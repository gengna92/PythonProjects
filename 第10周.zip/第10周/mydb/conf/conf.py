host = '192.168.168.178'
port= 3306
db = 'aaaa'
username = 'root'
password = '12345678'

# host = '127.0.0.1'
# port= 3306
# db = ''
# username = 'root'
# password = '123456'