import time

from selenium.webdriver import ActionChains
import selenium.webdriver.support.expected_conditions as EC
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.select import Select

from base.get_logger import GetLogger
from selenium import webdriver
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.support.wait import WebDriverWait


# 获取log日志器
log = GetLogger().get_logger()


class Base:

    def __init__(self, base_driver=None):
        # 注解，不是赋值操作。用作ide的类型提示
        base_driver: WebDriver
        if base_driver is None:
            self.driver = webdriver.Chrome()
            #sit
            self.driver.get("http://sit2.cbi-ls.szf.com/#/login")
            #uat
            # self.driver.get("http://ls.corporbank.com/#/login?redirect=%2F")
            log.info("[base]: 正在获取初始化driver对象:{}".format(self.driver))
        else:
            self.driver = base_driver
        self.driver.implicitly_wait(3)

    # 登录
    def login(self,username,pwd,username_loc,pwd_loc,sign_in_loc):
        log.info("[base]: {} 正在登录.".format(username))
        self.base_input(username_loc,username)
        self.base_input(pwd_loc,pwd)
        self.base_click(sign_in_loc)

    # 查找元素方法 封装
    def base_find(self, loc,  timeout=60, poll=0.5):
        log.info("[base]: 正在定位:{} 元素，默认定位超时时间为: {}".format(loc, timeout))
        # 使用显示等待 查找元素
        return WebDriverWait(self.driver,
                             timeout=timeout,
                             poll_frequency=poll).until(lambda x:x.find_element(*loc))

        # 查找元素方法 封装
    def base_finds(self, loc,  timeout=60, poll=0.5):
        log.info("[base]: 正在定位:{} 元素们，默认定位超时时间为: {}".format(loc, timeout))
        # 使用显示等待 查找元素
        return WebDriverWait(self.driver,
                             timeout=timeout,
                             poll_frequency=poll).until(lambda x:x.find_elements(*loc))

    # 点击元素 方法封装
    def base_click(self, loc, timeout=60, poll=0.5):
        log.info("[base]: 正在对:{} 元素实行点击事件".format(loc))
        WebDriverWait(self.driver,
                      timeout=timeout,
                      poll_frequency=poll).until(expected_conditions.element_to_be_clickable(loc))
        self.base_find(loc).click()

    # 输入元素 方法封装
    def base_input(self, loc, value):
        # 先找到元素
        el = self.base_find(loc)
        # 清空
        log.info("[base]: 正在对:{} 元素实行清空".format(loc))
        el.clear()
        # 输入
        el.send_keys(value)

    # 输入元素 下拉框方法封装 #直接sendkeys不行，不会往下走
    def base_send_keys(self, loc, value):
        # 先找到元素
        el = self.base_find(loc)
        self.driver.execute_script("document.getElementsByTagName('input')[0].removeAttribute('readonly');")
        self.driver.execute_script("document.getElementsByTagName('input')[1].removeAttribute('readonly');")
        # 输入
        el.send_keys(value)

    # 选择下拉元素方法封装 #Message: Select only works on <select> elements, not on <li>
    def base_select(self, loc,value):
        Select(self.driver.find_element_by_xpath(loc)).select_by_visible_text(value)

    #下拉框找到元素，js,click
    def base_js_click(self,el):
        self.driver.execute_script("arguments[0].click();",el)

    # actionchains 从一个元素挪到另一个
    def base_action_chains(self, loc1,loc2):
        source = self.base_find(loc1)
        target = self.base_find(loc2)
        action = ActionChains(self.driver)
        action.drag_and_drop(source,target).perform()


    # 获取文本信息 方法封装
    def base_get_text(self, loc):
        log.info("[base]: 正在获取:{} 元素文本值".format(loc))
        return self.base_find(loc).text

    # 截图方法封装
    def base_get_image(self):
        log.info("[base]: 断言出错，调用截图")
        self.driver.get_screenshot_as_file("../image/{}.png".format(time.strftime("%Y_%m_%d %H_%M_%S")))

    # 判断元素是否存在 方法封装
    def base_element_is_exist(self, loc):
        try:
            self.base_find(loc, timeout=2)
            log.info("[base]: {} 元素查找成功，存在页面".format(loc))
            return True # 代表元素存在
        except:
            log.info("[base]: {} 元素查找失败，不存在当前页面".format(loc))
            return False # 代表元素不存在


# 切换frame表单方法
    def base_switch_frame(self, name):
        self.driver.switch_to.frame(name)

    # 回到默认目录方法
    def base_default_content(self):
        self.driver.switch_to.default_content()

    # 切换窗口 方法 调用此方法
    def base_switch_to_window(self, title):
        log.info("正在执行切换title值为：{}窗口 ".format(title))
        self.driver.switch_to.window(self.base_get_title_handle(title))

    # 获取指定title页面的handle方法
    def base_get_title_handle(self, title):
        # 获取当前页面所有的handles
        for handle in self.driver.window_handles:
            log.info("正在遍历handles：{}-->{}".format(handle, self.driver.window_handles))
            # 切换 handle
            self.driver.switch_to.window(handle)
            log.info("切换 :{} 窗口".format(handle))
            # 获取当前页面title 并判断 是否等于 指定参数title
            log.info("判断当前页面title:{} 是否等于指定的title:{}".format(self.driver.title, title))
            if self.driver.title == title:
                log.info("条件成立！ 返回当前handle{}".format(handle))
                # 返回 handle
                return handle
    # 关闭driver
    def quit(self):
        self.driver.quit()
