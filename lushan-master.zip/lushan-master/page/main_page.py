from base.base import Base
from base.get_logger import GetLogger
from selenium.webdriver.common.by import By
from page.cbibank_page import CbiBankPage
# 获取log日志器
log = GetLogger().get_logger()


class MainPage(Base):
    _EMI_loc = (By.ID,"tab-#EMI")
    _cbibank_loc = (By.ID,"tab-#CBIBANK")
    _menu_loc = (By.XPATH,"//div[@class='hamburger-container']")

    #EMI
    def go_to_EMI(self):
        log.info("[main_page] 执行进入EMI操作")
        self.base_click(self._EMI_loc)
        # return EmiPage(self.driver)

    #CBIBANK
    def go_to_cbi_bank(self):
        if self.base_element_is_exist(self._cbibank_loc):
            log.info("[main_page] 执行进入cbiBANK登录操作")
            self.base_click(self._cbibank_loc)
        else:
            self.base_default_content()
        return CbiBankPage(self.driver)
