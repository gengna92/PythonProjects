from base.base import Base
from base.get_logger import GetLogger
from selenium.webdriver.common.by import By
from page.main_page import MainPage
# 获取log日志器
log = GetLogger().get_logger()


class LoginPage(Base):
    _username_loc = (By.NAME,"userName")
    _pwd_loc = (By.NAME,"password")
    _sign_in_loc = (By.XPATH,"//*[@type='button']")
    # 点击 登录链接
    def go_to_main_page(self):
        self.username = '1320000000'
        self.pwd = 'Henna@123'
        # self.username = '190'
        # self.pwd = 'Qwe123'
        log.info("[login_page] 执行：{}登录操作".format(self.username))
        self.login(self.username,self.pwd,self._username_loc,self._pwd_loc,self._sign_in_loc)
        return MainPage(self.driver)
