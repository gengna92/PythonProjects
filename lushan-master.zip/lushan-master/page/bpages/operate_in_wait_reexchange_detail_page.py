import time

from selenium.webdriver.common.by import By

from base.base import Base


class OperateInWaitReexchangeDetailPage(Base):

    def _reback_menu(self):
        time.sleep(2)
        _out_reexc_loc = (By.XPATH,"//span[contains(text(),'汇入交易退汇')]")
        _reexchange_out = self.base_finds(_out_reexc_loc)[2]
        _reexchange_out.click()
        _com_reexchange_loc = (By.XPATH,"//span[contains(text(),'退汇交易')]")
        _operate_reexchange_trans = self.base_finds(_com_reexchange_loc)[8]
        _operate_reexchange_trans.click()
        _oper_cen_loc = (By.XPATH,"//span[contains(text(),'运营中心')]")
        self.base_click(_oper_cen_loc)

    def operate_in_reexchange(self):
        time.sleep(2)
        _reexchange_loc = (By.XPATH,"//span[contains(text(),'自动退汇')]")
        self.base_click(_reexchange_loc)
        time.sleep(1)
        _choice_loc = (By.XPATH,"//input[@placeholder='请选择']")
        self.base_click(_choice_loc)
        _nostr_loc = (By.XPATH,"//span[contains(text(),'TESTCNY')]")
        self.base_js_click(_nostr_loc)
        _bkup_message_loc = (By.XPATH,"//textarea[@placeholder='请输入交易描述']")
        self.base_input(_bkup_message_loc,"auto_test")
        _ensure_loc = (By.XPATH,"//span[contains(text(),'提交')]")
        self.base_click(_ensure_loc)
        time.sleep(1)
        _sure_loc = (By.XPATH,"//span[contains(text(),'确定')]")
        self.base_click(_sure_loc)
        self._reback_menu()
