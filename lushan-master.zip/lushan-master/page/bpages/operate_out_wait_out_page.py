import time

from selenium.webdriver.common.by import By

from base.base import Base
from base.get_logger import GetLogger
from page.bpages.operate_out_wait_out_detail_page import OperateOutWaitOutDetailPage

log = GetLogger.get_logger()


class OperateOutWaitOut(Base):

    def out_wait_out(self,order_id):
        _tran_order_id_loc = (By.XPATH,"//input[contains(@placeholder,'请输入交易单号')]")
        self.base_input(_tran_order_id_loc,order_id)
        _query_button_loc = (By.XPATH,"//button[@class='el-button el-button--primary el-button--small']")
        self.base_click(_query_button_loc)
        time.sleep(2)
        _detail_loc = (By.XPATH,"//span[contains(text(),'详情')]")
        _detail = self.base_finds(_detail_loc)[1]
        _detail.click()
        return OperateOutWaitOutDetailPage(self.driver)

    def c_out_wait_out(self,order_id):
        _tran_order_id_loc = (By.XPATH,"//input[contains(@placeholder,'请输入交易单号')]")
        self.base_input(_tran_order_id_loc,order_id)
        time.sleep(1)
        _type_loc = (By.XPATH,"//input[@placeholder='请选择']")
        self.base_click(_type_loc)
        time.sleep(1)
        _signature_loc = self.base_finds((By.XPATH,"//span[contains(text(),'个人')]"))[7]
        self.base_js_click(_signature_loc)
        _query_button_loc = (By.XPATH,"//button[@class='el-button el-button--primary el-button--small']")
        self.base_click(_query_button_loc)
        time.sleep(2)
        _detail_loc = (By.XPATH,"//span[contains(text(),'详情')]")
        _detail = self.base_finds(_detail_loc)[1]
        _detail.click()
        return OperateOutWaitOutDetailPage(self.driver)

    