from base.base import Base


class RiskInRiskDealPage(Base):
    def risk_in_risk_deal(self):
        pass