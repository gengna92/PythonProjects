from base.base import Base


class RiskOutRiskDealPage(Base):
    def risk_out_risk_deal(self):
        pass