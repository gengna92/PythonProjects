import time

from selenium.webdriver.common.by import By

from base.base import Base
from page.bpages.tran_center_query_in_detail_page import TranCenterQueryInDetailPage


class TranCenterQueryInPage(Base):

    def query_in(self,send_out_en_name):
        _send_out_english_name_loc = (By.XPATH,"//input[contains(@placeholder,'请输入汇款人英文名称')]")
        self.base_input(_send_out_english_name_loc,send_out_en_name)
        _query_button_loc = (By.XPATH,"//button[@class='el-button el-button--primary el-button--small']")
        self.base_click(_query_button_loc)
        time.sleep(5)
        #根据结果动态修改下标
        _trs = self.base_finds((By.XPATH,"//tr[@class='el-table__row']"))
        counts = len(_trs)
        c = int(counts)
        if c == 2 :
            _detail_loc = (By.XPATH,"//span[contains(text(),'详情')]")
            _detail = self.base_finds(_detail_loc)[1]
            _detail.click()
        else:
            i = (c-2)/2
            a = int(i)
            _detail_loc = (By.XPATH,"//span[contains(text(),'详情')]")
            _detail = self.base_finds(_detail_loc)[a]
            _detail.click()
        return TranCenterQueryInDetailPage(self.driver)


    def query_in4inter_trans(self,order_id):
        time.sleep(2)
        _tran_order_id_loc = (By.XPATH,"//input[contains(@placeholder,'请输入交易单号')]")
        self.base_input(_tran_order_id_loc,order_id)
        _query_button_loc = (By.XPATH,"//button[@class='el-button el-button--primary el-button--small']")
        self.base_click(_query_button_loc)
        time.sleep(2)
        _detail_loc = (By.XPATH,"//span[contains(text(),'详情')]")
        _detail = self.base_finds(_detail_loc)[1]
        _detail.click()
        return TranCenterQueryInDetailPage(self.driver)