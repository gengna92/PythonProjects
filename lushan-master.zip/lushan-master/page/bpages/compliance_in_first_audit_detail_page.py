import time

from selenium.webdriver.common.by import By

from base.base import Base

class ComplianceInFirstAuditDetailPage(Base):

    def reback_compliance(self):
        _com_in_loc = (By.XPATH,"//span[contains(text(),'汇入交易')]")
        _com_center_company_loc = (By.XPATH,"//span[contains(text(),'企业')]")
        time.sleep(1)
        _compliance_out_trans = self.base_finds(_com_in_loc)[6]
        _compliance_out_trans.click()
        _com_center_company = self.base_finds(_com_center_company_loc)[2]
        _com_center_company.click()
        _compliance_cen_loc = (By.XPATH,"//span[contains(text(),'合规中心')]")
        self.base_click(_compliance_cen_loc)

    #通过
    def in_first_audit_pass(self):
        time.sleep(2)
        _pass_button_loc = (By.XPATH,"//span[contains(text(),'通过')]")
        self.base_click(_pass_button_loc)
        time.sleep(2)
        _pass_message_loc = (By.XPATH,"//textarea[contains(@placeholder,'请输入备注')]")
        self.base_input(_pass_message_loc,"autotest_pass1")
        time.sleep(1)
        _sure_button_loc = (By.XPATH,"//span[contains(text(),'确 定')]")
        _en_sure_button = self.base_finds(_sure_button_loc)[3]
        _en_sure_button.click()
        self.reback_compliance()


    #驳回
    def in_first_audit_reject(self):
        _pass_button_loc = (By.XPATH,"//span[contains(text(),'驳回')]")
        self.base_click(_pass_button_loc)
        _pass_message_loc = (By.XPATH,"//textarea[contains(@placeholder,'请输入备注')]")
        self.base_input(_pass_message_loc,"autotest_reject")
        _sure_button_loc = (By.XPATH,"//span[contains(text(),'确 定')]")
        _en_sure_button = self.base_finds(_sure_button_loc)[2]
        _en_sure_button.click()
        self.reback_compliance()

    #合规拒绝
    def in_first_audit_refuse(self):
        time.sleep(3)
        _pass_button_loc = (By.XPATH,"//span[contains(text(),'合规拒绝')]")
        self.base_click(_pass_button_loc)
        _pass_message_loc = (By.XPATH,"//textarea[contains(@placeholder,'请输入备注')]")
        self.base_input(_pass_message_loc,"autotest_reject")
        _sure_button_loc = (By.XPATH,"//span[contains(text(),'确 定')]")
        _en_sure_button = self.base_finds(_sure_button_loc)[2]
        _en_sure_button.click()
        _ensure_loc = (By.XPATH,"//span[contains(text(),'确定')]")
        self.base_click(_ensure_loc)
        self.reback_compliance()





