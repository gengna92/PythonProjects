import time

from selenium.webdriver.common.by import By

from base.base import Base


class OperateReexchangeOutDetailPage(Base):

    def _reback_menu(self):
        time.sleep(2)
        _out_reexc_loc = (By.XPATH,"//span[contains(text(),'汇出交易退汇')]")
        _reexchange_out = self.base_finds(_out_reexc_loc)[2]
        _reexchange_out.click()
        _com_reexchange_loc = (By.XPATH,"//span[contains(text(),'退汇交易')]")
        _operate_reexchange_trans = self.base_finds(_com_reexchange_loc)[8]
        _operate_reexchange_trans.click()
        _tran_cen_loc = (By.XPATH,"//span[contains(text(),'运营中心')]")
        self.base_click(_tran_cen_loc)

    def operate_reexchange_out_detail(self):
        time.sleep(1)
        _status_loc = self.base_find((By.XPATH,"//div[@class='sub-content']"))
        status = _status_loc.text
        _order_loc = self.base_finds((By.XPATH,"//span[contains(text(),'交易单号')]/../span"))[1]
        orderid = _order_loc.text
        self._reback_menu()
        return [orderid,status]

