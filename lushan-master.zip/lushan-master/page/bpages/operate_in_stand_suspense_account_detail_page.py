import time

from selenium.webdriver.common.by import By

from base.base import Base


class OperateInStandSuspenseAccountDetailPage(Base):

    def _reback_menu(self):
        time.sleep(3)
        _o_in_standard_in = (By.XPATH,"//span[contains(text(),'标准类汇入')]")
        self.base_click(_o_in_standard_in)
        _com_in_loc = (By.XPATH,"//span[contains(text(),'汇入交易')]")
        _operate_in_trans = self.base_finds(_com_in_loc)[10]
        _operate_in_trans.click()
        _ope_in_loc = (By.XPATH,"//span[contains(text(),'运营中心')]")
        self.base_click(_ope_in_loc)

    def do_suspense_account(self,order_id):
        _auto_loc = (By.XPATH,"//span[contains(text(),'自动挂账')]")
        self.base_click(_auto_loc)
        time.sleep(3)
        _choice_loc = (By.XPATH,"//input[@placeholder='请选择']")
        self.base_click(_choice_loc)
        time.sleep(2)
        _nostro_code_loc = self.base_find((By.XPATH,"//span[contains(text(),'CBISIGNUSD')]"))
        self.base_js_click(_nostro_code_loc)
        _decribe_loc = (By.XPATH,"//textarea[@placeholder='请输入交易描述']")
        self.base_send_keys(_decribe_loc,"autotest")
        _submit_loc = (By.XPATH,"//span[contains(text(),'提交')]")
        self.base_click(_submit_loc)
        time.sleep(2)
        _ensure_loc = (By.XPATH,"//span[contains(text(),'确定')]")
        self.base_click(_ensure_loc)
        self._reback_menu()

