import time

from selenium.webdriver.common.by import By

from base.base import Base

class ComplianceInReexQueryDetailPage(Base):

    def _reback_menu(self):
        time.sleep(2)
        _com_reexchange_loc = (By.XPATH,"//span[contains(text(),'退汇交易')]")
        _operate_reexchange_trans = self.base_finds(_com_reexchange_loc)[6]
        _operate_reexchange_trans.click()
        _company_loc = (By.XPATH,"//span[contains(text(),'企业')]")
        _company = self.base_finds(_company_loc)[2]
        _company.click()
        _com_cen_loc = (By.XPATH,"//span[contains(text(),'合规中心')]")
        self.base_click(_com_cen_loc)

    def detail_query(self):
        _status_loc = (By.XPATH,"//div[@class='sub-content']")
        status = self.base_get_text(_status_loc)
        _order_loc = self.base_finds(By.XPATH,"//span[contains(text(),'汇出交易单号')]/../span")[2]
        order_id = _order_loc.text
        self._reback_menu()
        return (order_id,status)

