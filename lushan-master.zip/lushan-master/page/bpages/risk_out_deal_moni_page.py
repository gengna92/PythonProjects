import time

from selenium.webdriver.common.by import By

from base.base import Base



class RiskOutDealMoniPage(Base):

    def _reback_menu(self):
        time.sleep(2)
        _company_loc = (By.XPATH,"//span[contains(text(),'企业')]")
        _company = self.base_finds(_company_loc)[3]
        _company.click()
        _t_moni_loc = (By.XPATH,"//span[contains(text(),'交易监控')]")
        self.base_click(_t_moni_loc)
        _t_moning_loc = (By.XPATH,"//span[contains(text(),'事中监控')]")
        self.base_click(_t_moning_loc)
        _t_manage_loc = (By.XPATH,"//span[contains(text(),'事中监控')]")
        self.base_click(_t_manage_loc)
        _risk_center_loc = (By.XPATH,"//span[contains(text(),'风控中心')]")
        self.base_click(_risk_center_loc)

    def query(self,order_id):
        _send_out_english_name_loc = (By.XPATH,"//input[contains(@placeholder,'请输入交易单号')]")
        self.base_input(_send_out_english_name_loc,order_id)
        _query_button_loc = (By.XPATH,"//button[@class='el-button el-button--primary el-button--small']")
        self.base_click(_query_button_loc)
        time.sleep(5)
        # _detail_loc = (By.XPATH,"//span[contains(text(),'详情')]")
        # _detail = self.base_finds(_detail_loc)[1]
        # _detail.click()
        #列表那个从左往右拉
        # loc1 = (By.XPATH,"//div[@class='el-table__body-wrapper is-scrolling-left']")
        # loc2 = (By.XPATH,"//div[@class='el-table__body-wrapper is-scrolling-right']")
        # self.base_action_chains(loc1,loc2)
        status_loc =(By.XPATH,"//div[contains(text(),'汇出记账成功')]")
        status = self.base_get_text(status_loc)
        return status
