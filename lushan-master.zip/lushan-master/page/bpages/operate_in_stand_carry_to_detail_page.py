import time

from selenium.webdriver.common.by import By

from base.base import Base


class OperateInStandCarryToDetailPage(Base):

    def _reback_menu(self):
        time.sleep(2)
        _o_in_standard_in = (By.XPATH,"//span[contains(text(),'标准类汇入')]")
        self.base_click(_o_in_standard_in)
        _com_in_loc = (By.XPATH,"//span[contains(text(),'汇入交易')]")
        _operate_in_trans = self.base_finds(_com_in_loc)[10]
        _operate_in_trans.click()
        _operate_center_loc = (By.XPATH,"//span[contains(text(),'运营中心')]")
        self.base_click(_operate_center_loc)

    #todo:确认入账
    def do_carry_to(self):
        _ensure_loc = (By.XPATH,"//span[contains(text(),'确认入账')]")
        self.base_click(_ensure_loc)
        _swift_loc = (By.XPATH,"//input[@class='el-input__inner']")
        self.base_input(_swift_loc,"CBLBPRS0")
        _submit_loc = (By.XPATH,"//span[contains(text(),'提交')]")
        self.base_click(_submit_loc)
        time.sleep(2)
        _sure_loc = (By.XPATH,"//span[contains(text(),'确定')]")
        self.base_click(_sure_loc)
        self._reback_menu()
