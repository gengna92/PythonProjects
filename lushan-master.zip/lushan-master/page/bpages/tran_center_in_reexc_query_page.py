import time

from selenium.webdriver.common.by import By

from base.base import Base
from page.bpages.compliance_in_reexc_detail_page import ComplianceInReexQueryDetailPage
from page.bpages.tran_center_in_reexc_detail_page import TranCenterInReexcDetailPage
from page.bpages.tran_center_out_reexc_detail_page import TranCenterOutReexcDetailPage


class TranCenterInReexcQueryPage(Base):

    def in_reexchange_query(self,order_id):
        _input_order_id_loc = (By.XPATH,"//input[@placeholder='请输入汇出交易单号']")
        self.base_input(_input_order_id_loc,order_id)
        _query_button_loc = (By.XPATH,"//button[@class='el-button el-button--primary el-button--small']")
        self.base_click(_query_button_loc)
        time.sleep(2)
        _detail_loc = (By.XPATH,"//span[contains(text(),'详情')]")
        _detail = self.base_finds(_detail_loc)[1]
        _detail.click()
        return TranCenterInReexcDetailPage(self.driver)
