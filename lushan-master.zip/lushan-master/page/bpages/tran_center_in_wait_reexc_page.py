import time

from selenium.webdriver.common.by import By

from base.base import Base
from page.bpages.tran_center_in_wait_reexc_detail_page import TranCenterInWaitReexcDetailPage


class TranCenterInWaitReexcPage(Base):

    def in_wait_reexchange(self,order_id):
        _input_order_id_loc = (By.XPATH,"//input[@placeholder='请输入原交易单号']")
        self.base_input(_input_order_id_loc,order_id)
        _query_button_loc = (By.XPATH,"//button[@class='el-button el-button--primary el-button--small']")
        self.base_click(_query_button_loc)
        time.sleep(3)
        _detail_loc = (By.XPATH,"//span[contains(text(),'详情')]")
        _detail = self.base_finds(_detail_loc)[1]
        _detail.click()
        #todo:没数据，到不了详情页
        return TranCenterInWaitReexcDetailPage(self.driver)