import time

from selenium.webdriver.common.by import By

from base.base import Base


class TranCenterQueryInDetailPage(Base):

    def _reback_menu(self):
        time.sleep(2)
        _t_center_in_loc = (By.XPATH,"//span[contains(text(),'汇入交易')]")
        self.base_click(_t_center_in_loc)
        _t_center_company_loc = (By.XPATH,"//span[contains(text(),'企业')]")
        _t_center_company = self.base_finds(_t_center_company_loc)[1]
        _t_center_company.click()
        _tran_cen_loc = (By.XPATH,"//div[@class='el-submenu__title']")
        _t_center_loc = self.base_finds(_tran_cen_loc)[6]
        _t_center_loc.click()

    def query_in_detail(self):
        time.sleep(1)
        _tran_in_amount_loc = (By.XPATH,"//div[contains(text(),'实际汇入金额')]/../div[@class='sub-content']")
        amount = self.base_get_text(_tran_in_amount_loc)
        _status_loc = (By.XPATH,"//div[contains(text(),'交易状态')]/../div[@class='sub-content']")
        status = self.base_get_text(_status_loc)
        time.sleep(1)
        self._reback_menu()
        return [amount,status]

    def detail(self):
        time.sleep(1)
        _order_loc = self.base_finds((By.XPATH,"//span[contains(text(),'交易单号')]/../span"))[1]
        orderid = _order_loc.text
        _status_loc = (By.XPATH,"//div[@class='sub-content']")
        status = self.base_get_text(_status_loc)
        time.sleep(1)
        self._reback_menu()
        return [orderid,status]

    def reexchange(self):
        _reexchange_loc = (By.XPATH,"//button[@class='el-button el-button--primary el-button--small']")
        self.base_click(_reexchange_loc)
        time.sleep(1)
        _choice_loc = (By.XPATH,"//input[@placeholder='请选择退汇类型']")
        self.base_click(_choice_loc)
        _consumer_re_loc = self.base_find((By.XPATH,"//span[contains(text(),'客户主动退汇')]"))
        self.base_js_click(_consumer_re_loc)
        _no_loc = self.base_finds((By.XPATH,"//span[@class='el-radio__inner']"))[1]
        _no_loc.click()
        _submit_loc = (By.XPATH,"//span[contains(text(),'提交审核')]")
        self.base_click(_submit_loc)
        time.sleep(1)
        _ensure_loc = (By.XPATH,"//span[contains(text(),'确定')]")
        self.base_click(_ensure_loc)
        self._reback_menu()


