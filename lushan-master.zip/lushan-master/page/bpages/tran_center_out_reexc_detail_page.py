import time

from selenium.webdriver.common.by import By

from base.base import Base

class TranCenterOutReexcDetailPage(Base):

    def detail_query(self):
        _status_loc = (By.XPATH,"//div[@class='sub-content']")
        status = self.base_get_text(_status_loc)
        _order_loc = self.base_finds(By.XPATH,"//span[contains(text(),'汇出交易单号')]/../span")[2]
        order_id = _order_loc.text
        return (order_id,status)

