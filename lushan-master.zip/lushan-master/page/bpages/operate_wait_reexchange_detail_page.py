import time

from selenium.webdriver.common.by import By

from base.base import Base


class OperateWaitReexchangeDetailPage(Base):

    def _reback_menu(self):
        time.sleep(2)
        _out_reexc_loc = (By.XPATH,"//span[contains(text(),'汇出交易退汇')]")
        _reexchange_out = self.base_finds(_out_reexc_loc)[2]
        _reexchange_out.click()
        _com_reexchange_loc = (By.XPATH,"//span[contains(text(),'退汇交易')]")
        _operate_reexchange_trans = self.base_finds(_com_reexchange_loc)[8]
        _operate_reexchange_trans.click()
        _tran_cen_loc = (By.XPATH,"//div[@class='el-submenu__title']")
        _t_center_loc = self.base_finds(_tran_cen_loc)[31]
        _t_center_loc.click()

    def operate_out_reexchange(self):
        time.sleep(2)
        _reexchange_loc = (By.XPATH,"//span[contains(text(),'退汇')]")
        _rec_loc = self.base_finds(_reexchange_loc)[28]
        _rec_loc.click()
        time.sleep(1)
        _bkup_message_loc = (By.XPATH,"//textarea[@placeholder='请输入备注']")
        self.base_input(_bkup_message_loc,"auto_test")
        _ensure_loc = (By.XPATH,"//span[contains(text(),'确 定')]")
        _ensure = self.base_finds(_ensure_loc)[6]
        _ensure.click()
        time.sleep(1)
        _sure_loc = (By.XPATH,"//span[contains(text(),'确定')]")
        self.base_click(_sure_loc)
        self._reback_menu()
