import time

from selenium.webdriver.common.by import By

from base.base import Base


class OperateInStandardIn(Base):

    def _reback_menu(self):
        time.sleep(3)
        _o_in_standard_in = (By.XPATH,"//span[contains(text(),'标准类汇入')]")
        self.base_click(_o_in_standard_in)
        _com_in_loc = (By.XPATH,"//span[contains(text(),'汇入交易')]")
        _operate_in_trans = self.base_finds(_com_in_loc)[10]
        _operate_in_trans.click()
        _ope_in_loc = (By.XPATH,"//span[contains(text(),'运营中心')]")
        self.base_click(_ope_in_loc)

    def in_standard_in(self,order_id):
        _tran_order_id_loc = (By.XPATH,"//input[contains(@placeholder,'请输入交易流水号')]")
        self.base_input(_tran_order_id_loc,order_id)
        _query_button_loc = (By.XPATH,"//button[@class='el-button el-button--primary el-button--small']")
        self.base_click(_query_button_loc)
        time.sleep(2)
        _detail_loc = (By.XPATH,"//span[contains(text(),'详情')]")
        _detail = self.base_finds(_detail_loc)[1]
        _detail.click()
        time.sleep(2)
        _manu_loc = (By.XPATH,"//span[contains(text(),'自动挂账')]")
        self.base_click(_manu_loc)
        time.sleep(3)
        _choice_loc = (By.XPATH,"//input[@placeholder='请选择']")
        self.base_click(_choice_loc)
        time.sleep(1)
        _nostro_code_loc = (By.XPATH,"//span[contains(text(),'CBISIGNUSD')]")
        self.base_js_click(_nostro_code_loc)
        _decribe_loc = (By.XPATH,"//textarea[@placeholder='请输入交易描述']")
        self.base_send_keys(_decribe_loc,"autotest")
        _submit_loc = (By.XPATH,"//span[contains(text(),'提交')]")
        self.base_click(_submit_loc)
        time.sleep(2)
        _ensure_loc = self.base_finds((By.XPATH,"//span[contains(text(),'确定')]"))[1]
        _ensure_loc.click()

    def in_standard_in_query(self,order_id):
        _tran_order_id_loc = (By.XPATH,"//input[contains(@placeholder,'请输入交易流水号')]")
        self.base_input(_tran_order_id_loc,order_id)
        _query_button_loc = (By.XPATH,"//button[@class='el-button el-button--primary el-button--small']")
        self.base_click(_query_button_loc)
        time.sleep(2)
        _detail_loc = (By.XPATH,"//span[contains(text(),'详情')]")
        _detail = self.base_finds(_detail_loc)[1]
        _detail.click()
        time.sleep(2)
        _status_loc = (By.XPATH,"//div[@class='sub-content']")
        status = self.base_get_text(_status_loc)
        _order_loc = self.base_finds((By.XPATH,"//span[contains(text(),'交易流水号')]/../span"))[1]
        orderid = _order_loc.text
        self._reback_menu()
        return [orderid,status]

