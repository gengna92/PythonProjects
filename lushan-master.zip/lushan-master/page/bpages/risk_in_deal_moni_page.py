from base.base import Base


class RiskInDealMoniPage(Base):
    def risk_in_deal_moni(self):
        pass