import time

from selenium.webdriver.common.by import By

from base.base import Base

class ComplianceInConneTranDetailPage(Base):

    def __reback_menu(self):
        time.sleep(3)
        _com_in_loc = (By.XPATH,"//span[contains(text(),'汇入交易')]")
        _compliance_in_trans = self.base_finds(_com_in_loc)[6]
        _compliance_in_trans.click()
        _company_loc = self.base_finds((By.XPATH,"//span[contains(text(),'企业')]"))[2]
        _company_loc.click()
        _compliance_loc = (By.XPATH,"//span[contains(text(),'合规中心')]")
        self.base_click(_compliance_loc)

    def in_conne_tran(self,apply_id):
        _apply_id_loc = (By.XPATH,"//input[contains(@placeholder,'请输入申报单号')]")
        self.base_input(_apply_id_loc,apply_id)
        _query_button_loc = self.base_finds((By.XPATH,"//button[@class='el-button el-button--primary el-button--small']"))[2]
        _query_button_loc.click()
        time.sleep(2)
        _radio_loc = (By.XPATH,"//span[@class='el-radio__input']")
        self.base_click(_radio_loc)
        time.sleep(1)
        _ensure_button_loc = self.base_finds((By.XPATH,"//button[@class='el-button el-button--primary el-button--small']"))[3]
        _ensure_button_loc.click()
        time.sleep(3)
        # _sure_loc = self.base_finds((By.XPATH,"//span[contains(text(),'确 定')]"))[4]
        # _sure_loc.click()
        _sure_loc = (By.XPATH,"//div[@aria-label='确认关联']/div[3]/span/button")
        self.base_click(_sure_loc)
        self.__reback_menu()

