import time

from selenium.webdriver.common.by import By

from base.base import Base
from page.bpages.operate_in_wait_reexchange_detail_page import OperateInWaitReexchangeDetailPage
from page.bpages.operate_reexchange_out_detail_page import OperateReexchangeOutDetailPage
from page.bpages.operate_wait_reexchange_detail_page import OperateWaitReexchangeDetailPage


class OperateInWaitReexchangePage(Base):

    def operate_wait_reexchange(self,order_id):
        _input_order_id_loc = (By.XPATH,"//input[@placeholder='请输入原交易单号']")
        self.base_input(_input_order_id_loc,order_id)
        _query_button_loc = (By.XPATH,"//button[@class='el-button el-button--primary el-button--small']")
        self.base_click(_query_button_loc)
        time.sleep(3)
        _detail_loc = (By.XPATH,"//span[contains(text(),'详情')]")
        _detail = self.base_finds(_detail_loc)[1]
        _detail.click()
        return OperateInWaitReexchangeDetailPage(self.driver)

    def operate_c_wait_reexchange(self,order_id):
        _input_order_id_loc = (By.XPATH,"//input[@placeholder='请输入交易单号']")
        self.base_input(_input_order_id_loc,order_id)
        time.sleep(1)
        _type_loc = (By.XPATH,"//input[@placeholder='请选择']")
        self.base_click(_type_loc)
        time.sleep(1)
        _signature_loc = self.base_finds((By.XPATH,"//span[contains(text(),'个人')]"))[7]
        self.base_js_click(_signature_loc)
        _query_button_loc = (By.XPATH,"//button[@class='el-button el-button--primary el-button--small']")
        self.base_click(_query_button_loc)
        time.sleep(3)
        _detail_loc = (By.XPATH,"//span[contains(text(),'详情')]")
        _detail = self.base_finds(_detail_loc)[1]
        _detail.click()
        return OperateInWaitReexchangeDetailPage(self.driver)
