import random
import string
import time

from selenium.webdriver.common.by import By

from base.base import Base


class OperateOutTransOutDetailPage(Base):

    def _reback_menu(self):
        _o_out_trans_out = (By.XPATH,"//span[contains(text(),'汇出交易')]")
        _out_trans_out = self.base_finds(_o_out_trans_out)[10]
        _out_trans_out.click()
        _operate_cen_loc = (By.XPATH,"//span[contains(text(),'运营中心')]")
        self.base_click(_operate_cen_loc)

    def out_trans_out_detail(self):
        time.sleep(1)
        _tran_out_amount_loc = (By.XPATH,"//div[contains(text(),'汇出金额')]/../div[@class='sub-content']")
        amount = self.base_get_text(_tran_out_amount_loc)
        _status_loc = (By.XPATH,"//div[contains(text(),'渠道状态')]/../div[@class='sub-content']")
        status = self.base_get_text(_status_loc)
        self._reback_menu()
        return [amount,status]

    def out_trans_out_success(self):
        time.sleep(1)
        _trans_out_success_loc = (By.XPATH,"//span[contains(text(),'汇出成功')]/..")
        self.base_click(_trans_out_success_loc)
        _choose_date_loc = (By.XPATH,"//input[@placeholder='请选择时间']")
        self.base_click(_choose_date_loc)
        _choose_day_loc = (By.XPATH,"//input[@placeholder='选择日期']")
        self.base_input(_choose_day_loc,"2020-02-03")
        time.sleep(5)
        _confirm_loc = (By.XPATH,"//span[contains(text(),'确定')]/..")
        self.base_click(_confirm_loc)
        time.sleep(1)
        _serial_loc = self.base_finds((By.XPATH,"//input[@class='el-input__inner']"))[9]
        random_serial = ''.join(random.sample(string.digits,8))
        _serial_loc.send_keys(random_serial)
        _remark_loc = (By.XPATH,"//textarea[@placeholder='请输入备注']")
        self.base_input(_remark_loc,"auto_test_remark")
        _ensure_loc = self.base_finds((By.XPATH,"//span[contains(text(),'确 定')]"))[6]
        _ensure_loc.click()
        _submits_loc = self.base_finds((By.XPATH,"//span[contains(text(),'提交')]"))[7]
        _submits_loc.click()
        time.sleep(1)
        self._reback_menu()

    def out_trans_out_fail(self):
        time.sleep(1)
        _trans_out_success_loc = (By.XPATH,"//span[contains(text(),'汇出失败')]/..")
        self.base_click(_trans_out_success_loc)
        _remark_loc = (By.XPATH,"//textarea[@placeholder='请输入备注']")
        self.base_input(_remark_loc,"auto_test_fail")
        _ensure_loc = self.base_finds((By.XPATH,"//span[contains(text(),'确 定')]"))[7]
        _ensure_loc.click()
        time.sleep(5)
        self._reback_menu()

    def core_accounting_ensure(self):
        time.sleep(1)
        _trans_out_success_loc = (By.XPATH,"//span[contains(text(),'核心记账确认')]/..")
        self.base_click(_trans_out_success_loc)
        time.sleep(1)
        _confirm_loc = self.base_finds((By.XPATH,"//span[contains(text(),'确 定')]"))[6]
        _confirm_loc.click()
        time.sleep(5)
        self._reback_menu()

