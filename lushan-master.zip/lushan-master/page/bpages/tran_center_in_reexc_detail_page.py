import time

from selenium.webdriver.common.by import By

from base.base import Base

class TranCenterInReexcDetailPage(Base):

    def _reback_menu(self):
        time.sleep(2)
        _in_reexchange_loc = (By.XPATH,"//span[contains(text(),'汇入交易退汇')]")
        self.base_click(_in_reexchange_loc)
        _company_loc = (By.XPATH,"//span[contains(text(),'企业')]")
        _company = self.base_finds(_company_loc)[1]
        _company.click()
        _com_cen_loc = (By.XPATH,"//span[contains(text(),'交易中心')]")
        self.base_click(_com_cen_loc)

    def detail_query(self):
        _status_loc = (By.XPATH,"//div[@class='sub-content']")
        status = self.base_get_text(_status_loc)
        _order_loc = self.base_finds(By.XPATH,"//span[contains(text(),'汇入交易单号')]/../span")[2]
        order_id = _order_loc.text
        self._reback_menu()
        return (order_id,status)

