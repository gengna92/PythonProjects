import time

from selenium.webdriver.common.by import By

from base.base import Base

class OperateOutWaitOutDetailPage(Base):

    def _reback_menu(self):
        time.sleep(2)
        _o_out_trans_out = (By.XPATH,"//span[contains(text(),'汇出交易')]")
        _out_trans_out = self.base_finds(_o_out_trans_out)[10]
        _out_trans_out.click()
        _operate_cen_loc = (By.XPATH,"//span[contains(text(),'运营中心')]")
        self.base_click(_operate_cen_loc)

    #USD通过
    def out_wait_audit_USD_pass(self):
        time.sleep(1)
        _wait_button_loc = (By.XPATH,"//span[contains(text(),'汇出待确认')]/..")
        self.base_click(_wait_button_loc)
        time.sleep(1)
        _agent_loc = (By.XPATH,"//span[@class='el-input__suffix-inner']")
        self.base_click(_agent_loc)
        _signature_loc = (By.XPATH,"//span[contains(text(),'SIGNATURE BANK')]")
        _sing_loc = self.base_find(_signature_loc)
        self.base_js_click(_sing_loc)
        _nostro_code_loc = self.base_finds(_agent_loc)[1]
        _nostro_code_loc.click()
        _n_code_loc = (By.XPATH,"//span[contains(text(),'CBISIGNUSD')]")
        self.base_find(_n_code_loc).click()
        _submits_loc = (By.XPATH,"//span[contains(text(),'提交')]")
        _submit_loc = self.base_finds(_submits_loc)[7]
        _submit_loc.click()
        time.sleep(1)
        _confirm_loc = (By.XPATH,"//span[contains(text(),'确定')]")
        self.base_click(_confirm_loc)
        self._reback_menu()

    #EUR通过
    def out_wait_audit_EUR_pass(self):
        time.sleep(1)
        _wait_button_loc = (By.XPATH,"//span[contains(text(),'汇出待确认')]/..")
        self.base_click(_wait_button_loc)
        time.sleep(1)
        _agent_loc = (By.XPATH,"//span[@class='el-input__suffix-inner']")
        self.base_click(_agent_loc)
        _signature_loc = (By.XPATH,"//span[contains(text(),'EMBC BANK')]")
        _sing_loc = self.base_find(_signature_loc)
        self.base_js_click(_sing_loc)
        _nostro_code_loc = self.base_finds(_agent_loc)[1]
        _nostro_code_loc.click()
        _n_code_loc = (By.XPATH,"//span[contains(text(),'TESTUSD')]")
        self.base_find(_n_code_loc).click()
        _submits_loc = (By.XPATH,"//span[contains(text(),'提交')]")
        _submit_loc = self.base_finds(_submits_loc)[7]
        _submit_loc.click()
        time.sleep(1)
        _confirm_loc = (By.XPATH,"//span[contains(text(),'确定')]")
        self.base_click(_confirm_loc)
        self._reback_menu()

    #CNY通过
    def out_wait_audit_CNY_pass(self):
        time.sleep(1)
        _wait_button_loc = (By.XPATH,"//span[contains(text(),'汇出待确认')]/..")
        self.base_click(_wait_button_loc)
        time.sleep(1)
        _agent_loc = (By.XPATH,"//span[@class='el-input__suffix-inner']")
        self.base_click(_agent_loc)
        _signature_loc = (By.XPATH,"//span[contains(text(),'PC BANK')]")
        _sing_loc = self.base_find(_signature_loc)
        self.base_js_click(_sing_loc)
        _nostro_code_loc = self.base_finds(_agent_loc)[1]
        _nostro_code_loc.click()
        _n_code_loc = (By.XPATH,"//span[contains(text(),'GOOPXXXUSD')]")
        self.base_find(_n_code_loc).click()
        _submits_loc = (By.XPATH,"//span[contains(text(),'提交')]")
        _submit_loc = self.base_finds(_submits_loc)[7]
        _submit_loc.click()
        time.sleep(1)
        _confirm_loc = (By.XPATH,"//span[contains(text(),'确定')]")
        self.base_click(_confirm_loc)
        self._reback_menu()

    #驳回
    def out_first_audit_reject(self):
        _pass_button_loc = (By.XPATH,"//span[contains(text(),'驳回')]")
        self.base_click(_pass_button_loc)
        _pass_message_loc = (By.XPATH,"//textarea[contains(@placeholder,'请输入备注')]")
        self.base_input("autotest_reject")
        _sure_button_loc = (By.XPATH,"//span[contains(text(),'确 定')]")
        _en_sure_button = self.base_finds(_sure_button_loc)[2]
        _en_sure_button.click()

    #合规拒绝
    def out_first_audit_refuse(self):
        _pass_button_loc = (By.XPATH,"//span[contains(text(),'合规拒绝')]")
        self.base_click(_pass_button_loc)
        _pass_message_loc = (By.XPATH,"//textarea[contains(@placeholder,'请输入备注')]")
        self.base_input("autotest_reject")
        _sure_button_loc = (By.XPATH,"//span[contains(text(),'确 定')]")
        _en_sure_button = self.base_finds(_sure_button_loc)[2]
        _en_sure_button.click()



