import time
from selenium.webdriver.common.by import By
from base.get_logger import GetLogger
from page.bpages.operate_in_stand_carry_to_detail_page import OperateInStandCarryToDetailPage
from page.bpages.operate_in_stand_suspense_account_detail_page import OperateInStandSuspenseAccountDetailPage
from page.bpages.operate_out_trans_out_detail_page import OperateOutTransOutDetailPage

log = GetLogger.get_logger()
from base.base import Base


class OperateInStandTranInPage(Base):

    def _reback_menu(self):
        time.sleep(2)
        _o_in_standard_in = (By.XPATH,"//span[contains(text(),'标准类汇入')]")
        self.base_click(_o_in_standard_in)
        _com_in_loc = (By.XPATH,"//span[contains(text(),'汇入交易')]")
        _operate_in_trans = self.base_finds(_com_in_loc)[5]
        _operate_in_trans.click()
        _operate_center_loc = (By.XPATH,"//span[contains(text(),'运营中心')]")
        self.base_click(_operate_center_loc)

    def tran_in_detail(self,order_id):
        time.sleep(2)
        _tran_order_id_loc = (By.XPATH,"//input[contains(@placeholder,'请输入交易单号')]")
        self.base_input(_tran_order_id_loc,order_id)
        _query_button_loc = (By.XPATH,"//button[@class='el-button el-button--primary el-button--small']")
        self.base_click(_query_button_loc)
        time.sleep(2)
        _detail_loc = (By.XPATH,"//span[contains(text(),'详情')]")
        _detail = self.base_finds(_detail_loc)[1]
        _detail.click()
        time.sleep(2)
        _status_loc = (By.XPATH,"//div[@class='sub-content']")
        status = self.base_get_text(_status_loc)
        _order_loc = self.base_finds((By.XPATH,"//span[contains(text(),'交易单号')]/../span"))[1]
        orderid = _order_loc.text
        self._reback_menu()
        return [orderid,status]

