import time

from selenium.webdriver.common.by import By

from base.base import Base
from page.bpages.compliance_out_first_audit_detail_page import ComplianceOutFirstAuditDetailPage
from base.get_logger import GetLogger
log = GetLogger.get_logger()


class ComplianceOutFirstAuditPage(Base):

    def out_first_audit(self,order_id):
        time.sleep(1)
        _tran_order_id_loc = (By.XPATH,"//input[contains(@placeholder,'请输入交易单号')]")
        self.base_input(_tran_order_id_loc,order_id)
        _query_button_loc = (By.XPATH,"//button[@class='el-button el-button--primary el-button--small']")
        self.base_click(_query_button_loc)
        time.sleep(2)
        _detail_loc = (By.XPATH,"//span[contains(text(),'详情')]")
        _detail = self.base_finds(_detail_loc)[1]
        _detail.click()
        return ComplianceOutFirstAuditDetailPage(self.driver)


