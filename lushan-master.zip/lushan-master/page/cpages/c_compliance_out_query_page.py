import time

from selenium.webdriver.common.by import By

from base.base import Base

class CComplianceOutQueryPage(Base):

    def reback_compliance(self):
        time.sleep(2)
        _com_out_loc = (By.XPATH,"//span[contains(text(),'汇出交易')]")
        _compliance_out_trans = self.base_finds(_com_out_loc)[6]
        _compliance_out_trans.click()
        _com_center_company_loc = self.base_finds((By.XPATH,"//span[contains(text(),'个人')]"))[2]
        _com_center_company_loc.click()
        _com_cen_loc = (By.XPATH,"//span[contains(text(),'合规中心')]")
        self.base_click(_com_cen_loc)

    def out_query_info(self,order_id):
        _tran_order_id_loc = (By.XPATH,"//input[contains(@placeholder,'请输入交易单号')]")
        self.base_input(_tran_order_id_loc,order_id)
        _query_button_loc = (By.XPATH,"//button[@class='el-button el-button--primary el-button--small']")
        self.base_click(_query_button_loc)
        time.sleep(2)
        _detail_loc = (By.XPATH,"//span[contains(text(),'详情')]")
        _detail = self.base_finds(_detail_loc)[1]
        _detail.click()
        time.sleep(2)
        _status_loc = (By.XPATH,"//div[@class='sub-content']")
        status = self.base_get_text(_status_loc)
        _order_loc = self.base_finds((By.XPATH,"//span[contains(text(),'交易单号')]/../span"))[1]
        orderid = _order_loc.text
        self.reback_compliance()
        return [orderid,status]