from base.base import Base


class CRiskInRiskDealPage(Base):
    def c_risk_in_risk_deal(self):
        pass