from base.base import Base


class CRiskOutRiskDealPage(Base):
    def c_risk_out_risk_deal(self):
        pass