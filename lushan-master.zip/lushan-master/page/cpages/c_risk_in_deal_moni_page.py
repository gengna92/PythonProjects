from base.base import Base


class CRiskInDealMoniPage(Base):
    def c_risk_in_deal_moni(self):
        pass