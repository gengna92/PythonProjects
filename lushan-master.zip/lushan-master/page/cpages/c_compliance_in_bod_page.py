from base.base import Base

class CComplianceInBodPage(Base):

    def in_bod_audit(self):
        pass