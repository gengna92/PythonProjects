import time

from selenium.webdriver.common.by import By

from base.base import Base


class CTranCenterQueryOutPage(Base):

    def back_tran_center(self):
        time.sleep(1)
        _t_center_out_loc = (By.XPATH,"//span[contains(text(),'汇出交易')]")
        _t_center_out = self.base_finds(_t_center_out_loc)[3]
        _t_center_out.click()
        _t_center_company_loc = (By.XPATH,"//span[contains(text(),'个人')]")
        _t_center_company = self.base_finds(_t_center_company_loc)[1]
        _t_center_company.click()
        _tran_cen_loc = (By.XPATH,"//span[contains(text(),'交易中心')]")
        self.base_click(_tran_cen_loc)

    def cancel_out(self,order_id):
        time.sleep(2)
        _tran_order_id_loc = (By.XPATH,"//input[contains(@placeholder,'请输入交易单号')]")
        self.base_input(_tran_order_id_loc,order_id)
        _query_button_loc = (By.XPATH,"//button[@class='el-button el-button--primary el-button--small']")
        self.base_click(_query_button_loc)
        time.sleep(2)
        _detail_loc = (By.XPATH,"//span[contains(text(),'详情')]")
        _detail = self.base_finds(_detail_loc)[1]
        _detail.click()
        time.sleep(2)
        _cancel_loc = (By.XPATH,"//span[contains(text(),'撤销')]/..")
        self.base_click(_cancel_loc)
        _ensure_loc = (By.XPATH,"//span[contains(text(),'确定')]/..")
        self.base_click(_ensure_loc)
        self.back_tran_center()

    def query_out_detail(self,order_id):
        time.sleep(2)
        _tran_order_id_loc = (By.XPATH,"//input[contains(@placeholder,'请输入交易单号')]")
        self.base_input(_tran_order_id_loc,order_id)
        _query_button_loc = (By.XPATH,"//button[@class='el-button el-button--primary el-button--small']")
        self.base_click(_query_button_loc)
        time.sleep(2)
        _detail_loc = (By.XPATH,"//span[contains(text(),'详情')]")
        _detail = self.base_finds(_detail_loc)[1]
        _detail.click()
        time.sleep(2)
        _status_loc = (By.XPATH,"//div[@class='sub-content']")
        status = self.base_get_text(_status_loc)
        _order_loc = self.base_finds((By.XPATH,"//span[contains(text(),'交易单号')]/../span"))[1]
        orderid = _order_loc.text
        self.back_tran_center()
        return [orderid,status]