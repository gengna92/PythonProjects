from base.base import Base

class CComplianceInQueryPage(Base):

    def in_query_info(self):
        pass