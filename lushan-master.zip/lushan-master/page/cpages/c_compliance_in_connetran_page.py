from base.base import Base

class CComplianceInConneTranPage(Base):

    def in_conne_tran(self):
        pass