from base.base import Base

class CTranCenterInReexcPage(Base):

    def in_reexchange(self):
        pass