from base.base import Base

class CComplianceInFirstAuditPage(Base):

    def in_first_audit(self):
        pass