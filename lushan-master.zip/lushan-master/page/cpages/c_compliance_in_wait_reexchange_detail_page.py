import time

from selenium.webdriver.common.by import By

from base.base import Base


class CComplianceInWaitReexchangeDetailPage(Base):

    def _reback_menu(self):
        time.sleep(2)
        _out_reexc_loc = (By.XPATH,"//span[contains(text(),'退汇交易')]")
        _reexchange_out = self.base_finds(_out_reexc_loc)[7]
        _reexchange_out.click()
        _com_reexchange_loc = (By.XPATH,"//span[contains(text(),'个人')]")
        _operate_reexchange_trans = self.base_finds(_com_reexchange_loc)[2]
        _operate_reexchange_trans.click()
        _com_cen_loc = (By.XPATH,"//span[contains(text(),'合规中心')]")
        self.base_click(_com_cen_loc)

    #todo:需要调
    def operate_out_reexchange(self):
        time.sleep(2)
        _reexchange_loc = (By.XPATH,"//span[contains(text(),'退汇')]")
        _rec_loc = self.base_finds(_reexchange_loc)[28]
        _rec_loc.click()
        time.sleep(1)
        _bkup_message_loc = (By.XPATH,"//textarea[@placeholder='请输入备注']")
        self.base_input(_bkup_message_loc,"auto_test")
        _ensure_loc = (By.XPATH,"//span[contains(text(),'确 定')]")
        _ensure = self.base_finds(_ensure_loc)[6]
        _ensure.click()
        time.sleep(1)
        _sure_loc = (By.XPATH,"//span[contains(text(),'确定')]")
        self.base_click(_sure_loc)
        self._reback_menu()
