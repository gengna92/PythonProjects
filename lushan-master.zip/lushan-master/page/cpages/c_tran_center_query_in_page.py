import time

from selenium.webdriver.common.by import By

from base.base import Base
from page.cpages.c_tran_center_query_in_detail_page import CTranCenterQueryInDetailPage


class CTranCenterQueryInPage(Base):

    def query_in(self,send_out_en_name):
        _send_out_english_name_loc = (By.XPATH,"//input[contains(@placeholder,'请输入汇款人英文名称')]")
        self.base_input(_send_out_english_name_loc,send_out_en_name)
        _query_button_loc = (By.XPATH,"//button[@class='el-button el-button--primary el-button--small']")
        self.base_click(_query_button_loc)
        time.sleep(3)
        # _detail_loc = (By.XPATH,"//span[contains(text(),'详情')]")
        # _detail = self.base_finds(_detail_loc)[1]
        # _detail.click()
        _detail2_loc = (By.XPATH,"//span[contains(text(),'详情')]")
        _detail2 = self.base_finds(_detail2_loc)[3]
        _detail2.click()
        return CTranCenterQueryInDetailPage(self.driver)
