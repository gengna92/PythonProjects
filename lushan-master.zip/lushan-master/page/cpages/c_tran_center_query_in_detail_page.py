import time

from selenium.webdriver.common.by import By

from base.base import Base


class CTranCenterQueryInDetailPage(Base):

    def _reback_menu(self):
        time.sleep(2)
        _t_center_in_loc = self.base_finds((By.XPATH,"//span[contains(text(),'汇入交易')]"))[3]
        _t_center_in_loc.click()
        _t_center_person_loc = self.base_finds((By.XPATH,"//span[contains(text(),'企业')]"))[1]
        _t_center_person_loc.click()
        _tran_cen_loc = (By.XPATH,"//div[@class='el-submenu__title']")
        _t_center_loc = self.base_finds(_tran_cen_loc)[6]
        _t_center_loc.click()

    def query_in_detail(self):
        time.sleep(1)
        _tran_in_amount_loc = (By.XPATH,"//div[contains(text(),'实际汇入金额')]/../div[@class='sub-content']")
        amount = self.base_get_text(_tran_in_amount_loc)
        _status_loc = (By.XPATH,"//div[contains(text(),'交易状态')]/../div[@class='sub-content']")
        status = self.base_get_text(_status_loc)
        time.sleep(1)
        self._reback_menu()
        return [amount,status]

