from base.base import Base

class CComplianceInSecondAuditPage(Base):

    def in_second_audit(self):
        pass