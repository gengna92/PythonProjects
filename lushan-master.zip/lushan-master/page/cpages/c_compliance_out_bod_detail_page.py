import time

from selenium.webdriver.common.by import By

from base.base import Base

class CComplianceOutBodDetailPage(Base):

    def reback_compliance(self):
        time.sleep(1)
        _com_out_loc = (By.XPATH,"//span[contains(text(),'汇出交易')]")
        _compliance_out_trans = self.base_finds(_com_out_loc)[8]
        _compliance_out_trans.click()
        _com_center_company_loc = self.base_finds((By.XPATH,"//span[contains(text(),'个人')]"))[2]
        _com_center_company_loc.click()
        _com_cen_loc = (By.XPATH,"//span[contains(text(),'合规中心')]")
        self.base_click(_com_cen_loc)

    #通过
    def bod_audit_pass(self):
        time.sleep(1)
        _pass_button_loc = (By.XPATH,"//span[contains(text(),'通过')]")
        self.base_click(_pass_button_loc)
        time.sleep(1)
        _pass_message_loc = (By.XPATH,"//textarea[contains(@placeholder,'请输入备注')]")
        self.base_input(_pass_message_loc,"autotest_pass2")
        _sure_button_loc = (By.XPATH,"//span[contains(text(),'确 定')]")
        _en_sure_button = self.base_finds(_sure_button_loc)[2]
        _en_sure_button.click()
        time.sleep(1)
        self.reback_compliance()

    #合规拒绝
    def bod_audit_refuse(self):
        _pass_button_loc = (By.XPATH,"//span[contains(text(),'合规拒绝')]")
        self.base_click(_pass_button_loc)
        _pass_message_loc = (By.XPATH,"//textarea[contains(@placeholder,'请输入备注')]")
        self.base_input(_pass_message_loc,"autotest_reject")
        _sure_button_loc = (By.XPATH,"//span[contains(text(),'确 定')]")
        _en_sure_button = self.base_finds(_sure_button_loc)[2]
        _en_sure_button.click()
        _ensure_loc = (By.XPATH,"//span[contains(text(),'确定')]")
        self.base_click(_ensure_loc)
        self.reback_compliance()




