from base.base import Base

class CTranCenterOutReexcPage(Base):

    def out_reexchange(self):
        pass