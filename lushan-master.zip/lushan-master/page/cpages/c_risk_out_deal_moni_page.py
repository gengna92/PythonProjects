from base.base import Base


class CRiskOutDealMoniPage(Base):
    def c_risk_out_deal_moni(self):
        pass