import time

from base.base import Base
from selenium.webdriver.common.by import By
from base.get_logger import GetLogger
from page.bpages.compliance_in_bod_page import ComplianceInBodPage
from page.bpages.compliance_in_connetran_page import ComplianceInConneTranPage
from page.bpages.compliance_in_first_audit_page import ComplianceInFirstAuditPage
from page.bpages.compliance_in_query_page import ComplianceInQueryPage
from page.bpages.compliance_in_reexchange_query_page import ComplianceInReexchangeQueryPage
from page.bpages.compliance_in_second_audit_page import ComplianceInSecondAuditPage
from page.bpages.compliance_in_wait_reexchange_page import ComplianceInWaitReexchangePage
from page.bpages.compliance_out_bod_page import ComplianceOutBodPage
from page.bpages.compliance_out_first_audit_page import ComplianceOutFirstAuditPage
from page.bpages.compliance_out_query_page import ComplianceOutQueryPage
from page.bpages.compliance_out_second_audit_page import ComplianceOutSecondAuditPage
from page.bpages.operate_in_stand_carry_to_page import OperateInStandCarryToPage
from page.bpages.operate_in_stand_suspense_account_page import OperateInStandSuspenseAccountPage
from page.bpages.operate_in_stand_tran_in_page import OperateInStandTranInPage
from page.bpages.operate_in_standard_in_page import OperateInStandardIn
from page.bpages.operate_in_wait_reexchange_page import OperateInWaitReexchangePage
from page.bpages.operate_out_trans_out_page import OperateOutTransOut
from page.bpages.operate_out_wait_out_page import OperateOutWaitOut
from page.bpages.operate_reexchange_in_page import OperateReexchangeInPage
from page.bpages.operate_reexchange_out_page import OperateReexchangeOutPage
from page.bpages.operate_wait_reexchange_page import OperateWaitReexchangePage
from page.bpages.risk_in_deal_moni_page import RiskInDealMoniPage
from page.bpages.risk_in_risk_deal_page import RiskInRiskDealPage
from page.bpages.risk_out_deal_moni_page import RiskOutDealMoniPage
from page.bpages.risk_out_risk_deal_page import RiskOutRiskDealPage
from page.bpages.tran_center_in_reexc_query_page import TranCenterInReexcQueryPage
from page.bpages.tran_center_in_wait_reexc_page import TranCenterInWaitReexcPage
from page.bpages.tran_center_out_reexc_page import TranCenterOutReexcPage
from page.bpages.tran_center_query_in_page import TranCenterQueryInPage
from page.bpages.tran_center_query_out_page import TranCenterQueryOutPage
#获取日志
from page.cpages.c_compliance_in_bod_page import CComplianceInBodPage
from page.cpages.c_compliance_in_connetran_page import CComplianceInConneTranPage
from page.cpages.c_compliance_in_first_audit_page import CComplianceInFirstAuditPage
from page.cpages.c_compliance_in_query_page import CComplianceInQueryPage
from page.cpages.c_compliance_in_second_audit_page import CComplianceInSecondAuditPage
from page.cpages.c_compliance_in_wait_reexchange_page import CComplianceInWaitReexchangePage
from page.cpages.c_compliance_out_bod_page import CComplianceOutBodPage
from page.cpages.c_compliance_out_first_audit_page import CComplianceOutFirstAuditPage
from page.cpages.c_compliance_out_query_page import CComplianceOutQueryPage
from page.cpages.c_compliance_out_second_audit_page import CComplianceOutSecondAuditPage
from page.cpages.c_risk_in_deal_moni_page import CRiskInDealMoniPage
from page.cpages.c_risk_in_risk_deal_page import CRiskInRiskDealPage
from page.cpages.c_risk_out_deal_moni_page import CRiskOutDealMoniPage
from page.cpages.c_risk_out_risk_deal_page import CRiskOutRiskDealPage
from page.cpages.c_tran_center_in_reexc_page import CTranCenterInReexcPage
from page.cpages.c_tran_center_in_wait_reexc_page import CTranCenterInWaitReexcPage
from page.cpages.c_tran_center_out_reexc_page import CTranCenterOutReexcPage
from page.cpages.c_tran_center_query_in_page import CTranCenterQueryInPage
from page.cpages.c_tran_center_query_out_page import CTranCenterQueryOutPage

log = GetLogger().get_logger()


class CbiBankPage(Base):

    _c_center_loc = (By.XPATH,"//span[contains(text(),'客户中心')]//..")
    _c_center_company_loc = (By.XPATH,"//span[contains(text(),'企业')]")
    _c_center_c_manage_loc = (By.XPATH,"//span[contains(text(),'客户管理')]")
    _c_center_vc_manage_loc = (By.XPATH,"//span[contains(text(),'虚拟子客户管理')]")
    _cm_customer_info_query_loc = (By.XPATH,"//span[contains(text(),'客户信息查询')]")
    _cm_account_info_query_loc = (By.XPATH,"//span[contains(text(),'账户信息查询')]")
    _cm_path_query_loc = (By.XPATH,"//span[contains(text(),'收款路径查询')]")
    _cm_path_audit_loc = (By.XPATH,"//span[contains(text(),'收款路径审核')]")
    _cm_cert_time_loc = (By.XPATH,"//span[contains(text(),'证件有效期管理')]")
    _cm_cert_timeout_query_loc =(By.XPATH,"//span[contains(text(),'证件过期查询')]")

    def switch_emi_menu_frame(self):
        _iframe_loc = (By.XPATH,'//*[@id="pane-#CBIBANK"]/iframe')
        if self.base_element_is_exist(_iframe_loc):
            iframe = self.base_find(_iframe_loc)
            self.base_switch_frame(iframe)




    #客户中心
    def _goto_cm_mange(self):
        log.info("[Emi_Page] 执行进入客户中心操作")
        #iframe无ID无NAME，先find这个iframe再进行switch
        self.switch_emi_menu_frame()
        self.base_click(self._c_center_loc)
        self.base_click(self._c_center_company_loc)
        self.base_click(self._c_center_c_manage_loc)

    #客户中心-客户信息查询
    def goto_cm_cinfo_query(self):
        self._goto_cm_mange()
        self.base_click(self._cm_customer_info_query_loc)
        #要测这个界面的时候再写
        # return CustomerCenterPage(self.driver)

    _t_center_loc = (By.XPATH,"//span[contains(text(),'交易中心')]")
    _t_center_company_loc = (By.XPATH,"//span[contains(text(),'企业')]")

    #交易中心-企业
    def _goto_tcenter(self):
        log.info("[emi_page] 正在进入交易中心")
        #切换iframe
        self.switch_emi_menu_frame()
        self.base_click(self._t_center_loc)
        _t_center_company = self.base_finds(self._t_center_company_loc)[1]
        _t_center_company.click()

    _t_center_person_loc = (By.XPATH,"//span[contains(text(),'个人')]")
    #交易中心-个人
    def _goto_c_tcenter(self):
        log.info("[emi_page] 正在进入交易中心")
        #切换iframe
        self.switch_emi_menu_frame()
        self.base_click(self._t_center_loc)
        _t_center_person = self.base_finds(self._t_center_person_loc)[1]
        _t_center_person.click()

    #交易中心-信息缺失
    def _goto_miss_tcenter(self):
        log.info("[emi_page] 正在进入交易中心")
        #切换iframe
        self.switch_emi_menu_frame()
        self.base_click(self._t_center_loc)
        _c_loc = self.base_finds(self._t_center_company_loc)[2]
        _c_loc.click()

    _t_center_out_loc = (By.XPATH,"//span[contains(text(),'汇出交易')]")
    _t_center_query_out_loc = (By.XPATH,"//span[contains(text(),'汇出交易查询')]")

    #打开企业汇出交易查询
    def goto_t_center_query_out_page(self):
        self._goto_tcenter()
        _t_center_out = self.base_finds(self._t_center_out_loc)[0]
        _t_center_out.click()
        log.info("[emi_page] 正在进入企业-交易中心汇出交易查询")
        self.base_click(self._t_center_query_out_loc)
        return TranCenterQueryOutPage(self.driver)

    #打开个人-汇出交易查询
    def goto_c_t_center_query_out_page(self):
        self._goto_c_tcenter()
        _t_center_out = self.base_finds(self._t_center_out_loc)[3]
        _t_center_out.click()
        log.info("[emi_page] 正在进入个人-交易中心汇出交易查询")
        _t_center_out_query_loc = self.base_finds(self._t_center_query_out_loc)[1]
        _t_center_out_query_loc.click()
        return CTranCenterQueryOutPage(self.driver)

    _t_center_in_loc = (By.XPATH,"//span[contains(text(),'汇入交易')]")
    _t_center_query_in_loc = (By.XPATH,"//span[contains(text(),'汇入交易查询')]")

    #打开企业-汇入交易查询
    def goto_t_center_query_in_page(self):
        self._goto_tcenter()
        time.sleep(1)
        _t_center_in = self.base_finds(self._t_center_in_loc)[0]
        _t_center_in.click()
        log.info("[emi_page] 正在进入企业-交易中心-汇入交易查询")
        self.base_click(self._t_center_query_in_loc)
        return TranCenterQueryInPage(self.driver)

    #打开个人-汇入交易查询
    def goto_c_t_center_query_in_page(self):
        self._goto_c_tcenter()
        _t_center_in = self.base_finds(self._t_center_in_loc)[3]
        _t_center_in.click()
        log.info("[emi_page] 正在进入企业-交易中心-汇入交易查询")
        _t_center_in_query = self.base_finds(self._t_center_query_in_loc)[1]
        _t_center_in_query.click()
        return CTranCenterQueryInPage(self.driver)

    _t_center_reexchange_loc = (By.XPATH,"//span[contains(text(),'退汇交易')]")
    _t_center_out_reexc_loc = (By.XPATH,"//span[contains(text(),'汇出交易退汇')]")
    _t_center_out_reexc_query_loc = (By.XPATH,"//span[contains(text(),'退汇交易查询')]")

    #打开企业-汇出交易退汇
    def goto_t_center_out_reexc_page(self):
        self._goto_tcenter()
        _t_re_exchange = self.base_finds(self._t_center_reexchange_loc)[0]
        _t_re_exchange.click()
        log.info("[emi_page] 正在进入企业-交易中心-汇出交易退汇")
        self.base_click(self._t_center_out_reexc_loc)
        self.base_click(self._t_center_out_reexc_query_loc)
        return TranCenterOutReexcPage(self.driver)

    #打开个人-汇出交易退汇
    def goto_c_t_center_out_reexc_page(self):
        self._goto_c_tcenter()
        _t_re_exchange = self.base_finds(self._t_center_reexchange_loc)[3]
        _t_re_exchange.click()
        log.info("[emi_page] 正在进入个人-交易中心-汇出交易退汇")
        _t_center_out_reexc = self.base_finds(self._t_center_out_reexc_loc)[1]
        _t_center_out_reexc.click()
        return CTranCenterOutReexcPage(self.driver)

    _t_center_in_reexc_loc = (By.XPATH,"//span[contains(text(),'汇入交易退汇')]")
    _wait_reexc_loc = (By.XPATH,"//span[contains(text(),'待退汇')]")
    #打开企业-汇入交易退汇-待退汇
    def goto_t_center_in_wait_reexc_page(self):
        self._goto_tcenter()
        _t_reexchange = self.base_finds(self._t_center_reexchange_loc)[0]
        _t_reexchange.click()
        log.info("[emi_page] 正在进入企业-交易中心汇入交易退汇")
        self.base_click(self._t_center_in_reexc_loc)
        self.base_click(self._wait_reexc_loc)
        return TranCenterInWaitReexcPage(self.driver)

    #打开企业-汇入交易退汇-待退汇
    def goto_t_center_in_reexc_query_page(self):
        self._goto_tcenter()
        _t_reexchange = self.base_finds(self._t_center_reexchange_loc)[0]
        _t_reexchange.click()
        log.info("[emi_page] 正在进入企业-交易中心汇入交易退汇")
        self.base_click(self._t_center_in_reexc_loc)
        _query_loc = self.base_finds((By.XPATH,"//span[contains(text(),'退汇交易查询')]"))[1]
        _query_loc.click()
        return TranCenterInReexcQueryPage(self.driver)

    #打开个人-汇入交易退汇-待退汇
    def goto_c_t_center_in_reexc_page(self):
        self._goto_c_tcenter()
        _t_reexchange = self.base_finds(self._t_center_reexchange_loc)[3]
        _t_reexchange.click()
        log.info("[emi_page] 正在进入个人-交易中心汇入交易退汇")
        _t_center_in_reexc = self.base_finds(self._t_center_in_reexc_loc)[1]
        _t_center_in_reexc.click()
        _wait_loc =  self.base_finds(self._wait_reexc_loc)[1]
        _wait_loc.click()
        return CTranCenterInWaitReexcPage(self.driver)

        #打开企业-汇入交易退汇-待退汇
    def goto_c_t_center_in_reexc_query_page(self):
        self._goto_c_tcenter()
        _t_reexchange = self.base_finds(self._t_center_reexchange_loc)[0]
        _t_reexchange.click()
        log.info("[emi_page] 正在进入个人-交易中心汇入交易退汇")
        self.base_click(self._t_center_in_reexc_loc)
        _query_loc = self.base_finds((By.XPATH,"//span[contains(text(),'退汇交易查询')]"))[3]
        _query_loc.click()
        return CTranCenterInReexcQueryPage(self.driver)


    _com_center_loc = (By.XPATH,"//span[contains(text(),'合规中心')]")
    _com_center_company_loc = (By.XPATH,"//span[contains(text(),'企业')]")
    _com_out_loc = (By.XPATH,"//span[contains(text(),'汇出交易')]")

    #合规中心-企业-汇出交易
    def _goto_compliance_center_out(self):
        log.info("[emi_page] 正在进入合规中心-企业-汇出交易")
        #切换iframe
        self.switch_emi_menu_frame()
        self.base_click(self._com_center_loc)
        _com_center_company = self.base_finds(self._t_center_company_loc)[2]
        _com_center_company.click()
        _compliance_out_trans = self.base_finds(self._com_out_loc)[6]
        _compliance_out_trans.click()

    _com_center_person_loc = (By.XPATH,"//span[contains(text(),'个人')]")
    #合规中心-个人-汇出交易
    def _goto_c_compliance_center_out(self):
        log.info("[emi_page] 正在进入合规中心-企业-汇出交易")
        #切换iframe
        self.switch_emi_menu_frame()
        self.base_click(self._com_center_loc)
        _com_center_c_loc = self.base_finds(self._com_center_person_loc)[2]
        _com_center_c_loc.click()
        _compliance_out_trans = self.base_finds(self._com_out_loc)[8]
        _compliance_out_trans.click()

    _com_out_first_audit_loc = (By.XPATH,"//span[contains(text(),'合规一审')]")#汇入的时候要用finds了
    #合规中心-企业-汇出交易-合规一审
    def goto_compliance_out_first_audit(self):
        self._goto_compliance_center_out()
        log.info("[emi_page] 正在进入合规中心-汇出交易-合规一审界面")
        self.base_click(self._com_out_first_audit_loc)
        return ComplianceOutFirstAuditPage(self.driver)

    #合规中心-个人-汇出交易-合规一审
    def goto_c_compliance_out_first_audit(self):
        self._goto_c_compliance_center_out()
        log.info("[emi_page] 正在进入合规中心-个人-汇出交易-合规一审界面")
        _com_out_first_audit = self.base_finds(self._com_out_first_audit_loc)[2]
        _com_out_first_audit.click()
        return CComplianceOutFirstAuditPage(self.driver)

    _com_out_second_audit_loc = (By.XPATH,"//span[contains(text(),'合规二审')]")#汇入的时候要用finds了
    #合规中心-企业-汇出交易-合规二审
    def goto_compliance_out_second_audit(self):
        self._goto_compliance_center_out()
        log.info("[emi_page] 正在进入合规中心-企业-汇出交易-合规二审界面")
        self.base_click(self._com_out_second_audit_loc)
        return ComplianceOutSecondAuditPage(self.driver)

    #合规中心-个人-汇出交易-合规二审
    def goto_c_compliance_out_second_audit(self):
        self._goto_c_compliance_center_out()
        log.info("[emi_page] 正在进入合规中心-个人-汇出交易-合规二审界面")
        _com_out_second_audit = self.base_finds(self._com_out_second_audit_loc)[2]
        _com_out_second_audit.click()
        return CComplianceOutSecondAuditPage(self.driver)

    _com_out_bod_audit_loc = (By.XPATH,"//span[contains(text(),'BOD讨论')]")#汇入的时候要用finds了
    #合规中心-企业-汇出交易-BOD
    def goto_compliance_out_bod(self):
        self._goto_compliance_center_out()
        log.info("[emi_page] 正在进入合规中心-企业-汇出交易-BOD界面")
        self.base_click(self._com_out_bod_audit_loc)
        return ComplianceOutBodPage(self.driver)

    #合规中心-个人-汇出交易-BOD
    def goto_c_compliance_out_bod(self):
        self._goto_c_compliance_center_out()
        log.info("[emi_page] 正在进入合规中心-个人-汇出交易-BOD界面")
        _com_out_bod_audit = self.base_finds(self._com_out_bod_audit_loc)[2]
        _com_out_bod_audit.click()
        return CComplianceOutBodPage(self.driver)

    _com_out_query_loc = (By.XPATH,"//span[contains(text(),'汇出交易查询')]")#[1]是
    #合规中心-企业-汇出交易-汇出交易查询
    def goto_compliance_out_query(self):
        self._goto_compliance_center_out()
        log.info("[emi_page] 正在进入合规中心-企业-汇出交易-汇出交易查询界面")
        _com_out_query = self.base_finds(self._com_out_query_loc)[2]
        _com_out_query.click()
        return ComplianceOutQueryPage(self.driver)

    #合规中心-个人-汇出交易-汇出交易查询
    def goto_c_compliance_out_query(self):
        self._goto_c_compliance_center_out()
        log.info("[emi_page] 正在进入合规中心-企业-汇出交易-汇出交易查询界面")
        _com_out_query = self.base_finds(self._com_out_query_loc)[3]
        _com_out_query.click()
        return CComplianceOutQueryPage(self.driver)

    _com_in_loc = (By.XPATH,"//span[contains(text(),'汇入交易')]")
    #合规中心-企业-汇入交易
    def _goto_compliance_center_in(self):
        log.info("[emi_page] 正在进入合规中心-企业-汇入交易")
        #切换iframe
        self.switch_emi_menu_frame()
        self.base_click(self._com_center_loc)
        _com_center_company_loc=self.base_finds(self._com_center_company_loc)[2]
        _com_center_company_loc.click()
        _compliance_in_trans = self.base_finds(self._com_in_loc)[6]
        _compliance_in_trans.click()

    #合规中心-企业-退汇交易
    def _goto_compliance_center_reexchange(self):
        log.info("[emi_page] 正在进入合规中心-企业-退汇交易")
        #切换iframe
        self.switch_emi_menu_frame()
        self.base_click(self._com_center_loc)
        _com_center_company_loc=self.base_finds(self._com_center_company_loc)[2]
        _com_center_company_loc.click()
        _reexchange_loc = (By.XPATH,"//span[contains(text(),'汇入待退汇')]")
        self.base_click(_reexchange_loc)

    #合规中心-企业-退汇交易-汇入待退汇
    def goto_compliance_in_wait_reexchange(self):
        log.info("[emi_page] 正在进入合规中心-企业-退汇交易-汇入待退汇")
        self._goto_compliance_center_reexchange()
        _wait_loc = (By.XPATH,"//span[contains(text(),'汇入待退汇')]")
        self.base_click(_wait_loc)
        return ComplianceInWaitReexchangePage(self.driver)

    #合规中心-企业-退汇交易-汇入退汇查询
    def goto_compliance_in_reexchange_query(self):
        log.info("[emi_page] 正在进入合规中心-企业-退汇交易-汇入退汇查询")
        self._goto_compliance_center_reexchange()
        _query_loc = (By.XPATH,"//span[contains(text(),'汇入退汇查询')]")
        self.base_click(_query_loc)
        return ComplianceInReexchangeQueryPage(self.driver)


    #合规中心-个人-退汇交易
    def _goto_c_compliance_center_reexchange(self):
        log.info("[emi_page] 正在进入合规中心-企业-退汇交易")
        #切换iframe
        self.switch_emi_menu_frame()
        self.base_click(self._com_center_loc)
        _c_loc = self.base_finds((By.XPATH,"//span[contains(text(),'个人')]"))[2]
        _c_loc.click()
        _reexchange_loc =self.base_finds((By.XPATH,"//span[contains(text(),'汇入待退汇')]"))[1]
        _reexchange_loc.click()

    #合规中心-个人-退汇交易-汇入待退汇
    def goto_c_compliance_in_wait_reexchange(self):
        log.info("[emi_page] 正在进入合规中心-企业-退汇交易-汇入待退汇")
        self._goto_c_compliance_center_reexchange()
        _wait_loc = self.base_finds((By.XPATH,"//span[contains(text(),'汇入待退汇')]"))[1]
        self.base_click(_wait_loc)
        return CComplianceInWaitReexchangePage(self.driver)

    #合规中心-个人-退汇交易-汇入退汇查询
    def goto_c_compliance_in_reexchange_query(self):
        log.info("[emi_page] 正在进入合规中心-企业-退汇交易-汇入退汇查询")
        self._goto_c_compliance_center_reexchange()
        _query_loc = self.base_finds((By.XPATH,"//span[contains(text(),'汇入退汇查询')]"))[1]
        self.base_click(_query_loc)
        return ComplianceInReexchangeQueryPage(self.driver)

    #合规中心-个人-汇入交易
    def _goto_c_compliance_center_in(self):
        log.info("[emi_page] 正在进入合规中心-个人-汇入交易")
        #切换iframe
        self.switch_emi_menu_frame()
        self.base_click(self._com_center_loc)
        _c_loc = self.base_finds((By.XPATH,"//span[contains(text(),'个人')]"))[2]
        _c_loc.click()
        _compliance_in_trans = self.base_finds(self._com_in_loc)[6]
        _compliance_in_trans.click()

    _com_in_first_audit_loc = (By.XPATH,"//span[contains(text(),'合规一审')]")
    #合规中心-企业-汇入交易-合规一审
    def goto_compliance_in_first_audit(self):
        self._goto_compliance_center_in()
        log.info("[emi_page] 正在进入合规中心-企业-汇入交易-合规一审界面")
        _in_first_audit = self.base_finds(self._com_in_first_audit_loc)[1]
        _in_first_audit.click()
        return ComplianceInFirstAuditPage(self.driver)

    #合规中心-个人-汇入交易-合规一审
    def goto_c_compliance_in_first_audit(self):
        self._goto_c_compliance_center_out()
        log.info("[emi_page] 正在进入合规中心-个人-汇入交易-合规一审界面")
        _in_first_audit = self.base_finds(self._com_in_first_audit_loc)[4]
        _in_first_audit.click()
        return CComplianceInFirstAuditPage(self.driver)

    _com_in_second_audit_loc = (By.XPATH,"//span[contains(text(),'合规二审')]")
    #合规中心-企业-汇入交易-合规二审
    def goto_compliance_in_second_audit(self):
        self._goto_compliance_center_in()
        log.info("[emi_page] 正在进入合规中心-企业-汇入交易-合规二审界面")
        _com_in_second_audit = self.base_finds(self._com_in_second_audit_loc)[1]
        _com_in_second_audit.click()
        return ComplianceInSecondAuditPage(self.driver)

    #合规中心-个人-汇入交易-合规二审
    def goto_c_compliance_in_second_audit(self):
        self._goto_c_compliance_center_in()
        log.info("[emi_page] 正在进入合规中心-企业-汇入交易-合规二审界面")
        _com_in_second_audit = self.base_finds(self._com_in_second_audit_loc)[4]
        _com_in_second_audit.click()
        return CComplianceInSecondAuditPage(self.driver)

    _com_in_bod_audit_loc = (By.XPATH,"//span[contains(text(),'BOD讨论')]")
    #合规中心-企业-汇入交易-BOD
    def goto_compliance_in_bod(self):
        self._goto_compliance_center_in()
        log.info("[emi_page] 正在进入合规中心-企业-汇入交易-BOD界面")
        _com_in_bod_audit = self.base_finds(self._com_in_bod_audit_loc)[1]
        _com_in_bod_audit.click()
        return ComplianceInBodPage(self.driver)

    #合规中心-个人-汇入交易-BOD
    def goto_c_compliance_in_bod(self):
        self._goto_c_compliance_center_in()
        log.info("[emi_page] 正在进入合规中心-企业-汇入交易-BOD界面")
        _com_in_bod_audit = self.base_finds(self._com_in_bod_audit_loc)[4]
        _com_in_bod_audit.click()
        return CComplianceInBodPage(self.driver)

    _com_in_query_loc = (By.XPATH,"//span[contains(text(),'汇入交易查询')]")#[1]是
    #合规中心-企业-汇入交易-汇入交易查询
    def goto_compliance_in_query(self):
        self._goto_compliance_center_in()
        log.info("[emi_page] 正在进入合规中心-汇入交易-汇入交易查询界面")
        _com_in_query = self.base_finds(self._com_in_query_loc)[1]
        _com_in_query.click()
        return ComplianceInQueryPage(self.driver)

    #合规中心-个人-汇入交易-汇入交易查询
    def goto_c_compliance_in_query(self):
        self._goto_c_compliance_center_in()
        log.info("[emi_page] 正在进入合规中心-个人-汇入交易-汇入交易查询界面")
        _com_in_query = self.base_finds(self._com_in_query_loc)[3]
        _com_in_query.click()
        return CComplianceInQueryPage(self.driver)

    _com_in_query_declare_loc = (By.XPATH,"//span[contains(text(),'客户申报查询')]")
    #合规中心-汇入交易-客户申报查询
    def goto_compliance_in_query_declare(self):
        self._goto_compliance_center_in()
        log.info("[emi_page] 正在进入合规中心-汇入交易-客户申报查询界面")
        self.base_click(self._com_in_query_declare_loc)
        # return 要用的时候再写页面

    _com_in_deal_relate_loc = (By.XPATH,"//span[contains(text(),'交易关联')]")
    #合规中心-企业-汇入交易-交易关联
    def goto_compliance_in_deal_relate(self):
        self._goto_compliance_center_in()
        log.info("[emi_page] 正在进入合规中心-汇入交易-交易关联")
        self.base_click(self._com_in_deal_relate_loc)
        return ComplianceInConneTranPage(self.driver)

    #合规中心-个人-汇入交易-交易关联
    def goto_c_compliance_in_deal_relate(self):
        self._goto_compliance_center_in()
        log.info("[emi_page] 正在进入合规中心-汇入交易-交易关联")
        _deal_relate_loc = self.base_finds(self._com_in_deal_relate_loc)[1]
        _deal_relate_loc.click()
        return CComplianceInConneTranPage(self.driver)

    _operate_center_loc = (By.XPATH,"//span[contains(text(),'运营中心')]")

    #运营中心-汇出交易
    def _goto_operate_center_out(self):
        log.info("[emi_page] 正在进入运营中心-汇出交易")
        #切换iframe
        self.switch_emi_menu_frame()
        self.base_click(self._operate_center_loc)
        _operate_out_trans = self.base_finds(self._com_out_loc)[10]
        _operate_out_trans.click()

    _o_out_wait_out = (By.XPATH,"//span[contains(text(),'待汇出')]")
    #运营中心-汇出交易-待汇出
    def goto_operate_out_wait_out(self):
        self._goto_operate_center_out()
        log.info("[emi_page] 正在进入运营中心-汇出交易-待汇出")
        self.base_click(self._o_out_wait_out)
        return OperateOutWaitOut(self.driver)

    _o_out_trans_out = (By.XPATH,"//span[contains(text(),'汇出交易')]")
    #运营中心-汇出交易-汇出交易
    def goto_operate_out_trans_out(self):
        self._goto_operate_center_out()
        log.info("[emi_page] 正在进入运营中心-汇出交易-汇出交易")
        _out_trans_out = self.base_finds(self._o_out_trans_out)[11]
        _out_trans_out.click()
        return OperateOutTransOut(self.driver)

    #运营中心-汇入交易
    def _goto_operate_center_in(self):
        log.info("[emi_page] 正在进入运营中心-汇入交易")
        #切换iframe
        self.switch_emi_menu_frame()
        self.base_click(self._operate_center_loc)
        _operate_in_trans = self.base_finds(self._com_in_loc)[10]
        _operate_in_trans.click()

    _o_in_standard_in = (By.XPATH,"//span[contains(text(),'标准类汇入')]")
    #运营中心-汇入交易-标准类汇入
    def goto_operate_in_standard_in(self):
        self._goto_operate_center_in()
        log.info("[emi_page] 正在进入运营中心-汇入交易-标准类汇入")
        self.base_click(self._o_in_standard_in)


    #运营中心-汇入交易-标准类汇入-汇入挂账
    def goto_operate_in_stand_suspense_account(self):
        self.goto_operate_in_standard_in()
        _suspense_account_loc = (By.XPATH,"//span[contains(text(),'汇入挂账')]")
        self.base_click(_suspense_account_loc)
        return OperateInStandSuspenseAccountPage(self.driver)

    #运营中心-汇入交易-标准类汇入-汇入入账
    def goto_operate_in_stand_carry_to(self):
        self.goto_operate_in_standard_in()
        _carry_to_loc = (By.XPATH,"//span[contains(text(),'汇入入账')]")
        self.base_click(_carry_to_loc)
        return OperateInStandCarryToPage(self.driver)

    #运营中心-汇入交易-标准类汇入-汇入交易
    def goto_operate_in_stand_tran_in(self):
        self.goto_operate_in_standard_in()
        _carry_to_loc = self.base_finds((By.XPATH,"//span[contains(text(),'汇入交易')]"))[11]
        _carry_to_loc.click()
        return OperateInStandTranInPage(self.driver)

    #运营中心-退汇交易
    def _goto_operate_center_reexchange(self):
        log.info("[emi_page] 正在进入运营中心-退汇交易")
        #切换iframe
        self.switch_emi_menu_frame()
        self.base_click(self._operate_center_loc)
        _operate_reexchange_trans = self.base_finds(self._com_reexchange_loc)[8]
        _operate_reexchange_trans.click()


    #运营中心-退汇交易-汇出交易退汇-退汇交易查询
    def goto_operate_reexchange_out(self):
        self._goto_operate_center_reexchange()
        _reexchange_out = self.base_finds(self._t_center_out_reexc_loc)[2]
        _reexchange_out.click()
        _t_center_out_reexc_query_loc = (By.XPATH,"//span[contains(text(),'退汇交易查询')]")
        _reexchange_out_query = self.base_finds((_t_center_out_reexc_query_loc))[4]
        _reexchange_out_query.click()
        return OperateReexchangeOutPage(self.driver)

    _wait_reexchange_loc = (By.XPATH,"//span[contains(text(),'待退汇')]")
    #运营中心-退汇交易-汇出交易退汇-待退汇
    def goto_operate_wait_reexchange(self):
        self._goto_operate_center_reexchange()
        _reexchange_out = self.base_finds(self._t_center_out_reexc_loc)[2]
        _reexchange_out.click()
        _wait_reexchange = self.base_finds(self._wait_reexchange_loc)[4]
        _wait_reexchange.click()
        return OperateWaitReexchangePage(self.driver)

    #运营中心-退汇交易-汇入交易退汇-待退汇
    def goto_operate_wait_reexchange_in(self):
        self._goto_operate_center_reexchange()
        _reexchange_in = self.base_finds(self._t_center_in_reexc_loc)[2]
        _reexchange_in.click()
        _wait_reechange_loc = self.base_finds(self._wait_reexchange_loc)[5]
        _wait_reechange_loc.click()
        return OperateInWaitReexchangePage(self.driver)

    #运营中心-退汇交易-汇入交易退汇-退汇交易查询
    def goto_operate_reexchange_in(self):
        self._goto_operate_center_reexchange()
        _reexchange_in = self.base_finds(self._t_center_in_reexc_loc)[2]
        _reexchange_in.click()
        _t_center_in_reexc_query_loc = (By.XPATH,"//span[contains(text(),'退汇交易查询')]")
        _reexchange_query = self.base_finds((_t_center_in_reexc_query_loc))[5]
        _reexchange_query.click()
        return OperateReexchangeInPage(self.driver)

    _operate_param_manage_loc = (By.XPATH,"//span[contains(text(),'参数配置管理')]")
    _operate_param_risk_country_loc = (By.XPATH,"//span[contains(text(),'风险国家')]")
    #运营中心-参数配置管理-风险国家
    def goto_operate_param_risk_country(self):
        log.info("[emi_page] 运营中心-参数配置管理-风险国家")
        #切换iframe
        self.switch_emi_menu_frame()
        self.base_click(self._operate_center_loc)
        self.base_click(self._operate_param_manage_loc)
        self.base_click(self._operate_param_risk_country_loc)
        # return OperateParamRiskCountryPage(self.driver)

    _risk_center_loc = (By.XPATH,"//span[contains(text(),'风控中心')]")
    _risk_center_rule_manage = (By.XPATH,"//span[contains(text(),'规则管理')]")

    #风控中心-规则管理
    def _goto_risk_center_rule(self):
        log.info("[emi_page] 正在进入风控中心-规则管理")
        #切换iframe
        self.switch_emi_menu_frame()
        self.base_click(self._risk_center_loc)
        self.base_click(self._risk_center_rule_manage)

    #风控中心-规则管理-规则管理
    def _goto_risk_center_rule_manage(self):
        log.info("[emi_page] 正在进入风控中心-规则管理-规则管理")
        self._goto_risk_center_rule()
        _rule_manage = self.base_finds(self._risk_center_rule_manage)[1]
        _rule_manage.click()
        # return RiskCenterRuleManage(self.driver) todo 用的时候写界面

    _risk_center_deal_manage = (By.XPATH,"//span[contains(text(),'交易管理')]")
    _deal_mid_monitoring = (By.XPATH,"//span[contains(text(),'事中监控')]")
    _deal_monitoring = (By.XPATH,"//span[contains(text(),'交易监控')]")
    _risk_deal_monitoring_company = (By.XPATH,"//span[contains(text(),'企业')]")
    #风控中心-交易管理-事中监控-交易监控-企业
    def _goto_risk_deal_monitoring(self):
        log.info("[emi_page] 正在进入风控中心-交易管理-事中监控-交易监控-企业菜单")
        #切换iframe
        self.switch_emi_menu_frame()
        self.base_click(self._risk_center_loc)
        self.base_click(self._risk_center_deal_manage)
        self.base_click(self._deal_mid_monitoring)
        self.base_click(self._deal_monitoring)
        _company_loc = self.base_finds(self._risk_deal_monitoring_company)[3]
        _company_loc.click()

    _risk_deal_monitoring_person = (By.XPATH,"//span[contains(text(),'个人')]")
    #风控中心-交易管理-事中监控-交易监控-个人
    def _goto_risk_deal_monitoring_person(self):
        log.info("[emi_page] 正在进入风控中心-交易管理-事中监控-交易监控-个人菜单")
        #切换iframe
        self.switch_emi_menu_frame()
        self.base_click(self._risk_center_loc)
        self.base_click(self._risk_center_deal_manage)
        self.base_click(self._deal_mid_monitoring)
        self.base_click(self._deal_monitoring)
        _person_loc = self.base_finds(self._risk_deal_monitoring_person)[3]
        _person_loc.click()

    _out_deal_monitoring_loc = (By.XPATH,"//span[contains(text(),'汇出交易监控')]")
    #风控中心-交易管理-事中监控-交易监控-企业-汇出交易监控
    def goto_risk_out_deal_monitoring(self):
        self._goto_risk_deal_monitoring()
        log.info("[emi_page] 正在进入风控中心-交易管理-事中监控-交易监控-企业-汇出交易监控页面")
        self.base_click(self._out_deal_monitoring_loc)
        return RiskOutDealMoniPage(self.driver)

    #风控中心-交易管理-事中监控-交易监控-个人-汇出交易监控
    def goto_risk_c_out_deal_monitoring(self):
        self._goto_risk_deal_monitoring_person()
        log.info("[emi_page] 正在进入风控中心-交易管理-事中监控-交易监控-企业-汇出交易监控页面")
        _out_deal_monitor_loc = self.base_finds(self._out_deal_monitoring_loc)
        _out_deal_monitor_loc.click()
        return CRiskOutDealMoniPage(self.driver)

    _in_deal_monitoring_loc = (By.XPATH,"//span[contains(text(),'汇入交易监控')]")
    #风控中心-交易管理-事中监控-交易监控-企业-汇入交易监控
    def goto_risk_in_deal_monitoring(self):
        self._goto_risk_deal_monitoring()
        log.info("[emi_page] 正在进入风控中心-交易管理-事中监控-交易监控-企业-汇入交易监控页面")
        self.base_click(self._in_deal_monitoring_loc)
        return RiskInDealMoniPage(self.driver)

    #风控中心-交易管理-事中监控-交易监控-个人-汇入交易监控
    def goto_risk_in_deal_monitoring_person(self):
        self._goto_risk_deal_monitoring_person()
        log.info("[emi_page] 正在进入风控中心-交易管理-事中监控-交易监控-个人-汇入交易监控页面")
        _in_deal_monitor_loc = self.base_finds(self._in_deal_monitoring_loc)[1]
        _in_deal_monitor_loc.click()
        return CRiskInDealMoniPage(self.driver)

    _risk_deal = (By.XPATH,"//span[contains(text(),'风险交易)]")
    #风控中心-交易管理-事中监控-风险交易-企业
    def _goto_risk_deal(self):
        log.info("[emi_page] 正在进入风控中心-交易管理-事中监控-风险交易-企业菜单")
        #切换iframe
        self.switch_emi_menu_frame()
        self.base_click(self._risk_center_loc)
        self.base_click(self._risk_center_deal_manage)
        self.base_click(self._deal_mid_monitoring)
        self.base_click(self._risk_deal)
        _risk_deal_company_loc = self.base_finds(self._risk_deal_monitoring_company)[4]
        _risk_deal_company_loc.click()

    #风控中心-交易管理-事中监控-风险交易-个人
    def _goto_risk_deal_person(self):
        log.info("[emi_page] 正在进入风控中心-交易管理-事中监控-风险交易-个人菜单")
        #切换iframe
        self.switch_emi_menu_frame()
        self.base_click(self._risk_center_loc)
        self.base_click(self._risk_center_deal_manage)
        self.base_click(self._deal_mid_monitoring)
        self.base_click(self._risk_deal)
        _risk_deal_person_loc = self.base_finds(self._risk_deal_monitoring_person)[4]
        _risk_deal_person_loc.click()

    _out_risk_deal_loc = (By.XPATH,"//span[contains(text(),'汇出风险交易')]")
    #风控中心-交易管理-事中监控-风险交易-企业-汇出风险交易
    def goto_risk_out_risk_deal(self):
        self._goto_risk_deal()
        log.info("[emi_page] 正在进入风控中心-交易管理-事中监控-风险交易-企业-汇出风险交易页面")
        self.base_click(self._out_risk_deal_loc)
        return RiskOutRiskDealPage(self.driver)

    #风控中心-交易管理-事中监控-风险交易-个人-汇出风险交易
    def goto_c_risk_out_risk_deal(self):
        self._goto_risk_deal_person()
        log.info("[emi_page] 正在进入风控中心-交易管理-事中监控-风险交易-个人-汇出风险交易页面")
        _out_risk_deal_query_loc =self.base_finds(self._out_risk_deal_loc)
        _out_risk_deal_query_loc.click()
        return CRiskOutRiskDealPage(self.driver)

    _in_risk_deal_loc = (By.XPATH,"//span[contains(text(),'汇入风险交易')]")
    #风控中心-交易管理-事中监控-风险交易-企业-汇出风险交易
    def goto_risk_in_risk_deal(self):
        self._goto_risk_deal()
        log.info("[emi_page] 正在进入风控中心-交易管理-事中监控-风险交易-企业-汇入风险交易页面")
        self.base_click(self._in_risk_deal_loc)
        return RiskInRiskDealPage(self.driver)

    #风控中心-交易管理-事中监控-风险交易-个人-汇入风险交易
    def goto_c_risk_in_risk_deal(self):
        self._goto_risk_deal_person()
        log.info("[emi_page] 正在进入风控中心-交易管理-事中监控-风险交易-个人-汇入风险交易页面")
        _out_risk_deal_query_loc =self.base_finds(self._out_risk_deal_loc)
        _out_risk_deal_query_loc.click()
        return CRiskInRiskDealPage(self.driver)

    _risk_center_list_manage = (By.XPATH,"//span[contains(text(),'名单管理')]")
    #风控中心-名单管理
    def _goto_risk_center_list_manage(self):
        log.info("[emi_page] 正在进入风控中心-名单管理")
        #切换iframe
        self.switch_emi_menu_frame()
        self.base_click(self._risk_center_loc)
        self.base_click(self._risk_center_list_manage)
        #todo: 企业名单也方法

    _risk_center_param_manage = (By.XPATH,"//span[contains(text(),'参数管理')]")
    #风控中心-参数管理
    def _goto_risk_center_param_manage(self):
        log.info("[emi_page] 正在进入风控中心-参数管理")
        #切换iframe
        self.switch_emi_menu_frame()
        self.base_click(self._risk_center_loc)
        self.base_click(self._risk_center_param_manage)
        #todo:参数管理下面的子页面都没写
