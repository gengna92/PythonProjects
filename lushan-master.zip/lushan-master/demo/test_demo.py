from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

from base.base import Base

class TestDemo:
    def test_demo(self):
        options = Options()
        options.add_experimental_option ("debuggerAddress", "127.0.0.1:9222")
        self.driver = webdriver.Chrome(options = options)
        _iframe_loc = self.driver.find_elements(By.CSS_SELECTOR,'.iframe')#//*[@id="pane-#CBIBANK"]/iframe
        self.driver.switch_to.frame(_iframe_loc[1])
        self.driver.find_element_by_xpath("//*[@class='el-input__inner']").click()
        # els = self.driver.find_elements_by_xpath('//li[@class="el-select-dropdown__item"]')
        # for el in els:
        #     # print(el.get_attribute("outerText"))
        #     if "SIGNATURE BANK" in el.text:
        #         el.click()
        el = self.driver.find_element_by_xpath('//li[@class="el-select-dropdown__item"]/span[contains(text(),"SIGNATURE BANK")]')
        print(el)
        self.driver.execute_script("arguments[0].click();",el)
        # # print(els)
