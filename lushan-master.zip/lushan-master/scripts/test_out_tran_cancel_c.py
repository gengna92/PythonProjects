from page.login_page import LoginPage
import pytest
from base.get_logger import GetLogger
log = GetLogger.get_logger()


class TestInterbankB2B:
    def setup_class(self):
        # 第一次实例化
        self.cbi = LoginPage().go_to_main_page().go_to_cbi_bank()

    #汇出交易-等待合规一审状态撤销
    def test_c_interbt_first_audit_refuse_flow(self):
        _order_id = "tran0021202106181720041692157"
        log.info("汇出交易-等待合规一审状态撤销流程：个人-汇出查询-撤销")
        self.cbi.goto_c_t_center_query_out_page().cancel_out(_order_id)
        log.info("汇出交易-等待合规一审状态撤销流程：交易中心个人-汇出查询-校验交易单号和'汇出汇款退回记账成功'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_order_id)
        assert res[0] == _order_id and res[1] == '撤销中'
        #运营中心-退汇交易-汇出交易退汇-待退汇
        log.info("汇出交易-BOD拒绝流程：正在运营中心-退汇交易-汇出交易退汇-待退汇-做确认")
        self.cbi.goto_operate_wait_reexchange().operate_c_wait_reexchange(_order_id).operate_out_reexchange()
        log.info("汇出交易-等待合规一审状态撤销流程：交易中心企业-汇出查询-校验交易单号和'撤销成功'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_order_id)
        assert res[0] == _order_id and res[1] == '撤销成功'
        log.info("汇出交易-等待合规一审状态撤销流程：合规中心-企业-汇出交易查询-校验交易单号和'撤销成功'状态")
        res = self.cbi.goto_c_compliance_out_query().out_query_info(_order_id)
        assert res[0] == _order_id and res[1] == '撤销成功'
        log.info("汇出交易-等待合规一审状态撤销流程：运营中心-退汇交易查询-校验交易单号和'汇出汇款退回记账成功'状态")
        res = self.cbi.goto_operate_reexchange_out().c_operate_reexchange_out(_order_id).operate_reexchange_out_detail()
        assert res[0] == _order_id and res[1] == '汇出汇款退回记账成功'

    #汇出交易-二审撤销流程
    def test_interbt_second_audit_refuse_flow(self):
        _order_id = "tran0021202106092018329187778"
        log.info("汇出交易-二审撤销流程：企业-汇出查询-校验交易单号和'等待合规一审'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_order_id)
        assert res[0] == _order_id and res[1] == '等待合规一审'
        #合规一审
        log.info("汇出交易-二审撤销流程：正在做合规一审通过")
        self.cbi.goto_c_compliance_out_first_audit().out_first_audit(_order_id).out_first_audit_pass()
        #交易中心查询-等待合规二审状态，撤销
        log.info("汇出交易-二审撤销流程：企业-汇出查询-交易中心查询-撤销")
        self.cbi.goto_c_t_center_query_out_page().cancel_out(_order_id)
        log.info("汇出交易-等待合规一审状态撤销流程：交易中心企业-汇出查询-校验交易单号和'汇出汇款退回记账成功'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_order_id)
        assert res[0] == _order_id and res[1] == '撤销中'
        #运营中心-退汇交易-汇出交易退汇-待退汇
        log.info("汇出交易-BOD拒绝流程：正在运营中心-退汇交易-汇出交易退汇-待退汇-做确认")
        self.cbi.goto_operate_wait_reexchange().operate_c_wait_reexchange(_order_id).operate_out_reexchange()
        log.info("汇出交易-等待合规一审状态撤销流程：交易中心企业-汇出查询-校验交易单号和'撤销成功'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_order_id)
        assert res[0] == _order_id and res[1] == '撤销成功'
        log.info("汇出交易-等待合规一审状态撤销流程：合规中心-企业-汇出交易查询-校验交易单号和'撤销成功'状态")
        res = self.cbi.goto_c_compliance_out_query().out_query_info(_order_id)
        assert res[0] == _order_id and res[1] == '撤销成功'
        log.info("汇出交易-等待合规一审状态撤销流程：运营中心-退汇交易查询-校验交易单号和'汇出汇款退回记账成功'状态")
        res = self.cbi.goto_operate_reexchange_out().c_operate_reexchange_out(_order_id).operate_reexchange_out_detail()
        assert res[0] == _order_id and res[1] == '汇出汇款退回记账成功'


    #汇出交易-BOD撤销流程
    def test_interbt_BOD_refuse_flow(self):
        _order_id = "tran0021202106092018329187778"
        log.info("汇出交易-BOD撤销流程：企业-汇出查询-校验交易单号和'等待合规一审'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_order_id)
        assert res[0] == _order_id and res[1] == '等待合规一审'
        #合规一审拒绝
        log.info("汇出交易-BOD撤销流程：正在做合规一审通过")
        self.cbi.goto_c_compliance_out_first_audit().out_first_audit(_order_id).out_first_audit_pass()
        #交易中心查询
        log.info("汇出交易-BOD撤销流程：企业-汇出查询-校验交易单号和''等待合规二审'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_order_id)
        assert res[0] == _order_id #and res[1] == '等待合规二审'
        #合规二审的时候选BOD
        log.info("汇出交易-BOD撤销流程：正在做合规二审选择BOD")
        self.cbi.goto_c_compliance_out_second_audit().out_second_audit(_order_id).out_second_audit_bod()
        #交易中心查询-等待BOD审核，撤销
        log.info("汇出交易-BOD撤销流程：企业-汇出查询-交易中心查询-撤销")
        self.cbi.goto_c_t_center_query_out_page().cancel_out(_order_id)
        log.info("汇出交易-等待合规一审状态撤销流程：交易中心企业-汇出查询-校验交易单号和'汇出汇款退回记账成功'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_order_id)
        assert res[0] == _order_id and res[1] == '撤销中'
        #运营中心-退汇交易-汇出交易退汇-待退汇
        log.info("汇出交易-BOD拒绝流程：正在运营中心-退汇交易-汇出交易退汇-待退汇-做确认")
        self.cbi.goto_operate_wait_reexchange().operate_c_wait_reexchange(_order_id).operate_out_reexchange()
        log.info("汇出交易-等待合规一审状态撤销流程：交易中心企业-汇出查询-校验交易单号和'撤销成功'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_order_id)
        assert res[0] == _order_id and res[1] == '撤销成功'
        log.info("汇出交易-等待合规一审状态撤销流程：合规中心-企业-汇出交易查询-校验交易单号和'撤销成功'状态")
        res = self.cbi.goto_c_compliance_out_query().out_query_info(_order_id)
        assert res[0] == _order_id and res[1] == '撤销成功'
        log.info("汇出交易-等待合规一审状态撤销流程：运营中心-退汇交易查询-校验交易单号和'汇出汇款退回记账成功'状态")
        res = self.cbi.goto_operate_reexchange_out().c_operate_reexchange_out(_order_id).operate_reexchange_out_detail()
        assert res[0] == _order_id and res[1] == '汇出汇款退回记账成功'


    def teardown_class(self):
        self.cbi.quit()


