import time

from page.login_page import LoginPage
import pytest
from base.get_logger import GetLogger
log = GetLogger.get_logger()


class TestInterbankB2B:
    def setup_class(self):
        # 第一次实例化
        self.cbi = LoginPage().go_to_main_page().go_to_cbi_bank()

    #汇入USD成功
    def test_trans_in_b2b_usd_success_flow(self):
        _usd_order_id = "tran0011202106231524445155268"
        _apply_id = '100000000000000884'
        # 合规中心-企业-汇入交易-交易关联
        self.cbi.goto_compliance_in_deal_relate().in_conne_tran(_usd_order_id).in_conne_tran(_apply_id)
        # 运营中心-汇入交易-标准类汇入-汇入挂账，挂账
        self.cbi.goto_operate_in_stand_suspense_account().suspense_account_detail(_usd_order_id).do_suspense_account(_usd_order_id)
        # 等道琼斯
        time.sleep(60)
        log.info("B2B跨行转账汇入usd流程：企业-汇入查询-校验交易单号和'等待合规一审'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_usd_order_id).detail()
        assert res[0] == _usd_order_id and res[1] == '等待合规一审'
        # 合规一审
        log.info("B2B跨行转账汇入usd流程：正在做合规一审")
        self.cbi.goto_compliance_in_first_audit().in_first_audit(_usd_order_id).in_first_audit_pass()
        # 交易中心-汇入交易查询校验状态
        log.info("B2B跨行转账汇入usd流程：合规一审后交易中心-汇入交易查询校验，交易单号和'等待合规二审'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_usd_order_id).detail()
        assert res[0] == _usd_order_id and res[1] == '等待合规二审'
        #合规二审
        log.info("B2B跨行转账汇入usd流程：正在做合规二审")
        self.cbi.goto_compliance_in_second_audit().in_second_audit(_usd_order_id).in_second_audit_pass()
        #交易中心-汇入交易查询校验状态
        log.info("B2B跨行转账汇入usd流程：合规二审后交易中心-汇入交易查询校验，交易单号和'审核通过等待汇出'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_usd_order_id).detail()
        assert res[0] == _usd_order_id and res[1] == '审核通过等待记账'
        # 运营中心-汇入交易-标准类汇入-汇入入账
        log.info("B2B跨行转账汇入usd流程：正在运营中心-汇入交易-标准类汇入-汇入入账")
        self.cbi.goto_operate_in_stand_carry_to().carry_to_detail(_usd_order_id).do_carry_to()
        # #交易中心-汇入交易查询校验状态
        # log.info("B2B跨行转账汇入usd流程：待汇入确认后交易中心-汇入交易查询校验，交易单号和'核心记账成功'状态")
        # res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_usd_order_id).detail()
        # assert res[0] == _usd_order_id and res[1] == '核心记账成功'
        # #运营中心-汇入交易-标准类汇入—汇入交易
        # log.info("B2B跨行转账汇入usd流程：正在运营中心-汇入交易-标准类汇入—汇入交易")
        # res = self.cbi.goto_operate_in_stand_tran_in().tran_in_detail(_usd_order_id)
        # assert res[0] == _usd_order_id and res[1] == '核心记账成功'
        # #合规中心/企业/汇入交易/汇入交易查询
        # log.info("B2B跨行转账汇入usd流程：合规中心/企业/汇入交易/汇入交易查询，查询合规订单状态为【核心记账成功】")
        # res = self.cbi.goto_compliance_in_query().in_query_info(_usd_order_id)
        # assert res[0] == _usd_order_id and res[1] == '核心记账成功'




    #交易中心-跨行汇出bod审核通过
    def test_inter_bank_b2b_bod_success_flow(self):
        _usd_order_id = "tran0011202106231524445155268"
        _apply_id = '100000000000000884'
        # 合规中心-企业-汇入交易-交易关联
        self.cbi.goto_compliance_in_deal_relate().in_conne_tran(_usd_order_id).in_conne_tran(_apply_id)
        # 运营中心-汇入交易-标准类汇入-汇入挂账，挂账
        self.cbi.goto_operate_in_stand_suspense_account().suspense_account_detail(_usd_order_id).do_suspense_account(_usd_order_id)
        # 等道琼斯
        time.sleep(60)
        log.info("B2B跨行转账汇入usd流程：企业-汇入查询-校验交易单号和'等待合规一审'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_usd_order_id).detail()
        assert res[0] == _usd_order_id and res[1] == '等待合规一审'
        # 合规一审
        log.info("B2B跨行转账汇入usd流程：正在做合规一审")
        self.cbi.goto_compliance_in_first_audit().in_first_audit(_usd_order_id).in_first_audit_pass()
        # 交易中心-汇入交易查询校验状态
        log.info("B2B跨行转账汇入usd流程：合规一审后交易中心-汇入交易查询校验，交易单号和'等待合规二审'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_usd_order_id).detail()
        assert res[0] == _usd_order_id and res[1] == '等待合规二审'
        #合规二审-选BOD
        log.info("B2B跨行转账汇入usd流程：合规2审选择BOD")
        self.cbi.goto_compliance_in_second_audit().in_second_audit(_usd_order_id).in_second_audit_bod()
        #交易中心-汇入交易查询校验状态
        log.info("B2B跨行转账汇入usd流程：合规二审后交易中心-汇入交易查询校验，交易单号和'等待BOD审核'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_usd_order_id).detail()
        assert res[0] == _usd_order_id and res[1] == '等待BOD审核'
        log.info("B2B跨行转账汇入usd流程：正在做BOD审核通过")
        self.cbi.goto_compliance_in_bod().in_bod_audit(_usd_order_id).bod_audit_pass()
        #交易中心-汇入交易查询校验状态
        log.info("B2B跨行转账汇入usd流程：合规二审后交易中心-汇入交易查询校验，交易单号和'审核通过等待汇出'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_usd_order_id).detail()
        assert res[0] == _usd_order_id and res[1] == '审核通过等待记账'
        # 运营中心-汇入交易-标准类汇入-汇入入账
        log.info("B2B跨行转账汇入usd流程：正在运营中心-汇入交易-标准类汇入-汇入入账")
        self.cbi.goto_operate_in_stand_carry_to().carry_to_detail(_usd_order_id).do_carry_to()
        #TODO：等着核心记账成功才能改变状态，还是系统有问题?要等挺久的不等了
        #交易中心-汇入交易查询校验状态
        # log.info("B2B跨行转账汇入usd流程：待汇入确认后交易中心-汇入交易查询校验，交易单号和'核心记账成功'状态")
        # res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_usd_order_id).detail()
        # assert res[0] == _usd_order_id and res[1] == '核心记账成功'
        # #运营中心-汇入交易-标准类汇入—汇入交易
        # log.info("B2B跨行转账汇入usd流程：正在运营中心-汇入交易-标准类汇入—汇入交易")
        # res = self.cbi.goto_operate_in_stand_tran_in().tran_in_detail(_usd_order_id)
        # assert res[0] == _usd_order_id and res[1] == '核心记账成功'
        # #合规中心/企业/汇入交易/汇入交易查询
        # log.info("B2B跨行转账汇入usd流程：合规中心/企业/汇入交易/汇入交易查询，查询合规订单状态为【核心记账成功】")
        # res = self.cbi.goto_compliance_in_query().in_query_info(_usd_order_id)
        # assert res[0] == _usd_order_id and res[1] == '核心记账成功'


    # def teardown_class(self):
    #     self.cbi.quit()

