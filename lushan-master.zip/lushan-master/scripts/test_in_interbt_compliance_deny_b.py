import time

from page.login_page import LoginPage
import pytest
from base.get_logger import GetLogger
log = GetLogger.get_logger()


class TestInterbankB2B:
    def setup_class(self):
        # 第一次实例化
        self.cbi = LoginPage().go_to_main_page().go_to_cbi_bank()

    #汇出交易-一审拒绝流程
    def test_interbt_first_audit_refuse_flow(self):
        _usd_order_id = "tran0011202106231524445155268"
        _apply_id = '100000000000000884'
        # 合规中心-企业-汇入交易-交易关联
        self.cbi.goto_compliance_in_deal_relate().in_conne_tran(_usd_order_id).in_conne_tran(_apply_id)
        # 运营中心-汇入交易-标准类汇入-汇入挂账，挂账
        self.cbi.goto_operate_in_stand_suspense_account().suspense_account_detail(_usd_order_id).do_suspense_account(_usd_order_id)
        # 等道琼斯
        time.sleep(60)
        log.info("B2B跨行转账汇入usd流程：企业-汇入查询-校验交易单号和'等待合规一审'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_usd_order_id).detail()
        assert res[0] == _usd_order_id and res[1] == '等待合规一审'
        # 合规一审
        log.info("B2B跨行转账汇入usd流程：正在做合规一审")
        self.cbi.goto_compliance_in_first_audit().in_first_audit(_usd_order_id).in_first_audit_refuse()
        #交易中心查询
        log.info("汇入交易-一审拒绝流程：企业-汇入查询-校验交易单号和'合规拒绝'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_usd_order_id).detail()
        assert res[0] == _usd_order_id and res[1] == '合规拒绝'
        #交易中心-退汇交易-汇入交易退汇-待退汇
        self.cbi.goto_c_t_center_in_reexc_page().in_wait_reexchange(_usd_order_id).operate_in_reexchange()
        #合规中心-退汇交易-汇入交易退汇-汇入待退汇
        self.cbi.goto_compliance_in_wait_reexchange().in_wait_reexchange(_usd_order_id).operate_in_reexchange()
        #运营中心-退汇交易-汇入交易退汇-待退汇
        log.info("汇入交易-一审拒绝流程：正在运营中心-退汇交易-汇入交易退汇-待退汇")
        self.cbi.goto_operate_wait_reexchange_in().operate_wait_reexchange(_usd_order_id).operate_in_reexchange()
        log.info("汇入交易-一审拒绝流程：交易中心企业-汇出查询-校验交易单号和'汇出汇款退回记账成功'状态")
        res = self.cbi.goto_t_center_query_out_page().query_out_detail(_order_id_01)
        assert res[0] == _order_id_01 and res[1] == '汇出汇款退回记账成功'
        log.info("汇出交易-一审拒绝流程：合规中心-企业-汇出交易查询-校验交易单号和'汇出汇款退回记账成功'状态")
        res = self.cbi.goto_compliance_out_query().out_query_info(_order_id_01)
        assert res[0] == _order_id_01 and res[1] == '汇出汇款退回记账成功'
        log.info("汇出交易-一审拒绝流程：运营中心-退汇交易查询-校验交易单号和'汇出汇款退回记账成功'状态")
        res = self.cbi.goto_operate_reexchange_out().operate_reexchange_out(_order_id_01).operate_reexchange_out_detail()
        assert res[0] == _order_id_01 and res[1] == '汇出汇款退回记账成功'

    _order_id_02 = "tran0021202105232330001613442"
    #汇出交易-二审拒绝流程
    def test_interbt_second_audit_refuse_flow(self):
        log.info("汇出交易-二审拒绝流程：企业-汇出查询-校验交易单号和'等待合规一审'状态")
        res = self.cbi.goto_t_center_query_out_page().query_out_detail(self._order_id_02)
        assert res[0] == self._order_id_02 and res[1] == '等待合规一审'
        #合规一审拒绝
        log.info("汇出交易-二审拒绝流程：正在做合规一审通过")
        self.cbi.goto_compliance_out_first_audit().out_first_audit(self._order_id_02).out_first_audit_pass()
        #交易中心查询
        log.info("汇出交易-二审拒绝流程：企业-汇出查询-校验交易单号和'合规拒绝'状态")
        res = self.cbi.goto_t_center_query_out_page().query_out_detail(self._order_id_02)
        assert res[0] == self._order_id_02 and res[1] == '等待合规二审'
        #合规二审拒绝
        log.info("汇出交易-二审拒绝流程：正在做合规二审拒绝")
        self.cbi.goto_compliance_out_second_audit().out_second_audit(self._order_id_02).out_second_audit_refuse()
        #运营中心-退汇交易-汇出交易退汇-待退汇
        log.info("汇出交易-二审拒绝流程：正在运营中心-退汇交易-汇出交易退汇-待退汇-做确认")
        self.cbi.goto_operate_wait_reexchange().operate_wait_reexchange(self._order_id_02).operate_out_reexchange()
        log.info("汇出交易-二审拒绝流程：交易中心企业-汇出查询-校验交易单号和'汇出汇款退回记账成功'状态")
        res = self.cbi.goto_t_center_query_out_page().query_out_detail(self._order_id_02)
        assert res[0] == self._order_id_02 and res[1] == '汇出汇款退回记账成功'
        log.info("汇出交易-二审拒绝流程：合规中心-企业-汇出交易查询-校验交易单号和'汇出汇款退回记账成功'状态")
        res = self.cbi.goto_compliance_out_query().out_query_info(self._order_id_02)
        assert res[0] == self._order_id_02 and res[1] == '汇出汇款退回记账成功'
        log.info("汇出交易-二审拒绝流程：运营中心-退汇交易查询-校验交易单号和'汇出汇款退回记账成功'状态")
        res = self.cbi.goto_operate_reexchange_out().operate_reexchange_out(self._order_id_02).operate_reexchange_out_detail()
        assert res[0] == self._order_id_02 and res[1] == '汇出汇款退回记账成功'

    _order_id_03 = "tran0021202105232330001613442"

    #汇出交易-BOD拒绝流程
    def test_interbt_BOD_refuse_flow(self):
        log.info("汇出交易-BOD拒绝流程：企业-汇出查询-校验交易单号和'等待合规一审'状态")
        res = self.cbi.goto_t_center_query_out_page().query_out_detail(self._order_id_03)
        assert res[0] == self._order_id_03 and res[1] == '等待合规一审'
        #合规一审拒绝
        log.info("汇出交易-BOD拒绝流程：正在做合规一审通过")
        self.cbi.goto_compliance_out_first_audit().out_first_audit(self._order_id_03).out_first_audit_pass()
        #交易中心查询
        log.info("汇出交易-BOD拒绝流程：企业-汇出查询-校验交易单号和'合规拒绝'状态")
        res = self.cbi.goto_t_center_query_out_page().query_out_detail(self._order_id_03)
        assert res[0] == self._order_id_03 and res[1] == '等待合规二审'
        #合规二审的时候选BOD
        log.info("汇出交易-BOD拒绝流程：正在做合规二审选择BOD")
        self.cbi.goto_compliance_out_second_audit().out_second_audit(self._order_id_03).out_second_audit_bod()
        #BOD处理
        log.info("汇出交易-BOD拒绝流程：正在做BOD拒绝")
        self.cbi.goto_compliance_out_bod().out_bod_audit(self._order_id_03).bod_audit_refuse()
        #运营中心-退汇交易-汇出交易退汇-待退汇
        log.info("汇出交易-BOD拒绝流程：正在运营中心-退汇交易-汇出交易退汇-待退汇-做确认")
        self.cbi.goto_operate_wait_reexchange().operate_wait_reexchange(self._order_id_03).operate_out_reexchange()
        log.info("汇出交易-BOD拒绝流程：交易中心企业-汇出查询-校验交易单号和'汇出汇款退回记账成功'状态")
        res = self.cbi.goto_t_center_query_out_page().query_out_detail(self._order_id_03)
        assert res[0] == self._order_id_03 and res[1] == '汇出汇款退回记账成功'
        log.info("汇出交易-BOD拒绝流程：合规中心-企业-汇出交易查询-校验交易单号和'汇出汇款退回记账成功'状态")
        res = self.cbi.goto_compliance_out_query().out_query_info(self._order_id_03)
        assert res[0] == self._order_id_03 and res[1] == '汇出汇款退回记账成功'
        log.info("汇出交易-BOD拒绝流程：运营中心-退汇交易查询-校验交易单号和'汇出汇款退回记账成功'状态")
        res = self.cbi.goto_operate_reexchange_out().operate_reexchange_out(self._order_id_03).operate_reexchange_out_detail()
        assert res[0] == self._order_id_03 and res[1] == '汇出汇款退回记账成功'


    # def teardown_class(self):
    #     self.cbi.quit()


