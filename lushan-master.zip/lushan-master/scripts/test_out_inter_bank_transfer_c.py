from page.login_page import LoginPage
import pytest
from base.get_logger import GetLogger
log = GetLogger.get_logger()


class TestInterbankB2B:
    def setup_class(self):
        # 第一次实例化
        self.cbi = LoginPage().go_to_main_page().go_to_cbi_bank()



    #交易中心-跨行汇出USD-C2C成功
    def test_inter_bank_c2c_usd_success_flow(self):
        _usd_order_id = "tran0021202106181650107913974"
        log.info("B2B跨行转账汇出usd流程：企业-汇出查询-校验交易单号和'等待合规一审'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_usd_order_id)
        assert res[0] == _usd_order_id and res[1] == '等待合规一审'
        #合规一审
        log.info("B2B跨行转账汇出usd流程：正在做合规一审")
        self.cbi.goto_c_compliance_out_first_audit().out_first_audit(_usd_order_id).out_first_audit_pass()
        #交易中心-汇出交易查询校验状态
        log.info("B2B跨行转账汇出usd流程：合规一审后交易中心-汇出交易查询校验，交易单号和'等待合规二审'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_usd_order_id)
        assert res[0] == _usd_order_id and res[1] == '等待合规二审'
        #合规二审
        log.info("B2B跨行转账汇出usd流程：正在做合规二审")
        self.cbi.goto_c_compliance_out_second_audit().out_second_audit(_usd_order_id).out_second_audit_pass()
        #交易中心-汇出交易查询校验状态
        log.info("B2B跨行转账汇出usd流程：合规二审后交易中心-汇出交易查询校验，交易单号和'审核通过等待汇出'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_usd_order_id)
        assert res[0] == _usd_order_id and res[1] == '审核通过等待汇出'
        #运营中心-汇出交易-待汇出-做确认
        log.info("B2B跨行转账汇出usd流程：正在运营中心-汇出交易-待汇出-做确认")
        self.cbi.goto_operate_out_wait_out().c_out_wait_out(_usd_order_id).out_wait_audit_USD_pass()
        #交易中心-汇出交易查询校验状态
        log.info("B2B跨行转账汇出usd流程：待汇出确认后交易中心-汇出交易查询校验，交易单号和'已汇出等待确认'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_usd_order_id)
        assert res[0] == _usd_order_id and res[1] == '已汇出等待确认'
        #运营中心-汇出交易-汇出交易-做汇出确认
        log.info("B2B跨行转账汇出usd流程：正在运营中心-汇出交易-汇出交易-做汇出确认")
        self.cbi.goto_operate_out_trans_out().c_out_trans_out(_usd_order_id).out_trans_out_success()
        #交易中心-汇出交易查询校验状态
        log.info("B2B跨行转账汇出usd流程：汇出确认后交易中心-汇出交易查询校验，交易单号和'已汇出等待确认'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_usd_order_id)
        assert res[0] == _usd_order_id and res[1] == '已汇出等待确认'
        #运营中心-汇出交易-汇出交易-做核心记账确认
        log.info("B2B跨行转账汇出usd流程：正在运营中心-汇出交易-汇出交易-做核心记账确认")
        self.cbi.goto_operate_out_trans_out().c_out_trans_out(_usd_order_id).core_accounting_ensure()
    def test_inter_bank_c2c_usd_success_flow_01(self):
        _usd_order_id = "tran0021202106181650107913974"
        #庐山-合规中心-企业-汇出交易-汇出交易查询，查询合规订单状态为【汇出记账成功】
        log.info("B2B跨行转账汇出usd流程：庐山-合规中心-企业-汇出交易-汇出交易查询，查询合规订单状态为【汇出记账成功】")
        res = self.cbi.goto_c_compliance_out_query().out_query_info(_usd_order_id)
        assert res[0] == _usd_order_id and res[1] == '汇出记账成功'
        #庐山-风控中心-交易管理-事中监控-交易监控-企业-汇出交易监控，查询风控订单状态为【汇出记账成功】
        # log.info("B2B跨行转账汇出usd流程：庐山-风控中心-交易管理-事中监控-交易监控-企业-汇出交易监控，查询风控订单状态为【汇出记账成功】")
        # res = self.cbi.goto_risk_out_deal_monitoring().query(_usd_order_id)
        # assert res[0] == '汇出记账成功'

    #交易中心-跨行汇出EUR-c2c成功
    def test_inter_bank_c2c_eur_success_flow(self):
        _eur_order_id = "tran0021202104281600029779128"
        log.info("B2B跨行转账汇出usd流程：企业-汇出查询-校验交易单号和'等待合规一审'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_eur_order_id)
        assert res[0] == _eur_order_id and res[1] == '等待合规一审'
        #合规一审
        log.info("B2B跨行转账汇出usd流程：正在做合规一审")
        self.cbi.goto_c_compliance_out_first_audit().out_first_audit(_eur_order_id).out_first_audit_pass()
        #交易中心-汇出交易查询校验状态
        log.info("B2B跨行转账汇出usd流程：合规一审后交易中心-汇出交易查询校验，交易单号和'等待合规二审'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_eur_order_id)
        assert res[0] == _eur_order_id and res[1] == '等待合规二审'
        #合规二审
        log.info("B2B跨行转账汇出usd流程：正在做合规二审")
        self.cbi.goto_c_compliance_out_second_audit().out_second_audit(_eur_order_id).out_second_audit_pass()
        #交易中心-汇出交易查询校验状态
        log.info("B2B跨行转账汇出usd流程：合规二审后交易中心-汇出交易查询校验，交易单号和'审核通过等待汇出'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_eur_order_id)
        assert res[0] == _eur_order_id and res[1] == '审核通过等待汇出'
        #运营中心-汇出交易-待汇出-做确认
        log.info("B2B跨行转账汇出usd流程：正在运营中心-汇出交易-待汇出-做确认")
        self.cbi.goto_operate_out_wait_out().c_out_wait_out(_eur_order_id).out_wait_audit_EUR_pass()
        #交易中心-汇出交易查询校验状态
        log.info("B2B跨行转账汇出usd流程：待汇出确认后交易中心-汇出交易查询校验，交易单号和'已汇出等待确认'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_eur_order_id)
        assert res[0] == _eur_order_id and res[1] == '已汇出等待确认'
        #运营中心-汇出交易-汇出交易-做汇出确认
        log.info("B2B跨行转账汇出usd流程：正在运营中心-汇出交易-汇出交易-做汇出确认")
        self.cbi.goto_operate_out_trans_out().c_out_trans_out(_eur_order_id).out_trans_out_success()
        #交易中心-汇出交易查询校验状态
        log.info("B2B跨行转账汇出usd流程：汇出确认后交易中心-汇出交易查询校验，交易单号和'已汇出等待确认'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_eur_order_id)
        assert res[0] == _eur_order_id and res[1] == '已汇出等待确认'
        #运营中心-汇出交易-汇出交易-做核心记账确认
        log.info("B2B跨行转账汇出usd流程：正在运营中心-汇出交易-汇出交易-做核心记账确认")
        self.cbi.goto_operate_out_trans_out().c_out_trans_out(_eur_order_id).core_accounting_ensure()
        #庐山-合规中心-企业-汇出交易-汇出交易查询，查询合规订单状态为【汇出记账成功】
        log.info("B2B跨行转账汇出usd流程：庐山-合规中心-企业-汇出交易-汇出交易查询，查询合规订单状态为【汇出记账成功】")
        res = self.cbi.goto_c_compliance_out_query().out_query_info(_eur_order_id)
        assert res[0] == _eur_order_id and res[1] == '汇出记账成功'

    #交易中心-跨行汇出EUR-c2c成功
    def test_inter_bank_c2c_cny_success_flow(self):
        _cny_order_id = "tran0021202104281600029779128"
        log.info("B2B跨行转账汇出usd流程：企业-汇出查询-校验交易单号和'等待合规一审'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_cny_order_id)
        assert res[0] == _cny_order_id and res[1] == '等待合规一审'
        #合规一审
        log.info("B2B跨行转账汇出usd流程：正在做合规一审")
        self.cbi.goto_c_compliance_out_first_audit().out_first_audit(_cny_order_id).out_first_audit_pass()
        #交易中心-汇出交易查询校验状态
        log.info("B2B跨行转账汇出usd流程：合规一审后交易中心-汇出交易查询校验，交易单号和'等待合规二审'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_cny_order_id)
        assert res[0] == _cny_order_id and res[1] == '等待合规二审'
        #合规二审
        log.info("B2B跨行转账汇出usd流程：正在做合规二审")
        self.cbi.goto_c_compliance_out_second_audit().out_second_audit(_cny_order_id).out_second_audit_pass()
        #交易中心-汇出交易查询校验状态
        log.info("B2B跨行转账汇出usd流程：合规二审后交易中心-汇出交易查询校验，交易单号和'审核通过等待汇出'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_cny_order_id)
        assert res[0] == _cny_order_id and res[1] == '审核通过等待汇出'
        #运营中心-汇出交易-待汇出-做确认
        log.info("B2B跨行转账汇出usd流程：正在运营中心-汇出交易-待汇出-做确认")
        self.cbi.goto_operate_out_wait_out().c_out_wait_out(_cny_order_id).out_wait_audit_CNY_pass()
        #交易中心-汇出交易查询校验状态
        log.info("B2B跨行转账汇出usd流程：待汇出确认后交易中心-汇出交易查询校验，交易单号和'已汇出等待确认'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_cny_order_id)
        assert res[0] == _cny_order_id and res[1] == '已汇出等待确认'
        #运营中心-汇出交易-汇出交易-做汇出确认
        log.info("B2B跨行转账汇出usd流程：正在运营中心-汇出交易-汇出交易-做汇出确认")
        self.cbi.goto_operate_out_trans_out().c_out_trans_out(_cny_order_id).out_trans_out_success()
        #交易中心-汇出交易查询校验状态
        log.info("B2B跨行转账汇出usd流程：汇出确认后交易中心-汇出交易查询校验，交易单号和'已汇出等待确认'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_cny_order_id)
        assert res[0] == _cny_order_id and res[1] == '已汇出等待确认'
        #运营中心-汇出交易-汇出交易-做核心记账确认
        log.info("B2B跨行转账汇出usd流程：正在运营中心-汇出交易-汇出交易-做核心记账确认")
        self.cbi.goto_operate_out_trans_out().c_out_trans_out(_cny_order_id).core_accounting_ensure()
        #庐山-合规中心-企业-汇出交易-汇出交易查询，查询合规订单状态为【汇出记账成功】
        log.info("B2B跨行转账汇出usd流程：庐山-合规中心-企业-汇出交易-汇出交易查询，查询合规订单状态为【汇出记账成功】")
        res = self.cbi.goto_c_compliance_out_query().out_query_info(_cny_order_id)
        assert res[0] == _cny_order_id and res[1] == '汇出记账成功'

    #交易中心-跨行汇出bod审核通过
    def test_inter_bank_c2c_bod_success_flow(self):
        _bod_order_id = ''
        log.info("B2B跨行转账汇出usd流程：企业-汇出查询-校验交易单号和'等待合规一审'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_bod_order_id)
        assert res[0] == _bod_order_id and res[1] == '等待合规一审'
        #合规一审
        log.info("B2B跨行转账汇出usd流程：正在做合规一审")
        self.cbi.goto_c_compliance_out_first_audit().out_first_audit(_bod_order_id).out_first_audit_pass()
        #交易中心-汇出交易查询校验状态
        log.info("B2B跨行转账汇出usd流程：合规一审后交易中心-汇出交易查询校验，交易单号和'等待合规二审'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_bod_order_id)
        assert res[0] == _bod_order_id and res[1] == '等待合规二审'
        #合规二审
        log.info("B2B跨行转账汇出usd流程：正在做合规二审")
        self.cbi.goto_c_compliance_out_second_audit().out_second_audit(_bod_order_id).out_second_audit_bod()
        #交易中心-汇出交易查询校验状态
        log.info("B2B跨行转账汇出usd流程：合规二审后交易中心-汇出交易查询校验，交易单号和'等待BOD审核'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_bod_order_id)
        assert res[0] == _bod_order_id and res[1] == '等待BOD审核'
        #bod通过
        log.info("B2B跨行转账汇出usd流程：正在做bod审核通过")
        self.cbi.goto_c_compliance_out_bod().out_bod_audit(_bod_order_id).bod_audit_pass()
        #交易中心-汇出交易查询校验状态
        log.info("B2B跨行转账汇出usd流程：待汇出确认后交易中心-汇出交易查询校验，交易单号和'已汇出等待确认'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_bod_order_id)
        assert res[0] == _bod_order_id and res[1] == '已汇出等待确认'
        #运营中心-汇出交易-待汇出-做确认
        log.info("B2B跨行转账汇出usd流程：正在运营中心-汇出交易-待汇出-做确认")
        self.cbi.goto_operate_out_wait_out().c_out_wait_out(_bod_order_id).out_wait_audit_USD_pass()
        #交易中心-汇出交易查询校验状态
        log.info("B2B跨行转账汇出usd流程：BOD后交易中心-汇出交易查询校验，交易单号和'审核通过等待汇出'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_bod_order_id)
        assert res[0] == _bod_order_id and res[1] == '审核通过等待汇出'
        #运营中心-汇出交易-汇出交易-做汇出确认
        log.info("B2B跨行转账汇出usd流程：正在运营中心-汇出交易-汇出交易-做汇出确认")
        self.cbi.goto_operate_out_trans_out().c_out_trans_out(_bod_order_id).out_trans_out_success()
        #交易中心-汇出交易查询校验状态
        log.info("B2B跨行转账汇出usd流程：汇出确认后交易中心-汇出交易查询校验，交易单号和'已汇出等待确认'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_bod_order_id)
        assert res[0] == _bod_order_id and res[1] == '已汇出等待确认'
        #运营中心-汇出交易-汇出交易-做核心记账确认
        log.info("B2B跨行转账汇出usd流程：正在运营中心-汇出交易-汇出交易-做核心记账确认")
        self.cbi.goto_operate_out_trans_out().c_out_trans_out(_bod_order_id).core_accounting_ensure()
        #庐山-合规中心-企业-汇出交易-汇出交易查询，查询合规订单状态为【汇出记账成功】
        log.info("B2B跨行转账汇出usd流程：庐山-合规中心-企业-汇出交易-汇出交易查询，查询合规订单状态为【汇出记账成功】")
        res = self.cbi.goto_c_compliance_out_query().out_query_info(_bod_order_id)
        assert res[0] == _bod_order_id and res[1] == '汇出记账成功'


    def test_inter_bank_c2c_fail_flow(self):
        _fail_order_id = "tran0021202106181720032256824"
        log.info("B2B跨行转账汇出流程：企业-汇出查询-校验交易单号和'等待合规一审'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_fail_order_id)
        assert res[0] == _fail_order_id and res[1] == '等待合规一审'
        #合规一审
        log.info("B2B跨行转账汇出流程：正在做合规一审")
        self.cbi.goto_c_compliance_out_first_audit().out_first_audit(_fail_order_id).out_first_audit_pass()
        #交易中心-汇出交易查询校验状态
        log.info("B2B跨行转账汇出流程：合规一审后交易中心-汇出交易查询校验，交易单号和'等待合规二审'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_fail_order_id)
        assert res[0] == _fail_order_id and res[1] == '等待合规二审'
        #合规二审
        log.info("B2B跨行转账汇出流程：正在做合规二审")
        self.cbi.goto_c_compliance_out_second_audit().out_second_audit(_fail_order_id).out_second_audit_pass()
        #交易中心-汇出交易查询校验状态
        log.info("B2B跨行转账汇出流程：合规二审后交易中心-汇出交易查询校验，交易单号和'审核通过等待汇出'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_fail_order_id)
        assert res[0] == _fail_order_id and res[1] == '审核通过等待汇出'
        #运营中心-汇出交易-待汇出-做确认
        log.info("B2B跨行转账汇出流程：正在运营中心-汇出交易-待汇出-做确认")
        self.cbi.goto_operate_out_wait_out().c_out_wait_out(_fail_order_id).out_wait_audit_USD_pass()
        #交易中心-汇出交易查询校验状态
        log.info("B2B跨行转账汇出流程：待汇出确认后交易中心-汇出交易查询校验，交易单号和'已汇出等待确认'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_fail_order_id)
        assert res[0] == _fail_order_id and res[1] == '已汇出等待确认'
        #运营中心-汇出交易-汇出交易-做汇出失败操作
        log.info("B2B跨行转账汇出流程：正在运营中心-汇出交易-汇出交易-做汇出失败操作")
        self.cbi.goto_operate_out_trans_out().c_out_trans_out(_fail_order_id).out_trans_out_fail()
        #交易中心-汇出交易查询校验状态
        log.info("B2B跨行转账汇出流程：汇出确认后交易中心-汇出交易查询校验，交易单号和'已汇出等待确认'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(_fail_order_id)
        assert res[0] == _fail_order_id and res[1] == '汇出汇款退回记账成功'
        #交易中心-企业-退汇交易-汇出交易退汇-退汇交易查询
        res = self.cbi.goto_c_t_center_out_reexc_page().out_reexchange_query(_fail_order_id).detail_query()
        assert res[0] == _fail_order_id and res[1] == '汇出汇款退回记账成功'
        #运营中心-退汇交易-汇出交易退汇-退汇交易查询
        res = self.cbi.goto_operate_reexchange_out().c_operate_reexchange_out(_fail_order_id).operate_reexchange_out_detail()
        assert res[0] == _fail_order_id and res[1] == '汇出汇款退回记账成功'
        log.info("B2B跨行转账汇出usd流程：庐山-合规中心-企业-汇出交易-汇出交易查询，查询合规订单状态为【汇出记账成功】")
        res = self.cbi.goto_c_compliance_out_query().out_query_info(_fail_order_id)
        assert res[0] == _fail_order_id and res[1] == '汇出汇款退回记账成功'


    # def teardown_class(self):
    #     self.cbi.quit()

