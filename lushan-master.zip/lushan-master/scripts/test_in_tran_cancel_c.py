from page.login_page import LoginPage
import pytest
from base.get_logger import GetLogger
log = GetLogger.get_logger()


class TestInTranCancelB:
    def setup_class(self):
        # 第一次实例化
        self.cbi = LoginPage().go_to_main_page().go_to_cbi_bank()

    #汇入交易-等待合规一审状态退汇
    def test_interbt_first_audit_cancel_flow(self):
        _order_id = "tran0021202106181720041692157"
        log.info("汇入交易-等待合规一审状态退汇流程：企业-汇入查询-退汇")
        self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_order_id).reexchange()
        log.info("汇入交易-等待合规一审状态退汇流程：交易中心企业-汇入查询-校验交易单号和'汇入汇款退回记账成功'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_order_id).query_in_detail()
        assert res[0] == _order_id and res[1] == '撤销中'
        #运营中心-退汇交易-汇入交易退汇-待退汇
        log.info("汇入交易-等待合规一审状态退汇流程：正在运营中心-退汇交易-汇入交易退汇-待退汇-做确认")
        self.cbi.goto_operate_wait_reexchange_in().operate_wait_reexchange(_order_id).operate_in_reexchange()
        log.info("汇入交易-等待合规一审状态退汇流程：交易中心企业-汇入查询-校验交易单号和'撤销成功'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_order_id).query_in_detail()
        assert res[0] == _order_id and res[1] == '撤销成功'
        log.info("汇入交易-等待合规一审状态退汇流程：合规中心-企业-汇入交易查询-校验交易单号和'撤销成功'状态")
        res = self.cbi.goto_compliance_in_query().in_query_info(_order_id)
        assert res[0] == _order_id and res[1] == '撤销成功'
        log.info("汇入交易-等待合规一审状态退汇流程：运营中心-退汇交易查询-校验交易单号和'汇入汇款退回记账成功'状态")
        res = self.cbi.goto_operate_reexchange_in().operate_reexchange_in(_order_id).operate_reexchange_in_detail()
        assert res[0] == _order_id and res[1] == '汇入汇款退回记账成功'

    #汇入交易-等待合规二审状态退汇
    def test_interbt_second_audit_refuse_flow(self):
        _order_id = "tran0021202106092018329187778"
        log.info("汇入交易-等待合规二审状态退汇流程：企业-汇出查询-校验交易单号和'等待合规一审'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_order_id).query_in_detail()
        assert res[0] == _order_id and res[1] == '等待合规一审'
        #合规一审
        log.info("汇入交易-等待合规二审状态退汇流程：正在做合规一审通过")
        self.cbi.goto_compliance_in_first_audit().in_first_audit(_order_id).in_first_audit_pass()
        #交易中心查询-等待合规二审状态，撤销
        log.info("汇入交易-等待合规二审状态退汇流程：企业-汇入查询-交易中心查询-撤销")
        self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_order_id).reexchange()
        log.info("汇入交易-等待合规二审状态退汇流程：交易中心企业-汇入查询-校验交易单号和'汇出汇款退回记账成功'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_order_id).query_in_detail()
        assert res[0] == _order_id and res[1] == '撤销中'
        #运营中心-退汇交易-汇出交易退汇-待退汇
        log.info("汇入交易-等待合规二审状态退汇流程：正在运营中心-退汇交易-汇出交易退汇-待退汇-做确认")
        self.cbi.goto_operate_wait_reexchange_in().operate_wait_reexchange(_order_id).operate_in_reexchange()
        log.info("汇入交易-等待合规二审状态退汇流程：交易中心企业-汇出查询-校验交易单号和'撤销成功'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_order_id).query_in_detail()
        assert res[0] == _order_id and res[1] == '撤销成功'
        log.info("汇入交易-等待合规二审状态退汇流程：合规中心-企业-汇出交易查询-校验交易单号和'撤销成功'状态")
        res = self.cbi.goto_compliance_in_query().in_query_info(_order_id)
        assert res[0] == _order_id and res[1] == '撤销成功'
        log.info("汇入交易-等待合规二审状态退汇流程：运营中心-退汇交易查询-校验交易单号和'汇出汇款退回记账成功'状态")
        res = self.cbi.goto_operate_reexchange_in().operate_reexchange_in(_order_id).operate_reexchange_in_detail()
        assert res[0] == _order_id and res[1] == '汇出汇款退回记账成功'


    #汇入交易-等待BOD状态退汇
    def test_interbt_BOD_refuse_flow(self):
        _order_id = "tran0021202106092018329187778"
        log.info("汇入交易-BOD撤销流程：企业-汇入查询-校验交易单号和'等待合规一审'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_order_id).query_in_detail()
        assert res[0] == _order_id and res[1] == '等待合规一审'
        #合规一审拒绝
        log.info("汇入交易-BOD撤销流程：正在做合规一审通过")
        self.cbi.goto_compliance_in_first_audit().in_first_audit(_order_id).in_first_audit_pass()
        #交易中心查询
        log.info("汇入交易-BOD撤销流程：企业-汇入查询-校验交易单号和''等待合规二审'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_order_id).query_in_detail()
        assert res[0] == _order_id and res[1] == '等待合规二审'
        #合规二审的时候选BOD
        log.info("汇入交易-BOD撤销流程：正在做合规二审选择BOD")
        self.cbi.goto_compliance_in_second_audit().in_second_audit(_order_id).in_second_audit_bod()
        #交易中心查询-等待BOD审核，撤销
        log.info("汇入交易-BOD撤销流程：企业-汇出查询-交易中心查询-撤销")
        self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_order_id).reexchange()
        log.info("汇入交易-等待合规一审状态撤销流程：交易中心企业-汇入查询-校验交易单号和'汇入汇款退回记账成功'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_order_id).query_in_detail()
        assert res[0] == _order_id and res[1] == '撤销中'
        #运营中心-退汇交易-汇出交易退汇-待退汇
        log.info("汇入交易-BOD拒绝流程：正在运营中心-退汇交易-汇入交易退汇-待退汇-做确认")
        self.cbi.goto_operate_wait_reexchange_in().operate_wait_reexchange(_order_id).operate_in_reexchange()
        log.info("汇入交易-等待合规一审状态撤销流程：交易中心企业-汇入查询-校验交易单号和'撤销成功'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_order_id).query_in_detail()
        assert res[0] == _order_id and res[1] == '撤销成功'
        log.info("汇入交易-等待合规一审状态撤销流程：合规中心-企业-汇入交易查询-校验交易单号和'撤销成功'状态")
        res = self.cbi.goto_compliance_in_query().in_query_info(_order_id)
        assert res[0] == _order_id and res[1] == '撤销成功'
        log.info("汇入交易-等待合规一审状态撤销流程：运营中心-退汇交易查询-校验交易单号和'汇入汇款退回记账成功'状态")
        res = self.cbi.goto_operate_reexchange_in().operate_reexchange_in(_order_id).operate_reexchange_in_detail()
        assert res[0] == _order_id and res[1] == '汇入汇款退回记账成功'


    def teardown_class(self):
        self.cbi.quit()


