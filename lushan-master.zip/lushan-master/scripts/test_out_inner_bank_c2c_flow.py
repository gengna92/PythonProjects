import time

from page.login_page import LoginPage
import pytest
from base.get_logger import GetLogger
log = GetLogger.get_logger()


class TestInnerbankB2BSuccess:
    def setup_class(self):
        # 第一次实例化
        self.cbi = LoginPage().go_to_main_page().go_to_cbi_bank()


    _order_id = "tran0020202106111020015185977"
    _send_out_english_name = "CHOUZHOU JIEHUI TEST LWJ 00001"
    _amount = "11.99"

    def test_inner_bank_c2c_flow(self):
        #交易中心-汇出交易查询
        log.info("C2B同行转账汇出流程：企业-汇出查询-校验交易单号和'等待合规一审'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(self._order_id)
        assert res[0] == self._order_id and res[1] == '等待合规一审'
        #个人-合规一审
        log.info("C2B同行转账汇出流程：正在做合规一审")
        self.cbi.goto_c_compliance_out_first_audit().out_first_audit(self._order_id).out_first_audit_pass()
        # 交易中心-汇出交易查询
        log.info("C2B同行转账汇出流程：企业-汇出查询-校验交易单号和'等待合规二审'状态")
        res = self.cbi.goto_c_t_center_query_out_page().query_out_detail(self._order_id)
        assert res[0] == self._order_id and res[1] == '等待合规二审'
        #合规二审
        log.info("C2B同行转账汇出流程：正在做合规二审")
        self.cbi.goto_c_compliance_out_second_audit().out_second_audit(self._order_id).out_second_audit_pass()
        #企业汇入交易查询，校验金额和状态
        log.info("C2B同行转账汇出流程：企业汇入交易查询校验金额和'汇入记账成功'状态")
        res = self.cbi.goto_c_t_center_query_in_page().query_in(self._send_out_english_name).query_in_detail()
        assert res[0] == self._amount and res[1] == "汇入记账成功"
        #运营中心，汇出查询，校验金额和状态
        log.info("C2B同行转账汇出流程：运营中心-汇出查询校验金额和'汇出记账成功'状态")
        res = self.cbi.goto_operate_out_trans_out().out_trans_out(self._order_id).out_trans_out_detail()
        assert res[0] == self._amount and res[1] == "汇出记账成功"

    # def teardown_class(self):
    #     self.cbi.quit()
