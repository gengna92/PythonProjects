import time

from page.login_page import LoginPage
import pytest
from base.get_logger import GetLogger
log = GetLogger.get_logger()


class TestInterbankB2B:
    def setup_class(self):
        # 第一次实例化
        self.cbi = LoginPage().go_to_main_page().go_to_cbi_bank()

    #汇入交易-一审拒绝流程
    def test_interbt_first_audit_refuse_flow(self):
        _usd_order_id = "tran0011202106231524445155268"
        _apply_id = '100000000000000884'
        # 合规中心-企业-汇入交易-交易关联
        self.cbi.goto_compliance_in_deal_relate().in_conne_tran(_usd_order_id).in_conne_tran(_apply_id)
        # 运营中心-汇入交易-标准类汇入-汇入挂账，挂账
        self.cbi.goto_operate_in_stand_suspense_account().suspense_account_detail(_usd_order_id).do_suspense_account(_usd_order_id)
        # 等道琼斯
        time.sleep(60)
        log.info("汇入交易-一审拒绝流程：企业-汇入查询-校验交易单号和'等待合规一审'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_usd_order_id).detail()
        assert res[0] == _usd_order_id and res[1] == '等待合规一审'
        # 合规一审
        log.info("汇入交易-一审拒绝流程：正在做合规一审")
        self.cbi.goto_compliance_in_first_audit().in_first_audit(_usd_order_id).in_first_audit_refuse()
        #交易中心查询
        log.info("汇入交易-一审拒绝流程：企业-汇入查询-校验交易单号和'合规拒绝'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_usd_order_id).detail()
        assert res[0] == _usd_order_id and res[1] == '合规拒绝'
        #交易中心-退汇交易-汇入交易退汇-待退汇
        self.cbi.goto_t_center_in_wait_reexc_page().in_wait_reexchange(_usd_order_id).operate_in_reexchange()
        #合规中心-退汇交易-汇入交易退汇-汇入待退汇
        self.cbi.goto_compliance_in_wait_reexchange().in_wait_reexchange(_usd_order_id).operate_in_reexchange()
        #运营中心-退汇交易-汇入交易退汇-待退汇
        log.info("汇入交易-一审拒绝流程：正在运营中心-退汇交易-汇入交易退汇-待退汇")
        self.cbi.goto_operate_wait_reexchange_in().operate_wait_reexchange(_usd_order_id).operate_in_reexchange()
        log.info("汇入交易-一审拒绝流程：交易中心企业-汇入查询-校验交易单号和'汇入汇款退回记账成功'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_usd_order_id).query_in_detail()
        assert res[0] == _usd_order_id and res[1] == '汇出汇款退回记账成功'
        log.info("汇入交易-一审拒绝流程：合规中心-企业-汇入交易查询-校验交易单号和'汇入汇款退回记账成功'状态")
        res = self.cbi.goto_compliance_in_query().in_query_info(_usd_order_id)
        assert res[0] == _usd_order_id and res[1] == '汇入汇款退回记账成功'
        log.info("汇入交易-一审拒绝流程：运营中心-退汇交易查询-校验交易单号和'汇出汇款退回记账成功'状态")
        res = self.cbi.goto_operate_reexchange_in().operate_reexchange_in(_usd_order_id).operate_reexchange_in_detail()
        assert res[0] == _usd_order_id and res[1] == '汇出汇款退回记账成功'

    #汇入交易-二审拒绝流程
    def test_interbt_second_audit_refuse_flow(self):
        _usd_order_id = "tran0011202106231524445155268"
        _apply_id = '100000000000000884'
        # 合规中心-企业-汇入交易-交易关联
        self.cbi.goto_compliance_in_deal_relate().in_conne_tran(_usd_order_id).in_conne_tran(_apply_id)
        # 运营中心-汇入交易-标准类汇入-汇入挂账，挂账
        self.cbi.goto_operate_in_stand_suspense_account().suspense_account_detail(_usd_order_id).do_suspense_account(_usd_order_id)
        # 等道琼斯
        time.sleep(60)
        log.info("汇入交易-二审拒绝流程：企业-汇入查询-校验交易单号和'等待合规一审'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_usd_order_id).detail()
        assert res[0] == _usd_order_id and res[1] == '等待合规一审'
        # 合规一审
        log.info("汇入交易-二审拒绝流程：正在做合规一审")
        self.cbi.goto_compliance_in_first_audit().in_first_audit(_usd_order_id).in_first_audit_pass()
        log.info("汇入交易-二审拒绝流程：企业-汇入查询-校验交易单号和'等待合规二审'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_usd_order_id).detail()
        assert res[0] == _usd_order_id and res[1] == '等待合规二审'
        #二审拒绝
        self.cbi.goto_compliance_in_second_audit().in_second_audit(_usd_order_id).in_second_audit_refuse()
        #交易中心查询
        log.info("汇入交易-二审拒绝流程：企业-汇入查询-校验交易单号和'合规拒绝'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_usd_order_id).detail()
        assert res[0] == _usd_order_id and res[1] == '合规拒绝'
        #交易中心-退汇交易-汇入交易退汇-待退汇
        self.cbi.goto_t_center_in_wait_reexc_page().in_wait_reexchange(_usd_order_id).operate_in_reexchange()
        #合规中心-退汇交易-汇入交易退汇-汇入待退汇
        self.cbi.goto_compliance_in_wait_reexchange().in_wait_reexchange(_usd_order_id).operate_in_reexchange()
        #运营中心-退汇交易-汇入交易退汇-待退汇
        log.info("汇入交易-二审拒绝流程：正在运营中心-退汇交易-汇入交易退汇-待退汇")
        self.cbi.goto_operate_wait_reexchange_in().operate_wait_reexchange(_usd_order_id).operate_in_reexchange()
        log.info("汇入交易-二审拒绝流程：交易中心企业-汇入查询-校验交易单号和'汇入汇款退回记账成功'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_usd_order_id).query_in_detail()
        assert res[0] == _usd_order_id and res[1] == '汇出汇款退回记账成功'
        log.info("汇入交易-二审拒绝流程：合规中心-企业-汇入交易查询-校验交易单号和'汇入汇款退回记账成功'状态")
        res = self.cbi.goto_compliance_in_query().in_query_info(_usd_order_id)
        assert res[0] == _usd_order_id and res[1] == '汇入汇款退回记账成功'
        log.info("汇入交易-二审拒绝流程：运营中心-退汇交易查询-校验交易单号和'汇出汇款退回记账成功'状态")
        res = self.cbi.goto_operate_reexchange_in().operate_reexchange_in(_usd_order_id).operate_reexchange_in_detail()
        assert res[0] == _usd_order_id and res[1] == '汇出汇款退回记账成功'

    #汇入交易-BOD拒绝流程
    def test_interbt_BOD_audit_refuse_flow(self):
        _usd_order_id = "tran0011202106231524445155268"
        _apply_id = '100000000000000884'
        # 合规中心-企业-汇入交易-交易关联
        self.cbi.goto_compliance_in_deal_relate().in_conne_tran(_usd_order_id).in_conne_tran(_apply_id)
        # 运营中心-汇入交易-标准类汇入-汇入挂账，挂账
        self.cbi.goto_operate_in_stand_suspense_account().suspense_account_detail(_usd_order_id).do_suspense_account(_usd_order_id)
        # 等道琼斯
        time.sleep(60)
        log.info("汇入交易-二审拒绝流程：企业-汇入查询-校验交易单号和'等待合规一审'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_usd_order_id).detail()
        assert res[0] == _usd_order_id and res[1] == '等待合规一审'
        # 合规一审
        log.info("汇入交易-二审拒绝流程：正在做合规一审")
        self.cbi.goto_compliance_in_first_audit().in_first_audit(_usd_order_id).in_first_audit_pass()
        log.info("汇入交易-二审拒绝流程：企业-汇入查询-校验交易单号和'等待合规二审'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_usd_order_id).detail()
        assert res[0] == _usd_order_id and res[1] == '等待合规二审'
        #二审选BOD
        self.cbi.goto_compliance_in_second_audit().in_second_audit(_usd_order_id).in_second_audit_bod()
        log.info("汇入交易-二审拒绝流程：企业-汇入查询-校验交易单号和'等待合规二审'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_usd_order_id).detail()
        assert res[0] == _usd_order_id and res[1] == '等待合规BOD审核'
        #BOD拒绝
        self.cbi.goto_compliance_in_bod().in_bod_audit(_usd_order_id).bod_audit_refuse()
        #交易中心查询
        log.info("汇入交易-二审拒绝流程：企业-汇入查询-校验交易单号和'合规拒绝'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_usd_order_id).detail()
        assert res[0] == _usd_order_id and res[1] == '合规拒绝'
        #交易中心-退汇交易-汇入交易退汇-待退汇
        self.cbi.goto_t_center_in_wait_reexc_page().in_wait_reexchange(_usd_order_id).operate_in_reexchange()
        #合规中心-退汇交易-汇入交易退汇-汇入待退汇
        self.cbi.goto_compliance_in_wait_reexchange().in_wait_reexchange(_usd_order_id).operate_in_reexchange()
        #运营中心-退汇交易-汇入交易退汇-待退汇
        log.info("汇入交易-二审拒绝流程：正在运营中心-退汇交易-汇入交易退汇-待退汇")
        self.cbi.goto_operate_wait_reexchange_in().operate_wait_reexchange(_usd_order_id).operate_in_reexchange()
        log.info("汇入交易-二审拒绝流程：交易中心企业-汇入查询-校验交易单号和'汇入汇款退回记账成功'状态")
        res = self.cbi.goto_t_center_query_in_page().query_in4inter_trans(_usd_order_id).query_in_detail()
        assert res[0] == _usd_order_id and res[1] == '汇出汇款退回记账成功'
        log.info("汇入交易-二审拒绝流程：合规中心-企业-汇入交易查询-校验交易单号和'汇入汇款退回记账成功'状态")
        res = self.cbi.goto_compliance_in_query().in_query_info(_usd_order_id)
        assert res[0] == _usd_order_id and res[1] == '汇入汇款退回记账成功'
        log.info("汇入交易-二审拒绝流程：运营中心-退汇交易查询-校验交易单号和'汇出汇款退回记账成功'状态")
        res = self.cbi.goto_operate_reexchange_in().operate_reexchange_in(_usd_order_id).operate_reexchange_in_detail()
        assert res[0] == _usd_order_id and res[1] == '汇出汇款退回记账成功'


    # def teardown_class(self):
    #     self.cbi.quit()


