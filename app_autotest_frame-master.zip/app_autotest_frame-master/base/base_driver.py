from appium import webdriver


def init_driver():
    desired_caps = dict()
    # 设备信息
    desired_caps['platformName'] = 'Android'
    desired_caps["chromedriverExecutable"] = "D:\\Chromedriver\\chromedriver_74\\chromedriver.exe"
    desired_caps['deviceName'] = '988a16394449545835'
    # app信息
    desired_caps['appPackage'] = 'com.bankdo.bankdo'
    desired_caps['appActivity'] = 'io.dcloud.PandoraEntry'
    # 不重置应用
    desired_caps['noReset'] = True

    return webdriver.Remote('http://127.0.0.1:4723/wd/hub', desired_caps)
