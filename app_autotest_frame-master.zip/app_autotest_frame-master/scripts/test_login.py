import time
import pytest
import yaml
from selenium.webdriver.common.by import By

from base.base_analyze import analyze_file
from base.base_driver import init_driver
from page.page import Page




class TestContact:

    def setup(self):
        self.driver = init_driver()
        self.page = Page(self.driver)

    def teardown(self):
        time.sleep(5)
        self.driver.quit()

    def test_01(self):
        self.page.start_page.goto_my_page.goto_login_page.login

    def test_02(self):
        res = self.page.start_page.confirm()
        print(res)





















