from selenium.webdriver.common.by import By

from base.base_action import BaseAction
from page.my_page import MyPage


class StartPage(BaseAction):

    # 总是允许
    # confirm_button = By.ID, "com.android.packageinstaller:id/permission_allow_button"
    confirm_button = By.XPATH, "//*[@class='android.widget.Button' and @text='总是允许']"
    home_page = By.XPATH, "//*[@resource-id='com.bankdo.bankdo:id/tabTV' and @text='首页']"
    my_page = By.XPATH, "//*[@resource-id='com.bankdo.bankdo:id/tabTV' and @text='我的']"


    # 总是允许之后获取上下文
    def confirm(self):
        # self.click(self.confirm_button)
        # self.click(self.confirm_button)
        #NATIVE_APP
        start_cons = self.driver.contexts

        self.click(self.home_page)
        #['NATIVE_APP', 'WEBVIEW_com.bankdo.bankdo']
        cons2 = self.driver.contexts
        page1 = self.driver.page_source
        # self.driver.switch
        self.driver.switch_to.context(cons2[-1])
        # cons3 = self.driver.contexts

        page = self.driver.page_source
        print(page)
        return page1

    @property
    def goto_my_page(self):

        self.click(self.my_page)
        #['NATIVE_APP', 'WEBVIEW_com.bankdo.bankdo']
        cons = self.driver.contexts
        # self.driver.switch
        self.driver.switch_to.context(cons[-1])
        page = self.driver.page_source
        print(page)
        return MyPage(self.driver)