from selenium.webdriver.common.by import By

from base.base_action import BaseAction



class MyPage(BaseAction):

    # 登录
    login_entrance_button = By.XPATH, "//*[@_i='13']"

    @property
    def goto_login_page(self):
        from page.login_page import LoginPage
        self.click(self.login_entrance_button)
        return LoginPage(self.driver)