from selenium.webdriver.common.by import By

from base.base_action import BaseAction


class LoginPage(BaseAction):

    # 手机号输入框
    phone_edit_text = By.XPATH, "//*[@_i='13']"

    # 密码输入框
    password_edit_text = By.XPATH, "//*[@class='easy']"

    # 登录按钮
    login_button = By.XPATH, "//*[@class='view-button'] "

    @property
    def login(self):
        self.input(self.phone_edit_text,"18910358208")
        self.input(self.password_edit_text,"Houxiuzhi123")
        self.click(self.login_button)

    # 输入用户名
    def input_phone(self, text):
        self.input(self.phone_edit_text, text)

    # 输入密码
    def input_password(self, text):
        self.input(self.password_edit_text, text)

    # 点击登录
    def login(self):
        self.click(self.login_button)