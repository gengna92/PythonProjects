import os



# os.sep

# mac 路径 /xxxx/xxxx/xxx.py
# windows 路径 c:\xxxx\xxx\xxx.py

# "./ndata/xx.py"

file_path1 = r".\ndata\xx.py"
file_path2 = r"./ndata/xx.py"
print(os.sep)