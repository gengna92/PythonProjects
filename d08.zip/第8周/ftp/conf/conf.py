ip = '127.0.0.1'
port = 9000
filepath = 'D:\python\LICENSE.txt'
salt = b'saltncvh'