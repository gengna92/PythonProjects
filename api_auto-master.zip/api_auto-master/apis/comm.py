import yaml
import base
import requests
import allure
import json
import time


class PreCard:
    def __init__(self):
        self.session = requests.session()
        self.data = {
            "channel": "1201",
            "loginId": "+8618800000000",
            "password": "255884Z4o/LhDBN9HJdhVA==",
            "uuid": "e5290eb817a94863981558f8e41b30bf"
        }
        self.data_henna = {
            "channel": "1201",
            "loginId": "+8618910358208",
            "password": "5wM0rVqCz/bjdF/FFOyg7w==",
            "uuid": "0b8a8a7158524f0881b7d8cfedea5e69"
        }
        self.myHeader = {"Content-Type": "application/json", "sessionId": self.get_sessionId_henna()}
        self.myHeader_01 = {"Content-Type": "application/json", "sessionId": self.get_sessionId()}

    #通用解析yaml数据方法
    def get_data(self,files):
        with open(files,encoding='utf-8') as f:
            yml_data = yaml.safe_load(f)
            data = []
            for i in yml_data.keys():
                errorCode = yml_data[i]['errorCode']
                datas = yml_data[i]['data']
                eles = (datas,errorCode)
                data.append(eles)
        return data

    #通用解析casename
    @allure.story("获取sessionId11111")
    def get_case_name(self,files):
        with open(files,encoding='utf-8') as f:
            yml_data = yaml.safe_load(f)
            casenames = []
            for i in (yml_data.keys()):
                casenames.append(i)
        return casenames

    @allure.story("获取sessionId")
    def get_sessionId(self):
        self.url = base.pre_bank_base_url + '/perbank/v1/user/login'
        r = requests.post(url=self.url,json=self.data,verify=False)
        sessionId = r.json()["sessionId"]
        return sessionId

    def get_sessionId_henna(self):
        self.url = base.pre_bank_base_url + '/perbank/v1/user/login'
        r = requests.post(url=self.url,json=self.data_henna,verify=False)
        sessionId = r.json()["sessionId"]
        return sessionId

    @allure.story("登录接口")
    def login(self,session,data):
        self.url = base.pre_bank_base_url + '/perbank/v1/user/login'
        self.data = data
        r = session.post(url=self.url,json=self.data,verify=False)
        return r

    @allure.story("获取MsgInfo")
    def genMsgInfo(self):
        self.url = base.easy_bank_base_url + '/interface/genMsgInfo'
        r = requests.get(url=self.url,headers=self.myHeader,verify=False)
        msgID = r.json()['msgID']
        return msgID

    @allure.story("获取MsgInfo")
    def genMsgInfo_A(self):
        self.url = base.easy_bank_base_url + '/interface/genMsgInfo'
        r = requests.get(url=self.url,headers=self.myHeader_01,verify=False)
        msgID = r.json()['msgID']
        return msgID

    @allure.story("设置默认卡")
    def setCardDefaultNew(self,session,data):
        self.url = base.easy_bank_base_url + '/interface/setCardDefaultNew'
        self.data = data
        r = session.post(url=self.url,json=self.data,headers=self.myHeader,verify=False)
        return r

    @allure.story("获取卡列表")
    def getCardListNew(self):
        self.url = base.easy_bank_base_url + '/interface/getCardListNew?refresh=1'
        r = requests.get(url=self.url,headers=self.myHeader,verify=False)
        return r


    @allure.story("获取卡qrcToken")
    def get_qrcToken(self):
        self.url = base.easy_bank_base_url + '/interface/getCardListNew?refresh=1'
        r = requests.get(url=self.url,headers=self.myHeader,verify=False)
        n = len(r.json()['userCardInfoDtoList'])
        if n > 0:
            qrcToken = r.json()['userCardInfoDtoList'][0]['qrcToken']
        else:
            print("未绑卡")
        return qrcToken

    @allure.story("获取卡数量")
    def get_card_count(self):
        self.url = base.easy_bank_base_url + '/interface/getCardListNew?refresh=1'
        r = requests.get(url=self.url,headers=self.myHeader,verify=False)
        n = len(r.json()['userCardInfoDtoList'])
        return n

    #APP绑卡
    @allure.story("APP绑卡")
    def app_bind(self,session,data):
        self.url = base.easy_bank_base_url + '/api/gift/app/bind'
        self.data = data
        r = session.post(url=self.url,json=self.data,headers=self.myHeader,verify=False)
        return r

    #H5绑卡
    @allure.story("H5绑卡")
    def h5_bind(self,session,data):
        self.url = base.easy_bank_base_url + '/api/gift/bind'
        self.data = data
        r = session.post(url=self.url,json=self.data,headers=self.myHeader,verify=False)
        return r

    #获取卡密
    @allure.story("获取卡密")
    def get_card(self,files):
        with open(files,encoding='utf-8') as f:
            lines = [line.strip('\n') for line in f.readlines()]
        return lines

    #删除已使用卡
    @allure.story("删除已使用卡")
    def del_used_card(self,files):
        cards = self.get_card(files)
        cards.pop()
        with open(files,'a',encoding='utf-8') as f:
            f.seek(0)
            f.truncate()
            # f.write(''.join(str(i) for i in cards) +'\n')
        for i in cards:
            with open(files,'a',encoding='utf-8') as f:
                f.write(i+'\n')

    #生成付款码
    @allure.story("生成付款码")
    def qrcGeneration(self,session,data):
        self.url = base.easy_bank_base_url + '/interface/qrcGeneration'
        self.data = data
        r = session.post(url=self.url,json=self.data,headers=self.myHeader,verify=False)
        return r

    #生成付款码
    @allure.story("生成付款码")
    def qrcGeneration_A(self,session,data):
        self.url = base.easy_bank_base_url + '/interface/qrcGeneration'
        self.data = data
        r = session.post(url=self.url,json=self.data,headers=self.myHeader_01,verify=False)
        return r

    #发卡
    @allure.story("发卡")
    def sendCard(self,session,data):
        self.url = base.easy_bank_base_url + '/api/send-card/send'
        self.data = data
        r = session.post(url=self.url,json=self.data,headers=self.myHeader,verify=False)
        return r

    #发红包
    @allure.story("发红包")
    def sendRedPacket(self,session,data):
        self.url = base.easy_bank_base_url + '/api/send-red-packet/send'
        self.data = data
        r = session.post(url=self.url,json=self.data,headers=self.myHeader,verify=False)
        return r

    #查询交易信息
    @allure.story("查询交易信息")
    def getTransactions(self,session,data):
        self.url = base.easy_bank_base_url + '/interface/getTransactions'
        self.data = data
        r = session.post(url=self.url,json=self.data,headers=self.myHeader,verify=False)
        return r

        # 查询交易信息

    @allure.story("查询交易信息")
    def getTransactions_A(self, session, data):
        self.url = base.easy_bank_base_url + '/interface/getTransactions'
        self.data = data
        r = session.post(url=self.url, json=self.data, headers=self.myHeader_01, verify=False)
        return r

    #获取零钱
    @allure.story("获取零钱")
    def balance(self):
        self.url = base.easy_bank_base_url + '/api/cash/balance'
        r = requests.get(url=self.url,headers=self.myHeader,verify=False)
        return r

    #获取零钱记录
    @allure.story("获取零钱记录")
    def balance_record(self):
        self.url = base.easy_bank_base_url + '/api/cash/record'
        r = requests.get(url=self.url,headers=self.myHeader,verify=False)
        return r


    @allure.story("设置隐藏卡")
    def set_card_hide(self,session,data):
        self.url = base.easy_bank_base_url + '/interface/setCardHideNew'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    @allure.story("领卡详情")
    def card_collection_detail(self,session,data):
        self.url = base.easy_bank_base_url + '/api/cardCollectionDetail'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    @allure.story("领卡记录")
    def card_collection_record(self,session,data):
        self.url = base.easy_bank_base_url + '/api/cardCollectionRecord'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    @allure.story("发卡记录")
    def send_card_record(self,session,data):
        self.url = base.easy_bank_base_url + '/api/cardIssuingRecord'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r


    @allure.story("H5领取心e卡")
    def send_card_receive(self,data):
        self.url = base.easy_bank_base_url + '/api/send-card/receive'
        self.data = data
        r = requests.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    @allure.story('主扫emv国外解析二维码数据')
    def parse_mpqrc_payload(self,session,data):
        self.url = base.easy_bank_base_url + '/interface/parseMpqrcPayload'
        self.data = data
        return session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)

    @allure.story('主扫emv国外')
    def mpqrc_payment_emv(self,session,data):
        self.url =  base.easy_bank_base_url + '/interface/mpqrcPaymentEMV'
        self.data = data
        return session.post(url=self.url,headers=self.myHeader_01,json=self.data,verify=False)

    @allure.story('主扫url国内')
    def mpqrc_payment_url(self,session,data):
        self.url =  base.easy_bank_base_url + '/interface/mpqrcPaymentURL'
        self.data = data
        return session.post(url=self.url,headers=self.myHeader_01,json=self.data,verify=False)

    @allure.story('主扫URL国内查询扫码信息')
    def qrc_info_inquiry(self,session,data):
        self.url =  base.easy_bank_base_url + '/interface/qrcInfoInquiry'
        self.data = data
        return session.post(url=self.url,headers=self.myHeader_01,json=self.data,verify=False)

    @allure.story('主扫交易结果查询')
    def trx_result_inquiry(self,session,data):
        self.url =  base.easy_bank_base_url + '/interface/trxResultInquiry'
        self.data = data
        return session.post(url=self.url,headers=self.myHeader_01,json=self.data,verify=False)

    @allure.story('被扫是否触发附加流程')
    def get_additional_processing(self,session,data):
        self.url =  base.easy_bank_base_url + '/interface/getAdditionalProcessing'
        self.data = data
        return session.post(url=self.url,headers=self.myHeader_01,json=self.data,verify=False)

    @allure.story('被扫附加流程用户回复')
    def additional_processing_result(self,session,data):
        self.url =  base.easy_bank_base_url + '/interface/additionalProcessingResult'
        self.data = data
        return session.post(url=self.url,headers=self.myHeader_01,json=self.data,verify=False)

    @allure.story('被扫根据二维码信息查询交易结果')
    def find_last_result(self,session,data):
        self.url =  base.easy_bank_base_url + '/interface/findLastTrxResult'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader_01,json=self.data,verify=False)
        return r

    @allure.story("卡片领取详情")
    def send_card_receive_detail(self,session,data):
        self.url = base.easy_bank_base_url + '/api/send-card/receiveDetail'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    @allure.story("获取发卡人信息")
    def send_card_sender_info(self,session,data):
        self.url = base.easy_bank_base_url + '/api/send-card/senderInfo'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    @allure.story("领卡")
    def card_receive(self,session,data):
        self.url = base.easy_bank_base_url + '/api/send-card/receive'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    @allure.story("领取状态")
    def card_receive_State(self,session,data):
        self.url = base.easy_bank_base_url + '/api/send-card/receiveState'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    @allure.story("领取红包")
    def redp_receive(self,session,data):
        self.url = base.easy_bank_base_url + '/api/send-red-packet/receive'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    @allure.story("领取红包记录")
    def redp_receive_record(self,session,data):
        self.url = base.easy_bank_base_url + '/api/send-red-packet/recvRedPacketRecord'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    @allure.story("app红包详情")
    def app_redp_detail(self,session,data):
        self.url = base.easy_bank_base_url + '/api/send-red-packet/redPacketDetail'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    @allure.story("H5红包详情")
    def h5_redp_detail(self,session,data):
        self.url = base.easy_bank_base_url + '/api/send-red-packet/redPacketDetailOfHtml'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

   #获取银联主扫国内url
    def get_qrc_yinlian_mpqrcPayload(self):
        para = time.strftime("%Y%m%d%H%M%S",time.localtime())
        url = 'https://open.unionpay.com/ajweb/help/qrcodeFormPage/sendOk?puid=6&requestType=mainSweepGoldenReceiver&sendtype=QRCode&sendData=[{"fid":131,"keyword":"acqCode","value":"48020000"},{"fid":132,"keyword":"orderNo","value":'+str(para)+'},{"fid":133,"keyword":"orderTime","value":'+str(para)+'},{"fid":134,"keyword":"orderType","value":"10"},{"fid":320,"keyword":"txnAmt","value":""},{"fid":369,"keyword":"termId","value":""},{"fid":383,"keyword":"payeeComments","value":""},{"fid":393,"keyword":"qrValidTime","value":""},{"fid":136,"keyword":"id","value":"777290058135880"},{"fid":137,"keyword":"name","value":"商户名称"},{"fid":381,"keyword":"accNo","value":""},{"fid":382,"keyword":"termId","value":""},{"fid":391,"keyword":"subId","value":""},{"fid":392,"keyword":"subName","value":""}]'
        res = requests.get(url=url).content.decode('utf-8')
        import re
        partten = re.compile(r"https://.*")
        r = partten.search(res).group(0).split(',')[0]
        return r

    #银联被扫国外send
    def qrc_consume_oss_send(self,mpqrcPayload):
        mpqrcPayload = 'hQVDUFYwMWFWTwigAAADMwEBA1cRYpJpAWkWCIbSUHIBAAABiAFfNAEAYzOfJghWivrINUsdVJ8nAYCfEBEHAAEDoAAAAQgzOTk5MDEyMp82AgAVggIAAJ83BO9qr/Q='
        self.myHeader["Content-Type"]=  "application/x-www-form-urlencoded"
        self.myHeader['X-Requested-With'] = 'XMLHttpRequest'
        data = {'BODY_4':'10',
                'caseCd':'211',
                'cgqrc':mpqrcPayload}
        res = requests.post(headers=self.myHeader,url='https://qrctest.unionpayintl.com/cqrt/ossComsume/send',data=data)
        return res.status_code



        # 获取银联被扫国内url
    def qrc_consume_sendok(self,barcodeCpqrcPayload):
        para = time.strftime("%Y%m%d%H%M%S", time.localtime())
        url = 'https://open.unionpay.com/ajweb/help/qrcodeFormPage/sendOk?puid=14&requestType=coverSweepGoldenReceiver&sendtype=Purchase&sendData=[{"fid":352,"keyword":"acqCode","value":"48020000"},{"fid":353,"keyword":"merId","value":"777290058135880"},{"fid":354,"keyword":"merCatCode","value":"5811"},{"fid":355,"keyword":"merName","value":"商户名称"},{"fid":356,"keyword":"reqType","value":"0310000903"},{"fid":357,"keyword":"txnAmt","value":"300"},{"fid":358,"keyword":"termId","value":"49000002"},' \
              '{"fid":359,"keyword":"qrNo","value":'+barcodeCpqrcPayload+'},' \
              '{"fid":360,"keyword":"backUrl","value":"http://101.231.204.84:8091/sim/notify_url2.jsp"},' \
              '{"fid":372,"keyword":"orderNo","value":'+str(para)+'},' \
              '{"fid":373,"keyword":"orderTime","value":'+str(para)+'}]'
        res = requests.get(url=url)
        return res.status_code


    @allure.story("H5获取发红包人信息")
    def redp_sender_Info(self,session,data):
        self.url = base.easy_bank_base_url + '/api/send-red-packet/senderInfo'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    @allure.story("发红包记录")
    def redp_send_record(self,session,data):
        self.url = base.easy_bank_base_url + '/api/send-red-packet/sendRedPacketRecord'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r
