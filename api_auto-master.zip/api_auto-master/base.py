import os
import sys
print(sys.path)

# 封装程序常量
easy_bank_base_url = 'https://uat-prunipay.easybank.com.cn'
pre_bank_base_url= 'http://bankdo.corporbank.com'


file_path = os.path.dirname(os.path.abspath(__file__))