#todo 主扫、被扫功能
import time
import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import allure
import pytest
import datetime
from dateutil.relativedelta import relativedelta
import os, sys
path = os.path.abspath(__file__)
for i in range(2):
    path = os.path.dirname(path)
    sys.path.append(path)
import base
from apis.comm import PreCard


class TestQrc:
    def setup(self):
        self.session = requests.session()
        self.preCard = PreCard()
        self.tmp = globals()

    def teardowm(self):
        self.session.close()
    # @pytest.fixture(scope='module')
    # def fun(self):
    #     self.session = requests.session()
    #     self.preCard = PreCard()
    #     self.tmp = globals()
    #     yield
    #     self.session.close()

    @allure.story('主扫EMV国外')
    @allure.severity('blocker')
    def test_mpqrc_payment_emv(self):
        allure.attach('新生成一个msgid')
        self.tmp['msgid'] = self.preCard.genMsgInfo_A()
        #此处token写死了，后续可做成动态
        self.tmp['token'] = '6292690169160886'
        self.data = {
            "msgInfo": {
                "msgID":  self.tmp['msgid'],
                "timeStamp": "20210408140405",
                "insID": "151525"
            },
            "trxInfo": {
                "token": self.tmp['token'],
                "userID": "PB10000900",
                "deviceID": "NEFFREEZOTMTMJY5MY00RDI3LTG2MUUTMDQ1ODUWRTC2OD",
                "trxAmt": "2.00",
                "trxCurrency": "344",
                "trxFeeAmt": "0",
                "merchantInfo": {
                    "acquirerIIN": "25000344",
                    "fwdIIN": "00020344",
                    "mid": "100000000000006",
                    "merchantName": "Test Merchant",
                    "mcc": "5972",
                    "merchantCountry": "HK",
                    "termId": None,
                    "agentCode": None
                },
                "mpqrcPayload": "000201010211153125000344000203441000000000000065204597253033445802HK5913Test Merchant6002HK626001200000000000000000000005200000000000000000000007080000001063045855",
                "origTrxMsgID": "A3999012220210408140401721435",
                "input": "inputAmt"
            },
            "token": self.tmp['token']
}
        res = self.preCard.mpqrc_payment_emv(self.session,data=self.data)
        try:
            ret = res.json()['msgResponse']['responseCode']
            qrcVoucherNo_emv = res.json()['trxInfo']['qrcVoucherNo']
            assert ret == '00'
            startTime = datetime.date.today() - relativedelta(months=+1)
            endTime = datetime.date.today()
            #获取最新的一条交易记录进行断言是否消费成功
            self.tran_data = {
                "msgInfo": {
                    "msgID": "A3999012220210408143313901999",
                    "timeStamp": "20210408143313",
                    "insID": "151525"
                },
                "trxInfo": {
                    "token": self.tmp['token'],
                    "userID": "PB10000900",
                    "deviceID": "NEFFREEZOTMTMJY5MY00RDI3LTG2MUUTMDQ1ODUWRTC2OD",
                    "startTime": str(startTime) ,
                    "endTime": str(endTime),
                    "paymentState": "",
                    "pageNo": 1,
                    "pageSize": 1
                },
                "token": self.tmp['token']
            }
            res = self.preCard.getTransactions_A(self.session,self.tran_data)
            qrcVoucherNo_t = res.json()['transactions']['records'][0]['qrcVoucherNo']
            assert qrcVoucherNo_emv == qrcVoucherNo_t
        except:
            allure.attach(Exception)
            # raise Exception

    @allure.story('主扫url国内')
    @allure.severity('blocker')
    def test_mpqrc_payment_url(self):
        allure.attach('新生成一个msgid')
        self.tmp['msgid'] = self.preCard.genMsgInfo_A()
        # 此处token写死了，后续可做成动态
        self.tmp['token'] = '6292690169160886'
        #获取mpqrcPayload
        self.tmp['mpqrcPayload'] = self.preCard.get_qrc_yinlian_mpqrcPayload()
        #获取origTrxMsgID
        self.info_data = {
            "msgInfo": {
                "msgID": self.tmp['msgid'] ,
                "timeStamp": "20210408154321",
                "insID": "151525"
            },
            "trxInfo": {
                "token": self.tmp['token'],
                "userID": "PB10000900",
                "deviceID": "NEFFREEZOTMTMJY5MY00RDI3LTG2MUUTMDQ1ODUWRTC2OD",
                "mpqrcPayload": self.tmp['mpqrcPayload']
            },
            "token":  self.tmp['token']
        }

        self.tmp['origTrxMsgID'] = self.preCard.qrc_info_inquiry(self.session,data=self.info_data).json()['msgInfo']['msgID']
        #新生成一个msgid
        self.tmp['msgid'] = self.preCard.genMsgInfo_A()
        self.data = {
            "msgInfo": {
                "msgID":  self.tmp['msgid'],
                "timeStamp": "20210408152922",
                "insID": "151525"
            },
            "trxInfo": {
                "token":  self.tmp['token'] ,
                "userID": "PB10000900",
                "deviceID": "NEFFREEZOTMTMJY5MY00RDI3LTG2MUUTMDQ1ODUWRTC2OD",
                "trxCurrency": "156",
                "trxFeeAmt": "0",
                "merchantInfo": {
                    "mcc": "5811",
                    "merchantName": "商户名称"
                },
                "mpqrcPayload":  self.tmp['mpqrcPayload'],
                "origTrxMsgID":  self.tmp['origTrxMsgID'],
                "input": "inputAmt",
                "trxAmt": "3.11",
                "riskInfo": {
                    "appUserID": "2195bda309c133759b744d08ab613f29",
                    "reservedMobileNo": "86-18800000000"
                }
            },
            "token":self.tmp['token']
        }
        res = self.preCard.mpqrc_payment_url(self.session, data=self.data)
        try:
            ret = res.json()['msgResponse']['responseCode']
            qrcVoucherNo_emv = res.json()['trxInfo']['qrcVoucherNo']
            assert ret == '00'
            startTime = datetime.date.today() - relativedelta(months=+1)
            endTime = datetime.date.today()
            # 获取最新的一条交易记录进行断言是否消费成功
            self.tran_data = {
                "msgInfo": {
                    "msgID": "A3999012220210408143313901999",
                    "timeStamp": "20210408143313",
                    "insID": "151525"
                },
                "trxInfo": {
                    "token": self.tmp['token'],
                    "userID": "PB10000900",
                    "deviceID": "NEFFREEZOTMTMJY5MY00RDI3LTG2MUUTMDQ1ODUWRTC2OD",
                    "startTime": str(startTime),
                    "endTime": str(endTime),
                    "paymentState": "",
                    "pageNo": 1,
                    "pageSize": 1
                },
                "token": self.tmp['token']
            }
            res = self.preCard.getTransactions_A(self.session, self.tran_data)
            qrcVoucherNo_t = res.json()['transactions']['records'][0]['qrcVoucherNo']
            assert qrcVoucherNo_emv == qrcVoucherNo_t
        except:
            allure.attach(Exception)
            # raise Exception

    @allure.story("被扫国内场景验证")
    @allure.severity('blocker')
    @pytest.mark.skip
    def test_qrc_payment_inbound(self):
        allure.attach("from genMsgInfo get MsgInfo")
        #生成付款二维码国外
        msg_info = self.preCard.genMsgInfo_A()
        self.tmp['msgID'] = msg_info
        allure.attach("from get_qrcToken get CardInfo")
        #token
        self.tmp['token'] = '6292690181183296'
        self.data = {
            "msgInfo": {
                "msgID": self.tmp['msgID'],
                "timeStamp": "20210408174818",
                "insID": "151525"
            },
            "trxInfo": {
                "token": self.tmp['token'],
                "userID": "PB10000900",
                "deviceID": "NEFFREEZOTMTMJY5MY00RDI3LTG2MUUTMDQ1ODUWRTC2OD",
                "cpqrcNo": "1",
                "limitCurrency": "840",
                "trxLimit": "10000",
                "cvmLimit": "0",
                "riskInfo": {
                    "appUserID": "2195bda309c133759b744d08ab613f29",
                    "reservedMobileNo": "86-18800000000"
                }
            },
            "token": self.tmp['token']
        }
        res = self.preCard.qrcGeneration_A(self.session,self.data)
        responseCode = res.json()['msgResponse']['responseCode']
        barcodeCpqrcPayload = res.json()['trxInfo']['barcodeCpqrcPayload']
        para = barcodeCpqrcPayload[0]
        assert responseCode == "00"
        #调取银联接口进行消费
        res = self.preCard.qrc_consume_sendok(para)
        if res == 200:
            allure.attach('调取银联接口成功')
            #被扫是否触发附加流程
            while 1:
                msg_info = self.preCard.genMsgInfo_A()
                self.tmp['msgID'] = msg_info
                self.additon_data = {
                    "msgInfo": {
                        "msgID": self.tmp['msgID'],
                        "timeStamp": "20210409110638",
                        "insID": "151525"
                    },
                    "trxInfo": {
                        "token": self.tmp['token'],
                        "userID": "PB10000900",
                        "deviceID": "NEFFREEZOTMTMJY5MY00RDI3LTG2MUUTMDQ1ODUWRTC2OD",
                        "barcodeCpqrcPayload": para
                    },
                    "token": self.tmp['token']
                }
                add_res = self.preCard.get_additional_processing(self.session,self.additon_data)
                if add_res.json()['trxInfo'] != None:
                    self.tmp['origMsgID'] = add_res.json()['trxInfo']['origMsgID']
                    time.sleep(2)
                    break

        #触发被扫附加流程回复
            msg_info = self.preCard.genMsgInfo_A()
            self.tmp['msgID'] = msg_info
            self.adp_result_data = {
                "msgInfo": {
                    "msgID": self.tmp['msgID'],
                    "timeStamp": "20210409110641",
                    "insID": "151525"
                },
                "trxInfo": {
                    "token": self.tmp['token'],
                    "userID": "PB10000900",
                    "deviceID": "NEFFREEZOTMTMJY5MY00RDI3LTG2MUUTMDQ1ODUWRTC2OD",
                    "origMsgID": self.tmp['origMsgID'],
                    "paymentStatus": "CONTINUING",
                    "barcodeCpqrcPayload": [para]
                },
                "token": "6292690188210241"
            }

            time.sleep(5)
            res = self.preCard.additional_processing_result(self.session,self.adp_result_data)
            res_code = res.json()['msgResponse']['responseCode']
            #断言被扫附加流程用户回复结果
            assert res_code == '00'
            #成功后根据二维码信息查询交易结果
            #先更新msgid
            for i in range(5):
                time.sleep(1)
                msg_info = self.preCard.genMsgInfo_A()
                self.tmp['msgID'] = msg_info
                self.tmp['token'] = '6292690181183296'

                self.result_data = {
                    "msgInfo": {
                        "msgID": self.tmp['msgID'],
                        "timeStamp": "20210408174845",
                        "insID": "151525"
                    },
                    "trxInfo": {
                        "token": self.tmp['token'],
                        "userID": "PB10000900",
                        "deviceID": "NEFFREEZOTMTMJY5MY00RDI3LTG2MUUTMDQ1ODUWRTC2OD",
                        "emvCpqrcPayload": "",
                        "barcodeCpqrcPayload": para
                    },
                    "token": "6292690188210241"
                }
                res = self.preCard.find_last_result(self.session,self.result_data)
                ret = res.json()['msgResponse']['responseCode']
                assert ret=='00'
                if res.json()['trxInfo'] !=None:
                    #获取交易号
                    qrcVoucherNo_emv = res.json()['trxInfo']['qrcVoucherNo']
                    break
            startTime = datetime.date.today() - relativedelta(months=+1)
            endTime = datetime.date.today()
            # 获取最新的一条交易记录进行断言是否消费成功
            self.tran_data = {
                "msgInfo": {
                    "msgID": "A3999012220210408143313901999",
                    "timeStamp": "20210408143313",
                    "insID": "151525"
                },
                "trxInfo": {
                    "token": self.tmp['token'],
                    "userID": "PB10000900",
                    "deviceID": "NEFFREEZOTMTMJY5MY00RDI3LTG2MUUTMDQ1ODUWRTC2OD",
                    "startTime": str(startTime),
                    "endTime": str(endTime),
                    "paymentState": "",
                    "pageNo": 1,
                    "pageSize": 1
                },
                "token": self.tmp['token']
            }
            res = self.preCard.getTransactions_A(self.session, self.tran_data)
            qrcVoucherNo_t = res.json()['transactions']['records'][0]['qrcVoucherNo']
            assert qrcVoucherNo_emv == qrcVoucherNo_t
        else:
            allure.attach('调取银联接口失败啦啦啦')

    @allure.story("被扫国外场景验证")
    @allure.severity('blocker')
    @pytest.mark.skip
    def test_qrc_payment_overseas(self):
        allure.attach("from genMsgInfo get MsgInfo")
        #生成付款二维码国外
        msg_info = self.preCard.genMsgInfo_A()
        self.tmp['msgID'] = msg_info
        allure.attach("from get_qrcToken get CardInfo")
        #token
        self.tmp['token'] = '6292690181183296'
        self.data = {
            "msgInfo": {
                "msgID": self.tmp['msgID'],
                "timeStamp": "20210408174818",
                "insID": "151525"
            },
            "trxInfo": {
                "token": self.tmp['token'],
                "userID": "PB10000900",
                "deviceID": "NEFFREEZOTMTMJY5MY00RDI3LTG2MUUTMDQ1ODUWRTC2OD",
                "cpqrcNo": "1",
                "limitCurrency": "840",
                "trxLimit": "10000",
                "cvmLimit": "0",
                "riskInfo": {
                    "appUserID": "2195bda309c133759b744d08ab613f29",
                    "reservedMobileNo": "86-18800000000"
                }
            },
            "token": self.tmp['token']
        }
        res = self.preCard.qrcGeneration_A(self.session,self.data)
        responseCode = res.json()['msgResponse']['responseCode']
        emvCpqrcPayload = res.json()['trxInfo']['emvCpqrcPayload']
        para = emvCpqrcPayload[0]
        assert responseCode == "00"
        #调取银联接口进行消费
        res = self.preCard.qrc_consume_oss_send(para)
        if res == 200:
            allure.attach('调取银联接口成功')
            #被扫是否触发附加流程
            while 1:
                msg_info = self.preCard.genMsgInfo_A()
                self.tmp['msgID'] = msg_info
                self.additon_data = {
                    "msgInfo": {
                        "msgID": self.tmp['msgID'],
                        "timeStamp": "20210409110638",
                        "insID": "151525"
                    },
                    "trxInfo": {
                        "token": self.tmp['token'],
                        "userID": "PB10000900",
                        "deviceID": "NEFFREEZOTMTMJY5MY00RDI3LTG2MUUTMDQ1ODUWRTC2OD",
                        "emvCpqrcPayload": para
                    },
                    "token": self.tmp['token']
                }
                add_res = self.preCard.get_additional_processing(self.session,self.additon_data)
                if add_res.json()['trxInfo'] != None:
                    self.tmp['origMsgID'] = add_res.json()['trxInfo']['origMsgID']
                    time.sleep(2)
                    break

        #触发被扫附加流程回复
            msg_info = self.preCard.genMsgInfo_A()
            self.tmp['msgID'] = msg_info
            self.adp_result_data = {
                "msgInfo": {
                    "msgID": self.tmp['msgID'],
                    "timeStamp": "20210409110641",
                    "insID": "151525"
                },
                "trxInfo": {
                    "token": self.tmp['token'],
                    "userID": "PB10000900",
                    "deviceID": "NEFFREEZOTMTMJY5MY00RDI3LTG2MUUTMDQ1ODUWRTC2OD",
                    "origMsgID": self.tmp['origMsgID'],
                    "paymentStatus": "CONTINUING",
                    "emvCpqrcPayload": [para]
                },
                "token": "6292690188210241"
            }

            time.sleep(5)
            res = self.preCard.additional_processing_result(self.session,self.adp_result_data)
            res_code = res.json()['msgResponse']['responseCode']
            #断言被扫附加流程用户回复结果
            assert res_code == '00'
            #成功后根据二维码信息查询交易结果
            #先更新msgid
            for i in range(5):
                time.sleep(1)
                msg_info = self.preCard.genMsgInfo_A()
                self.tmp['msgID'] = msg_info
                self.tmp['token'] = '6292690181183296'

                self.result_data = {
                    "msgInfo": {
                        "msgID": self.tmp['msgID'],
                        "timeStamp": "20210408174845",
                        "insID": "151525"
                    },
                    "trxInfo": {
                        "token": self.tmp['token'],
                        "userID": "PB10000900",
                        "deviceID": "NEFFREEZOTMTMJY5MY00RDI3LTG2MUUTMDQ1ODUWRTC2OD",
                        "emvCpqrcPayload": para,
                        "barcodeCpqrcPayload": ""
                    },
                    "token": "6292690188210241"
                }
                res = self.preCard.find_last_result(self.session,self.result_data)
                ret = res.json()['msgResponse']['responseCode']
                assert ret=='00'
                if res.json()['trxInfo'] !=None:
                    #获取交易号
                    qrcVoucherNo_emv = res.json()['trxInfo']['qrcVoucherNo']
                    break
            startTime = datetime.date.today() - relativedelta(months=+1)
            endTime = datetime.date.today()
            # 获取最新的一条交易记录进行断言是否消费成功
            self.tran_data = {
                "msgInfo": {
                    "msgID": "A3999012220210408143313901999",
                    "timeStamp": "20210408143313",
                    "insID": "151525"
                },
                "trxInfo": {
                    "token": self.tmp['token'],
                    "userID": "PB10000900",
                    "deviceID": "NEFFREEZOTMTMJY5MY00RDI3LTG2MUUTMDQ1ODUWRTC2OD",
                    "startTime": str(startTime),
                    "endTime": str(endTime),
                    "paymentState": "",
                    "pageNo": 1,
                    "pageSize": 1
                },
                "token": self.tmp['token']
            }
            res = self.preCard.getTransactions_A(self.session, self.tran_data)
            qrcVoucherNo_t = res.json()['transactions']['records'][0]['qrcVoucherNo']
            assert qrcVoucherNo_emv == qrcVoucherNo_t
        else:
            allure.attach('调取银联接口失败啦啦啦')













