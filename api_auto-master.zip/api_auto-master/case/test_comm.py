import pytest
import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import allure

import os, sys
path = os.path.abspath(__file__)
for i in range(2):
    path = os.path.dirname(path)
    sys.path.append(path)
import base
from apis.comm import PreCard




class TestComm:

    def setup(self):
        self.session = requests.session()
        self.preCard = PreCard()
        self.tmp = globals()

    def teardowm(self):
        self.session.close()

    C = PreCard()
    login_yml = base.file_path + '/data/login.yml'
    @allure.feature("login_comm_case")
    @pytest.mark.parametrize("data,errorcode",C.get_data(login_yml),ids=C.get_case_name(login_yml))
    def test_login(self,data,errorcode):
        res = self.preCard.login(self.session,data)
        err = res.json()['ec']
        errormsg = res.json()['em']
        ret = res.json()['ret']
        # 如果登录不成功，贴一下errormsg
        if err != "0":
            allure.attach("errormsg: ",errormsg)
            allure.attach("retsult: ",ret)
        allure.attach("预期errorcode：",errorcode)
        allure.attach("实际errorcode：",err)
        assert errorcode == err

    set_default_yml = base.file_path + '/data/card/setdefault.yml'
    @allure.feature("set_default_comm_case")
    @pytest.mark.parametrize("data,errorcode",C.get_data(set_default_yml),ids=C.get_case_name(set_default_yml))
    def test_set_default(self,data,errorcode):
        res = self.preCard.setCardDefaultNew(self.session,data)
        err = res.json()['msgResponse']['responseCode']
        errormsg = res.json()['msgResponse']['responseMsg']
        # 如果登录不成功，贴一下errormsg
        if err != "00":
            allure.attach("errormsg: ",errormsg)
        allure.attach("预期errorcode：",errorcode)
        allure.attach("实际errorcode：",err)
        assert errorcode == err


    app_bind_yml = base.file_path + '/data/app_bind.yml'
    @allure.feature("app_build_comm_case")
    @pytest.mark.parametrize("data,errorcode",C.get_data(app_bind_yml),ids=C.get_case_name(app_bind_yml))
    def test_app_build(self,data,errorcode):
        res = self.preCard.app_bind(self.session,data)
        #返回参数有err和errmsg
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != "00":
                # 如果登录不成功，贴一下errormsg
                allure.attach("errormsg: ",errormsg)
                allure.attach("实际errorcode：",err)
            assert errorcode == err
        #返回参数没有err和errmsg
        except:
            ret = res.json()['retCode']
            retMsg = res.json()['retMsg']
            if ret == '0001':
                allure.attach("retMsg: ",retMsg)
                allure.attach("实际errorcode：",ret)
                assert errorcode == ret
        allure.attach("预期errorcode：",errorcode)

    qrc_gen_yml = base.file_path + '/data/qrc_generation.yml'
    @allure.feature("qrc_gen_comm_case")
    @pytest.mark.parametrize("data,errorcode",C.get_data(qrc_gen_yml),ids=C.get_case_name(qrc_gen_yml))
    def test_qrc_gen(self,data,errorcode):
        res = self.preCard.qrcGeneration(self.session,data)
        err = res.json()['msgResponse']['responseCode']
        errormsg = res.json()['msgResponse']['responseMsg']
        # 如果登录不成功，贴一下errormsg
        if err != "00":
            allure.attach("errormsg: ",errormsg)
        allure.attach("预期errorcode：",errorcode)
        allure.attach("实际errorcode：",err)
        assert errorcode == err

    send_packet_yml = base.file_path + '/data/send_red_packet.yml'
    @allure.feature("send_red_packet(_comm_case")
    @pytest.mark.parametrize("data,errorcode",C.get_data(send_packet_yml),ids=C.get_case_name(send_packet_yml))
    def test_send_red_packet(self,data,errorcode):
        res = self.preCard.sendRedPacket(self.session,data)
        #返回参数有err和errmsg
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != "00":
                # 如果登录不成功，贴一下errormsg
                allure.attach("errormsg: ",errormsg)
                allure.attach("实际errorcode：",err)
            assert errorcode == err
        #返回参数没有err和errmsg
        except:
            ret = res.json()['retCode']
            retMsg = res.json()['retMsg']
            if ret == '0001':
                allure.attach("retMsg: ",retMsg)
                allure.attach("实际errorcode：",ret)
                assert errorcode == ret
        allure.attach("预期errorcode：",errorcode)

    send_card_yml = base.file_path + '/data/card/send_card.yml'
    @allure.feature("send_card_comm_case")
    @pytest.mark.parametrize("data,errorcode",C.get_data(send_card_yml),ids=C.get_case_name(send_card_yml))
    def test_send_card(self,data,errorcode):
        res = self.preCard.sendCard(self.session,data)
        #返回参数有err和errmsg
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != "00":
                # 如果登录不成功，贴一下errormsg
                allure.attach("errormsg: ",errormsg)
                allure.attach("实际errorcode：",err)
            assert errorcode == err
        #返回参数没有err和errmsg
        except:
            ret = res.json()['retCode']
            retMsg = res.json()['retMsg']
            if ret == '0001':
                allure.attach("retMsg: ",retMsg)
                allure.attach("实际errorcode：",ret)
                assert errorcode == ret
        allure.attach("预期errorcode：",errorcode)

    card_collection_record_yml = base.file_path + '/data/card/cardCollectionRecord.yml'
    @allure.feature("card_collection_detail_comm_case")
    @pytest.mark.parametrize("data,errorcode",C.get_data(card_collection_record_yml),
                             ids=C.get_case_name(card_collection_record_yml))
    def test_card_collection_record(self,data,errorcode):
        res = self.preCard.card_collection_record(self.session,data)
        #返回参数有err和errmsg
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != "00":
                # 如果登录不成功，贴一下errormsg
                allure.attach("errormsg: ",errormsg)
                allure.attach("实际errorcode：",err)
            assert errorcode == err
        #返回参数没有err和errmsg
        except:
            ret = res.json()['retCode']
            retMsg = res.json()['retMsg']
            if ret != '00':
                allure.attach("retMsg: ",retMsg)
                allure.attach("实际errorcode：",ret)
                assert errorcode == ret
        allure.attach("预期errorcode：",errorcode)

    card_Issuing_record_yml = base.file_path + '/data/card/cardIssuingRecord.yml'
    @allure.feature("card_Issuing_record_comm_case")
    @pytest.mark.parametrize("data,errorcode",C.get_data(card_Issuing_record_yml),
                             ids=C.get_case_name(card_Issuing_record_yml))
    def test_card_collection_record(self,data,errorcode):
        res = self.preCard.send_card_record(self.session,data)
        #返回参数有err和errmsg
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != "00":
                # 如果登录不成功，贴一下errormsg
                allure.attach("errormsg: ",errormsg)
                allure.attach("实际errorcode：",err)
            assert errorcode == err
        #返回参数没有err和errmsg
        except:
            ret = res.json()['retCode']
            retMsg = res.json()['retMsg']
            if ret != '00':
                allure.attach("retMsg: ",retMsg)
                allure.attach("实际errorcode：",ret)
                assert errorcode == ret
        allure.attach("预期errorcode：",errorcode)

    card_send_info_yml = base.file_path + '/data/card/cardsenderInfo.yml'
    @allure.feature("cardsenderInfo_comm_case")
    @pytest.mark.parametrize("data,errorcode",C.get_data(card_send_info_yml),
                             ids=C.get_case_name(card_send_info_yml))
    def test_card_sender_info(self,data,errorcode):
        res = self.preCard.send_card_sender_info(self.session,data)
        #返回参数有err和errmsg
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != "00":
                # 如果登录不成功，贴一下errormsg
                allure.attach("errormsg: ",errormsg)
                allure.attach("实际errorcode：",err)
            assert errorcode == err
        #返回参数没有err和errmsg
        except:
            ret = res.json()['retCode']
            retMsg = res.json()['retMsg']
            if ret != '00':
                allure.attach("retMsg: ",retMsg)
                allure.attach("实际errorcode：",ret)
                assert errorcode == ret
        allure.attach("预期errorcode：",errorcode)

    card_receive_detail_yml = base.file_path + '/data/card/receiveDetail.yml'
    @allure.feature("card_receive_detail_comm_case")
    @pytest.mark.parametrize("data,errorcode",C.get_data(card_receive_detail_yml),
                             ids=C.get_case_name(card_receive_detail_yml))
    def test_card_sender_info(self,data,errorcode):
        res = self.preCard.send_card_receive_detail(self.session,data)
        #返回参数有err和errmsg
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != "00":
                # 如果登录不成功，贴一下errormsg
                allure.attach("errormsg: ",errormsg)
                allure.attach("实际errorcode：",err)
            assert errorcode == err
        #返回参数没有err和errmsg
        except:
            ret = res.json()['retCode']
            retMsg = res.json()['retMsg']
            if ret != '00':
                allure.attach("retMsg: ",retMsg)
                allure.attach("实际errorcode：",ret)
                assert errorcode == ret
        allure.attach("预期errorcode：",errorcode)

    card_receive_yml = base.file_path + '/data/card/card_receive.yml'
    @allure.feature("card_receive_comm_case")
    @pytest.mark.parametrize("data,errorcode",C.get_data(card_receive_yml),
                             ids=C.get_case_name(card_receive_yml))
    def test_card_receive(self,data,errorcode):
        res = self.preCard.card_receive(self.session,data)
        #返回参数有err和errmsg
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != "00":
                # 如果登录不成功，贴一下errormsg
                allure.attach("errormsg: ",errormsg)
                allure.attach("实际errorcode：",err)
            assert errorcode == err
        #返回参数没有err和errmsg
        except:
            ret = res.json()['retCode']
            retMsg = res.json()['retMsg']
            if ret != '00':
                allure.attach("retMsg: ",retMsg)
                allure.attach("实际errorcode：",ret)
                assert errorcode == ret
        allure.attach("预期errorcode：",errorcode)

    card_hide_yml = base.file_path + '/data/card/setCardHide.yml'
    @allure.feature("card_hide_comm_case")
    @pytest.mark.parametrize("data,errorcode",C.get_data(card_hide_yml),
                             ids=C.get_case_name(card_hide_yml))
    def test_card_hide(self,data,errorcode):
        res = self.preCard.set_card_hide(self.session,data)
        #返回参数有err和errmsg
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != "00":
                # 如果登录不成功，贴一下errormsg
                allure.attach("errormsg: ",errormsg)
                allure.attach("实际errorcode：",err)
            assert errorcode == err
        #返回参数没有err和errmsg
        except:
            ret = res.json()['retCode']
            retMsg = res.json()['retMsg']
            if ret != '00':
                allure.attach("retMsg: ",retMsg)
                allure.attach("实际errorcode：",ret)
                assert errorcode == ret
        allure.attach("预期errorcode：",errorcode)

    redp_receive_yml = base.file_path + '/data/redpacket/redp_receive.yml'
    @allure.feature("redp_receive_comm_case")
    @pytest.mark.parametrize("data,errorcode",C.get_data(redp_receive_yml),
                             ids=C.get_case_name(redp_receive_yml))
    def test_redp_receive(self,data,errorcode):
        res = self.preCard.redp_receive(self.session,data)
        #返回参数有err和errmsg
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != "00":
                # 如果登录不成功，贴一下errormsg
                allure.attach("errormsg: ",errormsg)
                allure.attach("实际errorcode：",err)
            assert errorcode == err
        #返回参数没有err和errmsg
        except:
            ret = res.json()['retCode']
            retMsg = res.json()['retMsg']
            if ret != '00':
                allure.attach("retMsg: ",retMsg)
                allure.attach("实际errorcode：",ret)
                assert errorcode == ret
        allure.attach("预期errorcode：",errorcode)

    app_redp_detail_yml = base.file_path + '/data/redpacket/appredPacketDetail.yml'
    @allure.feature("app_redp_detail_comm_case")
    @pytest.mark.parametrize("data,errorcode",C.get_data(app_redp_detail_yml),
                             ids=C.get_case_name(app_redp_detail_yml))
    def test_app_redp_detail(self,data,errorcode):
        res = self.preCard.app_redp_detail(self.session,data)
        #返回参数有err和errmsg
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != "00":
                # 如果登录不成功，贴一下errormsg
                allure.attach("errormsg: ",errormsg)
                allure.attach("实际errorcode：",err)
            assert errorcode == err
        #返回参数没有err和errmsg
        except:
            ret = res.json()['retCode']
            retMsg = res.json()['retMsg']
            if ret != '00':
                allure.attach("retMsg: ",retMsg)
                allure.attach("实际errorcode：",ret)
                assert errorcode == ret
        allure.attach("预期errorcode：",errorcode)

    h5_redp_detail_yml = base.file_path + '/data/redpacket/redPacketDetailH5.yml'
    @allure.feature("app_redp_detail_comm_case")
    @pytest.mark.parametrize("data,errorcode",C.get_data(h5_redp_detail_yml),
                             ids=C.get_case_name(h5_redp_detail_yml))
    def test_h5_redp_detail(self,data,errorcode):
        res = self.preCard.h5_redp_detail(self.session,data)
        #返回参数有err和errmsg
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != "00":
                # 如果登录不成功，贴一下errormsg
                allure.attach("errormsg: ",errormsg)
                allure.attach("实际errorcode：",err)
            assert errorcode == err
        #返回参数没有err和errmsg
        except:
            ret = res.json()['retCode']
            retMsg = res.json()['retMsg']
            if ret != '00':
                allure.attach("retMsg: ",retMsg)
                allure.attach("实际errorcode：",ret)
                assert errorcode == ret
        allure.attach("预期errorcode：",errorcode)

    redp_sendinfo_yml = base.file_path + '/data/redpacket/redpsenderInfo.yml'
    @allure.feature("app_redp_detail_comm_case")
    @pytest.mark.parametrize("data,errorcode",C.get_data(redp_sendinfo_yml),
                             ids=C.get_case_name(redp_sendinfo_yml))
    def test_app_redp_detail(self,data,errorcode):
        res = self.preCard.redp_sender_Info(self.session,data)
        #返回参数有err和errmsg
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != "00":
                # 如果登录不成功，贴一下errormsg
                allure.attach("errormsg: ",errormsg)
                allure.attach("实际errorcode：",err)
            assert errorcode == err
        #返回参数没有err和errmsg
        except:
            ret = res.json()['retCode']
            retMsg = res.json()['retMsg']
            if ret != '00':
                allure.attach("retMsg: ",retMsg)
                allure.attach("实际errorcode：",ret)
                assert errorcode == ret
        allure.attach("预期errorcode：",errorcode)

    recv_redp_record_yml = base.file_path + '/data/redpacket/recvRedPacketRecord.yml'
    @allure.feature("recv_redp_record_comm_case")
    @pytest.mark.parametrize("data,errorcode",C.get_data(recv_redp_record_yml),
                             ids=C.get_case_name(recv_redp_record_yml))
    def test_recv_redp_record(self,data,errorcode):
        res = self.preCard.redp_receive_record(self.session,data)
        #返回参数有err和errmsg
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != "00":
                # 如果登录不成功，贴一下errormsg
                allure.attach("errormsg: ",errormsg)
                allure.attach("实际errorcode：",err)
            assert errorcode == err
        #返回参数没有err和errmsg
        except:
            ret = res.json()['retCode']
            retMsg = res.json()['retMsg']
            if ret != '00':
                allure.attach("retMsg: ",retMsg)
                allure.attach("实际errorcode：",ret)
                assert errorcode == ret
        allure.attach("预期errorcode：",errorcode)


    send_redp_record_yml = base.file_path + '/data/redpacket/sendRedPacketRecord.yml'
    @allure.feature("send_redp_record_comm_case")
    @pytest.mark.parametrize("data,errorcode",C.get_data(send_redp_record_yml),
                             ids=C.get_case_name(send_redp_record_yml))
    def test_send_redp_record(self,data,errorcode):
        res = self.preCard.redp_send_record(self.session,data)
        #返回参数有err和errmsg
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != "00":
                # 如果登录不成功，贴一下errormsg
                allure.attach("errormsg: ",errormsg)
                allure.attach("实际errorcode：",err)
            assert errorcode == err
        #返回参数没有err和errmsg
        except:
            ret = res.json()['retCode']
            retMsg = res.json()['retMsg']
            if ret != '00':
                allure.attach("retMsg: ",retMsg)
                allure.attach("实际errorcode：",ret)
                assert errorcode == ret
        allure.attach("预期errorcode：",errorcode)