import pytest
import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import allure


import os, sys
path = os.path.abspath(__file__)
for i in range(2):
    path = os.path.dirname(path)
    sys.path.append(path)
import base
from apis.comm import PreCard




class TestQrc:

    def setup(self):
        self.session = requests.session()
        self.preCard = PreCard()
        self.tmp = globals()

    def teardowm(self):
        self.session.close()
    C = PreCard()

    parse_mpqrc_payload_yml = base.file_path + '/data/qrc/parse_mpqrc_payload.yml'
    @allure.feature("parseMpqrcPayload")
    @pytest.mark.parametrize("data,errorcode",C.get_data(parse_mpqrc_payload_yml),ids=C.get_case_name(parse_mpqrc_payload_yml))
    def test_parse_mpqrc_payload(self,data,errorcode):
        print(data)
        res = self.preCard.parse_mpqrc_payload(self.session,data)
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != '00':
                allure.attach("errormsg: ", errormsg)
                allure.attach("实际errorcode：", err)
            assert errorcode == err
    #传参mpqrcPayload，响应体为空
        except:
            ret = res.json()['retCode']
            retmsg = res.json()['retMsg']
            allure.attach("实际errorcode: ", ret)
            allure.attach("errormsg：", retmsg)
            assert errorcode == ret

    mpqrc_payment_emv_yml = base.file_path + '/data/qrc/mpqrc_payment_emv.yml'
    @allure.feature("mpqrcPaymentEMV")
    @pytest.mark.parametrize('data,errorcode',C.get_data(mpqrc_payment_emv_yml),ids=C.get_case_name(mpqrc_payment_emv_yml))
    def test_mpqrc_payment_emv(self,data,errorcode):
        res = self.preCard.mpqrc_payment_emv(self.session,data)
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != '00':
                allure.attach("errormsg: ", errormsg)
                allure.attach("实际errorcode：", err)
            assert errorcode == err
        except:
            ret = res.json()['retCode']
            retmsg = res.json()['retMsg']
            allure.attach("实际errorcode: ", ret)
            allure.attach("errormsg：", retmsg)
            assert errorcode == ret

    mpqrc_payment_url_yml = base.file_path + '/data/qrc/mpqrc_payment_url.yml'
    @allure.feature("mpqrcPaymentURl")
    @pytest.mark.parametrize('data,errorcode',C.get_data(mpqrc_payment_url_yml),ids=C.get_case_name(mpqrc_payment_url_yml))
    def test_mpqrc_payment_url(self,data,errorcode):
        res = self.preCard.mpqrc_payment_url(self.session,data)
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != '00':
                allure.attach("errormsg: ", errormsg)
                allure.attach("实际errorcode：", err)
            assert errorcode == err
        except:
            ret = res.json()['retCode']
            retmsg = res.json()['retMsg']
            allure.attach("实际errorcode: ", ret)
            allure.attach("errormsg：", retmsg)
            assert errorcode == ret

    qrc_info_inquiry_yml = base.file_path + '/data/qrc/qrc_info_inquiry.yml'
    @allure.feature("qrcinfoinquiry")
    @pytest.mark.parametrize('data,errorcode',C.get_data(qrc_info_inquiry_yml),ids=C.get_case_name(qrc_info_inquiry_yml))
    def test_qrc_info_inquiry(self,data,errorcode):
        res = self.preCard.qrc_info_inquiry(self.session,data)
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != '00':
                allure.attach("errormsg: ", errormsg)
                allure.attach("实际errorcode：", err)
            assert errorcode == err
        except:
            ret = res.json()['retCode']
            retmsg = res.json()['retMsg']
            allure.attach("实际errorcode: ", ret)
            allure.attach("errormsg：", retmsg)
            assert errorcode == ret

    trx_result_inquiry_yml = base.file_path + '/data/qrc/trx_result_inquiry.yml'
    @allure.story('trxresultinquiry')
    @pytest.mark.parametrize('data,errorcode',C.get_data(trx_result_inquiry_yml),ids=C.get_case_name(trx_result_inquiry_yml))
    def test_trx_result_inquiry(self,data,errorcode):
        res = self.preCard.trx_result_inquiry(self.session,data)
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != '00':
                allure.attach("errormsg: ", errormsg)
                allure.attach("实际errorcode：", err)
            assert errorcode == err
        except:
            ret = res.json()['retCode']
            retmsg = res.json()['retMsg']
            allure.attach("实际errorcode: ", ret)
            allure.attach("errormsg：", retmsg)
            assert errorcode == ret


    trx_result_inquiry_yml = base.file_path + '/data/qrc/get_additional_processing.yml'
    @allure.story('getadditionalprocessing')
    @pytest.mark.parametrize('data,errorcode',C.get_data(trx_result_inquiry_yml),ids=C.get_case_name(trx_result_inquiry_yml))
    def get_additional_processing(self,data,errorcode):
        res = self.preCard.get_additional_processing(self.session,data)
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']

            if err != '00':
                allure.attach("errormsg: ", errormsg)
                allure.attach("实际errorcode：", err)
            assert errorcode == err
        except:
            ret = res.json()['retCode']
            retmsg = res.json()['retMsg']
            allure.attach("实际errorcode: ", ret)
            allure.attach("errormsg：", retmsg)
            assert errorcode == ret

    additional_processing_result_yml = base.file_path + '/data/qrc/additional_processing_result.yml'
    @allure.feature('additionalProcessingResult')
    @pytest.mark.parametrize('data,errorcode',C.get_data(additional_processing_result_yml),ids=C.get_case_name(additional_processing_result_yml))
    def test_additional_processing_result(self,data,errorcode):
        res = self.preCard.additional_processing_result(self.session,data)
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != '00':
                allure.attach("errormsg: ", errormsg)
                allure.attach("实际errorcode：", err)
            assert err == errorcode
        except:
            ret = res.json()['retCode']
            retmsg = res.json()['retMsg']
            allure.attach("实际errorcode: ", ret)
            allure.attach("errormsg：", retmsg)
            assert errorcode == ret

    additional_processing_result_yml = base.file_path + '/data/qrc/find_last_result.yml'
    @allure.feature('findlastResult')
    @pytest.mark.parametrize('data,errorcode',C.get_data(additional_processing_result_yml),ids=C.get_case_name(additional_processing_result_yml))
    def test_find_last_result(self,data,errorcode):
        res = self.preCard.find_last_result(self.session,data)
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != '00':
                allure.attach("errormsg: ", errormsg)
                allure.attach("实际errorcode：", err)
            assert err == errorcode
        except:
            ret = res.json()['retCode']
            retmsg = res.json()['retMsg']
            allure.attach("实际errorcode: ", ret)
            allure.attach("errormsg：", retmsg)
            assert errorcode == ret






if __name__ == '__main__':
    pytest.main(["-q", "-s", f"{__file__}"])

