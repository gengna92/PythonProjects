import time
import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import allure

import os, sys
path = os.path.abspath(__file__)
for i in range(2):
    path = os.path.dirname(path)
    sys.path.append(path)
import base
from apis.comm import PreCard




class TestComm:

    def setup(self):
        self.session = requests.session()
        self.preCard = PreCard()
        self.t = globals()

    def teardowm(self):
        self.session.close()


    #设置预付卡：1.登录获取sessionId，2.调用genMsgInfo获取msgID,3.获取qrctoken,4.设置预付卡 5.断言
    @allure.story("设置默认卡")
    @allure.severity('blocker')
    def test_set_default_card(self):
        allure.attach("from genMsgInfo get MsgInfo")
        msg_info = self.preCard.genMsgInfo()
        self.t['msgID'] = msg_info
        allure.attach("from get_qrcToken get CardInfo")
        qrc_token = self.preCard.get_qrcToken()
        self.t['qrc_token'] = qrc_token
        self.data = {
            "msgInfo": {
                "insID": 123456,
                "msgID": self.t['msgID'],
                "msgType": "string",
                "timeStamp": 20200921100936,
                "versionNo": "string"
            },
            "trxInfo": {
                "flag": 1,
                "token": self.t['qrc_token']
            }
        }
        res = self.preCard.setCardDefaultNew(self.session,self.data)
        print(res.json())
        responseCode = res.json()['msgResponse']['responseCode']
        if responseCode == '996':
            allure.attach("已经是默认卡",responseCode)
            print("已经是默认卡")
        elif responseCode == '00':
            n = len(res.json()['userCardInfoDtoList'])
            for i in range(n):
                qrctoken = res.json()['userCardInfoDtoList'][i]['qrcToken']
                if qrctoken != qrc_token:
                    continue
                else:
                    flag = res.json()['userCardInfoDtoList'][i]['defaultFlag']
                    allure.attach("设置默认卡成功",flag)
                    print("设置默认卡成功")
                    assert flag == 1
        else:
            allure.attach(Exception)
            # raise Exception

    #设置隐藏卡：1.登录获取sessionId,2.设置隐藏卡 3.断言，4.清理数据
    @allure.story("设置隐藏卡")
    @allure.severity('blocker')
    def test_set_hide_card(self):
        self.token = "6292690111333318"
        self.data = [{
            "trxInfo": {
                "flag": 1,
                "token": self.token
            }
        },{
            "trxInfo": {
                "flag": 0,
                "token": self.token
            }
        }]
        res = self.preCard.set_card_hide(self.session,self.data[0])
        print(self.data)
        print(res.json())
        responseCode = res.json()['msgResponse']['responseCode']
        if responseCode == '996':
            allure.attach("已经隐藏",responseCode)
            print("已经隐藏")
        elif responseCode == '00':
            n = len(res.json()['userCardInfoDtoList'])
            for i in range(n):
                qrctoken = res.json()['userCardInfoDtoList'][i]['qrcToken']
                if qrctoken != self.token:
                    continue
                else:
                    flag = res.json()['userCardInfoDtoList'][i]['hideFlag']
                    allure.attach("设置隐藏卡成功",flag)
                    print("设置隐藏卡成功")
                    assert flag == 1
        else:
            allure.attach(Exception)
            # raise Exception
        #清理数据
        self.preCard.set_card_hide(self.session,self.data[1])




    #1.获取卡密，2.绑定，3.删除已使用的卡密，4.获取客户卡list，5.断言是否真的绑定成功
    @allure.story("app绑人民币卡")
    def test_app_bind_cny(self):
        #绑定之前获取客户拥有卡数量
        num = self.preCard.get_card_count()
        cny_file = base.file_path + '/data/CNY.txt'
        cards = self.preCard.get_card(cny_file)
        if len(cards)>0:
            card  = cards[-1]
            self.t['cny_card'] = card
        else:
            print("卡密已用完")
        self.data = {
            "mobileNo": "+8618910358208",
            "cardPwd": self.t['cny_card']
        }
        #绑定操作
        res = self.preCard.app_bind(self.session,self.data)
        ec = res.json()['msgResponse']['responseCode']
        #绑定成功
        if ec == '00':
            #删除已使用的卡密
            self.preCard.del_used_card(cny_file)
            #等待1分钟才会有结果
            time.sleep(60)
            #查询绑定后卡数量
            num_new = self.preCard.get_card_count()
            assert num_new > num
        #卡已经被绑定，删除
        elif ec == '1002':
            self.preCard.del_used_card(cny_file)
        else:
            allure.attach(Exception)
            # raise Exception

    #1.获取卡密，2.绑定，3.删除已使用的卡密，4.获取客户卡list，5.断言是否真的绑定成功
    @allure.story("app绑美元卡")
    def test_app_bind_usd(self):
        #绑定之前获取客户拥有卡数量
        num = self.preCard.get_card_count()
        usd_file = base.file_path + '/data/USD.txt'
        cards = self.preCard.get_card(usd_file)
        if len(cards)>0:
            card  = cards[-1]
            self.t['usd_card'] = card
        else:
            print("卡密已用完")
        self.data = {
            "mobileNo": "+8618910358208",
            "cardPwd": self.t['usd_card']
        }

        #绑定操作
        res = self.preCard.app_bind(self.session,self.data)
        ec = res.json()['msgResponse']['responseCode']
        if ec == '00':
            self.preCard.del_used_card(usd_file)
            #等待1分钟才会有结果
            time.sleep(60)
            #查询绑定后卡数量
            num_new = self.preCard.get_card_count()
            assert num_new > num
        elif ec == '1002':
            self.preCard.del_used_card(usd_file)
        else:
            allure.attach(Exception)
            # raise Exception

    #生成付款码：1.登录获取sessionId，2.调用genMsgInfo获取msgID,3.获取qrctoken,4.生成付款码 5.断言
    @allure.story("生成付款码")
    @allure.severity('blocker')
    def test_set_default_card(self):
        allure.attach("from genMsgInfo get MsgInfo")
        msg_info = self.preCard.genMsgInfo()
        self.t['msgID'] = msg_info
        allure.attach("from get_qrcToken get CardInfo")
        qrc_token = self.preCard.get_qrcToken()
        self.t['qrc_token'] = qrc_token
        self.data = {
            "msgInfo": {
                "msgID": self.t['msgID'],
                "timeStamp": "20210323162631",
                "insID": ""
            },
            "trxInfo": {
                "token": self.t['qrc_token'],
                "userID": "PB10001000",
                "deviceID": "NEFFREEZOTMTMJY5MY00RDI3LTG2MUUTMDQ1ODUWRTC2OD",
                "cpqrcNo": "1",
                "limitCurrency": "840",
                "trxLimit": "10000",
                "cvmLimit": "0",
                "riskInfo": {
                    "appUserID": "e4fb3601e304321a365cb527caca43d2",
                    "reservedMobileNo": "86-18910358208"
                }
            },
            "token": self.t['qrc_token']
        }
        res = self.preCard.qrcGeneration(self.session,self.data)
        responseCode = res.json()['msgResponse']['responseCode']
        #todo:emvCpqrcPayload 调银联接口消费
        #emvCpqrcPayload = res.json()['']['emvCpqrcPayload']
        assert responseCode == "00"




