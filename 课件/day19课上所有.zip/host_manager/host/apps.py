from django.apps import AppConfig


class HostConfig(AppConfig):
    name = 'host'
