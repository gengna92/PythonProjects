from django.contrib import admin
from host import models

# Register your models here.
admin.site.register(models.User)
