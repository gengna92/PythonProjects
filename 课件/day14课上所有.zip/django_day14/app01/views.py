from django.shortcuts import render, HttpResponse, redirect
from app01 import models


def index(request):
    # ret = models.User.objects.all()    # 对象列表   QuerySet
    # for i in ret:
    #     print(i.username,i.password)
    #
    ret = models.User.objects.filter(username='alex',password='1234')
    print(ret)
    return HttpResponse('<h1>index页面</h1>')


def login(request):
    error = ''
    print(request.path_info)
    
    if request.method == 'POST':
        # 获取提交的数据
        # print(request.POST)
        user = request.POST.get('user')
        pwd = request.POST.get('pwd')
        if models.User.objects.filter(username=user,password=pwd):
            return redirect('/index/')  # Location: /index/
        
        error = '用户名或密码错误'
    
    return render(request, 'login.html', {'error': error})
