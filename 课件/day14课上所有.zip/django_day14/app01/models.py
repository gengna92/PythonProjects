from django.db import models


# Create your models here.
class User(models.Model):
    uid = models.AutoField(primary_key=True)  # 主键  uid
    username = models.CharField(max_length=32)  # varchar(32)
    password = models.CharField(max_length=32)  # varchar(32)
