import socket

# 实例化一个socket对象
sk = socket.socket()

# 绑定IP和端口
sk.bind(('127.0.0.1', 8000))

# 监听
sk.listen()

while True:
    # 等待连接
    conn, addr = sk.accept()
    
    # 接收数据
    data = conn.recv(1024)
    print(data)
    
    # 发送数据
    conn.send(b'HTTP/1.1 200 OP\r\n\r\n')
    conn.send(b'<h1>ok</h1>')
    
    # 断开连接
    conn.close()
