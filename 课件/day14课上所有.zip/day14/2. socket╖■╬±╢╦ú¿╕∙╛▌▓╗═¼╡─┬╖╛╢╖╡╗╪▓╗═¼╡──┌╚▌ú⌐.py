import socket

# 实例化一个socket对象
sk = socket.socket()

# 绑定IP和端口
sk.bind(('127.0.0.1', 8000))

# 监听
sk.listen()

while True:
    # 等待连接
    conn, addr = sk.accept()
    
    # 接收数据
    data = conn.recv(1024)
    data = data.decode('utf-8')
    url = data.split()[1]
    
    # 发送数据
    conn.send(b'HTTP/1.1 200 OP\r\n\r\n')
    
    if url == '/index/':
        conn.send(b'<h1>index</h1>')
    elif url == '/home/':
        conn.send(b'<h1>home</h1>')
    else:
        conn.send(b'<h1>404 NOT found </h1>')
    
    # 断开连接
    conn.close()
