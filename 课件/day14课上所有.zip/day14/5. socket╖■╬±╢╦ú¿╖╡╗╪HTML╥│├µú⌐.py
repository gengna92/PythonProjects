import socket

# 实例化一个socket对象
sk = socket.socket()

# 绑定IP和端口
sk.bind(('127.0.0.1', 8000))

# 监听
sk.listen()


def index(url):
    with open('index.html','rb') as f:
        ret = f.read()
    return ret


def home(url):
    ret = '<h1>home  {}</h1>'.format(url)
    return ret.encode('utf-8')


def web(url):
    ret = 'xxxxxx'
    return ret.encode('utf-8')

list1 = [
    ('/index/', index),
    ('/home/', home),
    ('/web/', web),
]

while True:
    # 等待连接
    conn, addr = sk.accept()
    
    # 接收数据
    data = conn.recv(1024)
    data = data.decode('utf-8')
    url = data.split()[1]
    
    # 发送数据
    conn.send(b'HTTP/1.1 200 OP\r\n\r\n')
    
    func = None
    
    for i in list1:
        if i[0] == url:
            func = i[1]
            break
    if func:
        ret = func(url)
    else:
        ret = b'404 not found'
    
    conn.send(ret)
    
    # 断开连接
    conn.close()
