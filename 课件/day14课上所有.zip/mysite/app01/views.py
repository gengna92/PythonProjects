from django.shortcuts import render, redirect
from app01 import models


def publisher(request):
    # 从数据库中查询所有的出版社
    all_publisher = models.Publisher.objects.all()  # 对象类表  [ Publisher对象 ]
    
    return render(request, 'publisher_list.html', {'publishers': all_publisher})


# 添加出版社
def add_publisher(request):
    # 判断请求方式
    error = ''
    if request.method == 'POST':
        # 新增出版社到数据库中
        pub_name = request.POST.get('pub_name')
        
        if not pub_name:
            error = '出版社不能为空'
        
        if models.Publisher.objects.filter(name=pub_name):
            error = '出版社已存在'
        
        if not error:
            # 插入
            models.Publisher.objects.create(name=pub_name)
            # 重定向到展示页面
            return redirect('/publisher_list/')
    
    return render(request, 'add_publisher.html', {'error': error})


# 删除出版社
def del_publisher(request):
    # 获取删除id
    id = request.GET.get('id')
    # 删除对象
    models.Publisher.objects.filter(id=id).delete()

    # 重定向到展示页面
    return redirect('/publisher_list/')


# 编辑出版社
def edit_publisher(request):
    # 获取id
    id = request.GET.get('id')
    # 查询对象
    obj = models.Publisher.objects.filter(id=id)[0]
    
    error = ''
    if request.method == 'POST':
        # 获取提交的数据
        pub_name = request.POST.get('pub_name')
        
        if not pub_name:
            error = '出版社不能为空'

        if models.Publisher.objects.filter(name=pub_name):
            error = '出版社已存在'
            
        if not error:
            # 修改数据
            obj.name = pub_name   # 在内存中修改
            obj.save()            # 提交到数据库
            
            # 跳转到展示页面
            return redirect('/publisher_list/')
        
    return render(request,'edit_publisher.html',{'obj':obj,'error':error})