# 1.作业的视频
# 2.习题册 go 李文周 脱产班

# 今天的内容
    # 并发 ：线程 锁
    # 协程 ：
    # 数据库
        # 了解基础的存储引擎
        # 了解mysql的基本数据类型
        # 了解mysql的建表语句和约束
        # 增删改查表中的数据

# 同步异步 阻塞非阻塞
# 进程
    # 进程的三状态 ：运行 阻塞 就绪
    # 进程之间数据隔离 所有的内存资源 寄存器资源 文件资源 都是独立的
    # multiprocessing
        # Process(target=函数).start()
            # 子进程.join() 主进程在这里阻塞，直到子进程执行完毕
        # Lock锁：只有在操作文件、数据库才需要
        # IPC机制 ：帮助我们完成进程之间的通信的
                    # 队列 ：基于文件的
                    #  memcahe redis kafka rabbitmq ：基于网络的

# 线程
    # 数据共享，创建销毁切换的开销小于进程
    # cpython解释器  ：全局解释器锁GIL，线程不能利用多核
    # 推荐使用线程完成 ：所有的网络操作（爬虫，web server，数据库操作） 和 文件操作
    # threading
        # Thread(target=函数).start()
        # 锁
        # 线程队列

# 池
    # 开启有限的线程、进程 让这些线程、进程执行无限多的任务
    # concurrent.futrues
        # ThreadPoolExcutor
            # t = ThreadPoolExcutor(5)
            # res_obj = t.submit(函数)
            # res_obj.result()
        # ProcessPoolExcutor
        
# def func():
#     子进程的代码
#
# 开启子进程 ：发送探针
# for 子进程 in p_l:
#     子进程.join()
# 主进程的代码
