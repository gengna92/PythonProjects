import socket
from threading import Thread
def client():
    sk = socket.socket()
    sk.connect(('127.0.0.1',9000))
    while True:
        sk.send(b'yuan')
        print(sk.recv(1024))
    
for i in range(500):
    Thread(target=client).start()
    
# input()
# 文件操作

# 进程 + 协程
# 进程 + 线程 + 协程
    # 5进程 20线程 500个协程 = 50000