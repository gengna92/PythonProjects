# 计算机中一个基础的数据结构 先进先出

import queue # 数据安全的 严格执行数据进出顺序的队列模块

# 普通的先进先出队列 —— 响应请求的时候
# q = queue.Queue(5)
# q.put(1)
# q.put_nowait(1)
# q.put(3)
# q.put(2)
# print(q.get())
# print(q.get())
# print(q.get())
# print(q.get_nowait())

# 后进先出队列 —— 栈 算法
# q2 = queue.LifoQueue()
# q2.put(1)
# q2.put_nowait(1)
# q2.put(3)
# q2.put(2)
# print(q2.get())
# print(q2.get())
# print(q2.get())
# print(q2.get_nowait())

# 优先级队列
# pq = queue.PriorityQueue()
# pq.put((2,'alex'))
# pq.put((1,'wusirx'))
# pq.put((1,'hello'))
# pq.put((3,'sylar'))
#
# print(pq.get())
# print(pq.get())
# print(pq.get())
# print(pq.get())