import pymysql

# conn = pymysql.connect(host='127.0.0.1', user='root', password="",database='py25')
# cur = conn.cursor(pymysql.cursors.DictCursor)

# cur.execute('select * from emp2;')
# content = cur.fetchall()
# print(content)
# content = cur.fetchmany(2)
# print(content)
# content = cur.fetchone()
# print(content)
# content = cur.fetchone()
# print(content)

# try:
#     cur.execute("insert into emp2 values (7,'taibai','male',40,200);")
#     conn.commit()
# except:
#     conn.rollback()
# cur.close()
# conn.close()