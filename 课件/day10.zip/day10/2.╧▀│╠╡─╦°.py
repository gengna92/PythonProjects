# gil锁

# 线程锁

# 为什么有了gil还需要线程锁？
    # gil锁 是锁的是线程 保证了多个线程中的CPU指令永远不会被多个CPU同时执行
    # 线程锁 锁的是代码 保证了一行python代码涉及到的多条CPU指令永远不会被同时执行
# from threading import Thread,Lock
# import dis
# a = 0
# def func():
#     global a
#     lock.acquire()
#     a += 1   # a + 1
#              # a = 上面的结果
#     lock.release()
# lock = Lock()
# dis.dis(func)

# python的多线程中,数据不安全的情况
    # 只要是操作全局变量
    # 只要对全局变量 += -= *= \=

# l = [0]
# with lock:
#     l[0]+=1



# gil
# import dis
# a = []
# def func():
#     global a
#     a.append(1)
# dis.dis(func)


# from threading import Thread,Lock
# import os,time
# def work(lock):
#     global n
#     for i in range(500000):
#         with lock:
#             n+=1
#
# def work2(lock):
#     global n
#     for i in range(500000):
#         with lock:
#             n -= 1
# if __name__ == '__main__':
#     n=100
#     l=[]
#     lock = Lock()
#     for i in range(100):
#         p1=Thread(target=work,args=(lock,))
#         p2=Thread(target=work2,args=(lock,))
#         l.append(p1)
#         l.append(p2)
#         p1.start()
#         p2.start()
#     for p in l:
#         p.join()
#
#     print(n) #结果可能为99



# 互斥锁
# 在同一个线程中 不能连续acquire多次
# from threading import Lock
#
# lock = Lock()
# lock.acquire()
# print(1)
# lock.acquire()
# lock.release()
# print(2)

# 死锁现象
# 递归锁


# 进程 ：多个进程同时操作一个文件的时候
# 线程 ：多个线程同时操作同一个全局变量 且 用到了 += -=
