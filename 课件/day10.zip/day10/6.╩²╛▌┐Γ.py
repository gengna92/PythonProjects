# 你的数据库
    # 数据库也是C/S架构
    # server  mysqld install
    # net strat mysql  启动了mysql的server端
    
    # 我们去使用或者处理的只能是client端
        # 所有的编程语言
        # 可视化工具 ：navicat
        # mysql软件自带的 mysql.exe
  
# 忘记密码 就重启服务 添加参数--skip-grant-tables
# net start mysql --skip-grant-tables


# 非关系型数据库
    # mongodb
    # redis
    
# mysql数据库
    # 关系型数据库

# 存储引擎
    # 存储数据的方式
    # myisam
        # mysql5.5 以及之前 所用的默认的存储引擎
        # 表级锁
    # innodb
        # 5.6 之后 默认的存储引擎
        # 事务  多条指令是完整的一体，要么一起成功，要么一起失败
        # 行级锁、支持表锁
        # 外键
    
# 基础的数据类型
    # 数字
        # 整数 int
        # 小数 float
        
    # 字符串，描述的都是字符
        # char 定长字段 255 相对浪费空间 存取的速度比varchar要快
            # char（10）
            # 'hellohello1'  --> 'hellohello'
            # 'hello      '
        # varchar  变长字段 65535  相对节省空间 存取的速度比varchar要慢
            # varchar(200)
            # 'hellohello1'  --> '10hellohello'
            # 'hello'  --> '5hello'
        # 常见的场景
            # 手机号 char(11)
            # 身份证号 char(18)
            # 用户名 char（14）
            # 密码 char（12）
            # 评论 varchar
    # 时间
        # datetime
    # 集合和枚举
        # hobby set('抽烟'，'喝酒','烫头')
        # gender enum('男','女')
 
        
# create table 表名字 (
# 第一个字段的名字 这个字段的数据类型(长度) 约束条件，
# 第二个字段的名字 这个字段的数据类型(长度) 约束条件，
# 第三个字段的名字 这个字段的数据类型(长度) 约束条件，
# 第四个字段的名字 这个字段的数据类型(长度) 约束条件，
# 第五个字段的名字 这个字段的数据类型(长度) 约束条件，
# );

# employee
# id　　	name　　	age　　	sex　　	phone　　	job　
# create table employee (
# id int,
# name char(10),
# age int,
# sex enum('male','female'),
# phone char(11),
# job char(10)
# ) charset = utf8;

# 创建表
# create table employee2 (
# id int primary key,
# name char(10) not null,
# age int,
# sex enum('male','female') not null default 'male',
# phone char(11) unique,
# job char(10)
# );

# 用到一些特殊的数据类型
# create table teacher (
# id int primary key auto_increment,
# name char(10) not null,
# age int,
# hire_date datetime,
# sex enum('male','female') not null default 'male',
# phone char(11) unique,
# salary float(8,2),
# hooby set('抽烟','喝酒','烫头','洗脚'),
# comment varchar(255)
# );

# 插入数据
# insert into 表名 (字段1，字段2，字段3.。。) value (值1，值2，值3);
# insert into 表名 value (值1，值2，值3);
# insert into 表名 values (值1，值2，值3),(值1，值2，值3),(值1，值2，值3);

# insert into teacher (id,name) value (1,'alex');
# insert into teacher value (2,'alex_sb',84,19980809112209,'male','13838384438',1000000.015,'抽烟,喝酒,喝酒,毒鸡汤',null);
# insert into teacher value (2,'alex_sb',84,'1998-08-09 11:22:09');
# insert into teacher (id,name) values (4,'wusir'),(5,'yuan'),(6,'sylar');

# 更新数据
# update
# update 表名 set 列名 = 值
# update 表名 set 列名 = 值 where 条件

# 把整张表所有人的年龄都改成18岁
# update teacher set age = 18;
# update teacher set hobby = '抽烟,喝酒' where id = 1;
# update teacher set hobby = '抽烟,喝酒',sex='female' where id = 1;


# 删除数据
# delete
# delete from 表;  清空表
# delete from teacher where sex = 'male';

# 查询
    # 单表查询
        # select distinct 字段  from 表 where 条件
        #                      group by 分组
        #                      having  过滤
        #                      order by 排序
        #                      limit 取前多少
        
        # 简单的select语句
            # select * from 表
            # select 字段 from 表
            # select 字段1，字段2 from 表
            # select 字段1，字段2 as 别名 from 表
            # select 字段1，字段2 别名 from 表
            # select 字段1，字段2*12 别名 from 表
            # select 字段1，concat('你想拼接的字符串',字段2*12) 别名 from 表
            # case when
           #  SELECT
           # (
           #     CASE
           #     WHEN emp_name = 'jingliyang' THEN
           #         emp_name
           #     WHEN emp_name = 'alex' THEN
           #         CONCAT(emp_name,'_BIGSB')
           #     ELSE
           #         concat(emp_name, 'SB')
           #     END
           # ) as new_name
           # FROM
           #     emp;
        # where 条件
            # 比较运算 ：> < >= <= <>!=
            # 范围 between and
                # in (1,2,3)
            # 逻辑运算符 ：not or and
            # like 'e%'
                #     通配符可以是%或_，
                #     %表示任意多字符
                #     _表示一个字符   a___   ab aa ac alex
        
            # 关于null
                # is null
                # is not null
                # not in + null 会让后面的这个条件失效(null,1000,2000,3000)
            
        # group by
            # 根据某一个字段进行分组
            # 为了对这个组中的数据进行统计 或者是 过滤
            # 各个部门各有多少人？
            
        # having 和group by不能分开用
            # 先分组，再过滤
            # 查询各岗位平均薪资大于10000的岗位名、平均工资
            # select post,avg(salary) group by post having avg(salary) > 10000;
            # 查询各岗位平均薪资大于10000且小于20000的岗位名、平均工资
            # select post,avg(salary) group by post having avg(salary) > 10000 and avg(salary) < 10000;
            
            # having :能够根据分组 + 聚合函数来进行过滤
    # 多表查询
        # 表与表笛卡尔积
        # 连表查询（效率更高）
            # 内连接  只显示匹配条件的行
                # inner join
                # select * from 表 inner join 表2 on 表.dep_id = 表2.id
                # select * from emp2 as t1 inner join department as t2 on t1.dep_id = t2.id
            # 外连接
                # 左外  left join 完整的显示左表 和右表中符合条件的项目
                # select * from emp2 as t1 left join department as t2 on t1.dep_id = t2.id
                # 右外 right join
                # select * from emp2 as t1 right join department as t2 on t1.dep_id = t2.id
                # 全外
                # select * from emp2 as t1 left join department as t2 on t1.dep_id = t2.id
                # union
                # select * from emp2 as t1 right join department as t2 on t1.dep_id = t2.id
            # 以内连接的方式查询emp2和department表，并且emp2表中的age字段值必须大于25,
            # 即找出年龄大于25岁的员工以及员工所在的部门
            # select t1.name as emp_name,t2.name dep_name from emp2 as t1 inner join department as t2 on t1.dep_id = t2.id where age >25;
            # select * from emp2 as t1 inner join department as t2 on t1.dep_id = t2.id order by age;
            
            # 部门是人力资源的所有同事的名字
            # select * from emp2 as t1 inner join department as t2 on t1.dep_id = t2.id where t2.name = '人力资源'；
            
        # 子查询（效率相对低）
            # 往往查询a表时依赖的某一个字段 是b表的内容
            # 部门是人力资源的所有同事的名字
            # select id from department where name = '人力资源';
            # select name from emp2 where dep_id = 201;
            
            # select name from emp2 where dep_id = (select id from department where name = '人力资源');
            
            # 查询平均年龄在25岁以上的部门名
            # select dep_id from emp2 group by dep_id having avg(age) >25;
            # select * from department where dep_id in (201,202)
            
            # select name from department where id in (select dep_id from emp2 group by dep_id having avg(age) >25);
            
            # 查看技术部员工姓名
            # select id from department where name = '技术';
            # select name from emp2 where id = (select id from department where name = '技术');
            
            
            # 查看不足1人的部门名(子查询得到的是有人的部门id)
            # select dep_id from emp2 group by dep_id;
            # select name from department where id not in (select dep_id from emp2 group by dep_id);
            
            # 查询大于所有人平均年龄的员工名与年龄
            # select avg(age) from emp2;
            # select name,age from emp2 where age > (select avg(age) from emp2);
            
            # 查询大于部门内平均年龄的员工名、年龄
            # select dep_id,avg(age) from emp2 group by dep_id;
            # select * from emp2 inner join (select dep_id,avg(age) as avg_age from emp2 group by dep_id) t2 on emp2.dep_id = t2.dep_id;

            # 查询每个部门最新入职的那位员工
            # select post,max(hire_date) from emp group by post;
# select emp.emp_name from emp inner join (select post,max(hire_date) as max_date from emp group by post) t2
# on emp.post = t2.post where emp.hire_date = t2.max_date;


# 事务
# begin；
# select * from 表 where 条件 for update；
# update 表 set 字段=值 where 条件；
# commit；

# 主键
# unique
# 拥有这两个约束的所有的字段 都自带索引
# 自己添加索引
    # create index 索引名 on 表名(字段名)