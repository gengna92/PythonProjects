# import time
# from threading import Thread,Lock
# noodle_lock = Lock()
# fork_lock = Lock()
# def eat1(name):
#     noodle_lock.acquire()
#     print('%s 抢到了面条'%name)
#     fork_lock.acquire()
#     print('%s 抢到了叉子'%name)
#     print('%s 吃面'%name)
#     fork_lock.release()
#     noodle_lock.release()
#
# def eat2(name):
#     fork_lock.acquire()
#     print('%s 抢到了叉子' % name)
#     time.sleep(0.1)
#     noodle_lock.acquire()
#     print('%s 抢到了面条' % name)
#     print('%s 吃面' % name)
#     noodle_lock.release()
#     fork_lock.release()
#
# for name in ['哪吒','egon','yuan']:
#     t1 = Thread(target=eat1,args=(name,))
#     t2 = Thread(target=eat2,args=(name,))
#     t1.start()
#     t2.start()
#
# 会出现死锁现象
# 多把锁 多个线程 在多个线程中出现了多把锁交替使用的情况

# 递归锁
# 可重入锁
# 在同一个线程内 可以连续被acquire任意次数
# from threading import RLock
#
# rlock = RLock()
# rlock.acquire()
# rlock.acquire()
# rlock.acquire()
# rlock.acquire()
# print(1)

import time
from threading import Thread,RLock
fork_lock = noodle_lock = RLock()
def eat1(name):
    noodle_lock.acquire()
    print('%s 抢到了面条'%name)
    fork_lock.acquire()
    print('%s 抢到了叉子'%name)
    print('%s 吃面'%name)
    fork_lock.release()
    noodle_lock.release()

def eat2(name):
    fork_lock.acquire()
    print('%s 抢到了叉子' % name)
    time.sleep(0.1)
    noodle_lock.acquire()
    print('%s 抢到了面条' % name)
    print('%s 吃面' % name)
    noodle_lock.release()
    fork_lock.release()

for name in ['哪吒','egon','yuan']:
    t1 = Thread(target=eat1,args=(name,))
    t2 = Thread(target=eat2,args=(name,))
    t1.start()
    t2.start()

# 多个线程之间还是互斥的，但是在同一个线程中可以被ACQUIRE多次而不产生死锁
# 互斥锁 效率高 但是偶尔容易出现多把锁的死锁现象
# 递归锁 但是不容易出现死锁现象(把原本的多把互斥锁换成一把递归锁，所有的死锁现象都会解决)，效率相对低
# 尽量使用互斥锁，出了问题先改成递归锁，然后再慢慢优化代码，看看能不能改成互斥锁也不产生死锁


# lock.aquire()
# a+=1
# b+=1
# lock.release()









