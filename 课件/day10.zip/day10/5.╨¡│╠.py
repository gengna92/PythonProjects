# 协程的本质就是一条线程，在一条线程上来回切换 就是协程

# def eat():
#     print('start eating')
#     time.sleep(1)
#     print('end eating')
#
# def sleep():
#     print('start sleeping')
#     time.sleep(1)
#     print('end sleeping')
#
# eat()
# sleep()

# 不需要开启多线程了 减少了线程的开销
# 不管多少个任务 开协程都不需要被操作系统感知到
# 任务之间的调度也不会给操作系统带来压力
# 我的多个任务同时执行 第一 共享了io时间，第二 给操作系统造成一个假象 就是线程很忙 从而多给我分配时间片
# from gevent import monkey
# monkey.patch_all()
# import time
# import gevent   # 默认 遇到自己认识的io操作才切换
# def eat():
#     print('start eating')
#     time.sleep(1)
#     print('end eating')
#
# def sleep():
#     print('start sleeping')
#     time.sleep(1)
#     print('end sleeping')
# g1 = gevent.spawn(eat)
# g2 = gevent.spawn(sleep)
# # g1.join()
# # g2.join()
# gevent.joinall([g1,g2])

# 两个例子
    # socket server
    # 爬虫
# from gevent import monkey
# monkey.patch_all()
# import socket
# import gevent
# def talk(conn):
#     while True:
#         msg = conn.recv(1024)
#         print(msg)
#         conn.send(b'received')
#
# sk = socket.socket()
# sk.bind(('127.0.0.1',9000))
# sk.listen()
#
# while True:
#     conn,addr = sk.accept()
#     gevent.spawn(talk,conn)
from gevent import monkey   # greenlet swith
monkey.patch_all()
import time
import gevent
from urllib import request


def get_url(url,filename):
    res = request.urlopen(url)
    with open(filename,'wb') as f:
        f.write(res.read())


url_list = [
    ('http://www.baidu.com','baidu'),
    ('http://www.cnblogs.com/Eva-J/articles/8306047.html','cnblog1'),
    ('http://www.sogou.com','sogou'),
    ('http://www.douban.com','douban'),
    ('http://www.JD.com','jd')
]

start = time.time()
for url,name in url_list:
    get_url(url,name+'.html')
print(time.time() - start)


start = time.time()
g_l = []
for url,name in url_list:
    g = gevent.spawn(get_url,url,name)
    g_l.append(g)
gevent.joinall(g_l)
print(time.time() - start)


# tornado yield
# asyncio














