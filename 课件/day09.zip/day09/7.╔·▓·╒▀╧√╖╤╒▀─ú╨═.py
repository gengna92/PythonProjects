# python生产者消费者模型

# 两个进程
    # 一个进程负责生产数据 producer
    # 一个进程负责消费数据 consumer

# IPC
    # INTER PROCESS COMMUNICATION 进程之间通信
# kafka rabitmq redis memcache mongodb
# python multiprocessing IPC机制 能够帮助我们在两个进程之间进行通信

# Queue 队列 ：管道+锁
# 管道 Pipe : 在进城之间数据不安全 +锁
# socket 基于文件家族的

from multiprocessing import Process,Queue

# def consumer(q):
#     print('--->',q.get())
#
# def producer(q):
#     q.put({1,2,3})
#
# if __name__ == '__main__':
#     q = Queue()
#     Process(target=consumer,args=(q,)).start()
#     Process(target=producer,args=(q,)).start()

# q = Queue(5)
# q.get()
# q.get_nowait()
# q.put(123)   # 向队列中放数据 如果队列满了 那么就阻塞
# q.put(123)
# q.put(123)
# q.put(123)
# print('4444')
# q.put(123)
# print('55555')
# q.put(123)
# print('66666')
# q.put(123)
# q.put_nowait(123)  # 向队列中放数据 如果满 也不阻塞
# q.put_nowait(123)
# print('55555')

# q.empty()
# q.full()
# q.qsize()

import time
import random
from multiprocessing import Process,Queue

def consumer(name,q):
    while True:
        food = q.get()
        if food == None:break
        time.sleep(random.uniform(1,2))
        print('%s吃了%s'%(name,food))
    
def producer(n,q,food):
    for i in range(n):
        time.sleep(random.random())
        q.put('%s%s'%(food,i))
        print('生产了 %s%s'%(food,i))
        
if __name__ == '__main__':
    q = Queue()
    Process(target=consumer,args=('alex',q)).start()
    Process(target=consumer,args=('wusir',q)).start()
    p = Process(target=producer,args=(10,q,'泔水'))
    p.start()
    p.join() # 等待生产结束
    q.put(None)
    q.put(None)
    




