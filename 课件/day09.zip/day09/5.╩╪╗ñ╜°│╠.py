# 守护进程
# import time
# from multiprocessing import Process
# def is_alive():
#     for i in range(10):
#         time.sleep(1)
#         print('is alive')
#
# def main():
#     print('主进程中的内容')
#     time.sleep(0.5)
#     print('主进程中的内容')
#     time.sleep(0.5)
#     print('主进程中的内容')
#     time.sleep(0.5)
#     print('主进程中的内容')
#     time.sleep(0.5)
#     print('主进程中的内容')
# if __name__ == '__main__':
#     p = Process(target=is_alive)
#     p.daemon = True   # 设置子进程为一个守护进程
#     p.start()
#     main()
    
    
# 正常的情况下
# 主进程会等待所有的子进程结束之后才结束
# 回收资源

# 守护进程的特点 ：随着主进程的代码结束而结束
# import time
# from multiprocessing import Process
#
# def is_alive():
#     for i in range(10):
#         time.sleep(1)
#         print('is alive')
#
# def son2():
#     time.sleep(2)
#     print('in son2')
#     time.sleep(2)
#     print('in son2')
#
# def main():
#     print('主进程中的内容')
#     time.sleep(0.5)
#     print('主进程中的内容')
#     time.sleep(0.5)
#     print('主进程中的内容')
#     time.sleep(0.5)
#     print('主进程中的内容')
#     time.sleep(0.5)
#     print('主进程中的内容')
#
#
# if __name__ == '__main__':
#     p = Process(target=is_alive)
#     p.daemon = True  # 设置子进程为一个守护进程
#     p.start()
#     p1 = Process(target=son2)
#     p1.start()
#     main()
#     p1.join()   # 主进程的最后一句代码

# 主进程  我
# 守护进程 等我离开
# 主进程我 是否要等学生离开 我的自由






# ipc机制

# 进程池