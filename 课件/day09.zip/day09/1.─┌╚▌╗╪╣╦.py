# 网络编程
# 应用层 python http协议
# socket
# 传输层  tcp、udp 、端口
# 网络层  ip
# 数据链路层 mac地址相关的  arp(ip找mac)
# 物理层

# socket是工作在哪儿呢？
# ip:端口 传输方式 ：tcp udp

# socket 概念 所有的应用层的网络协议都是基于socket来的

# socket是符合了 上面这个概念的 一个 在python中的工具模块
# server
import socket
# sk = socket.socket(type=socket.SOCK_DGRAM)  # udp
# sk = socket.socket(type=socket.SOCK_STREAM)  # tcp
# sk.bind(('127.0.0.1',9900))
# sk.listen()   # tcp

# conn,addr = sk.accept()    #tcp
# conn.recv
# conn.send

# udp
# msg,cli_addr = sk.recvfrom()
# sk.sendto(b'msg'.encode(),cli_addr)

# str --> utf-8/gbk字节
# py2.x的时候，socket可以直接发送或者接受字符串

# tcp协议的问题：
    # 粘包
        # 主要由于数据之间的界限不清晰
        # 自定义协议
            # 先发送要发送的数据的长度  struct
            # 再发送数据
    # 面向连接
        # 占线

# socketserver 处理socket tcp协议的并发问题的模块
# 自定义类 继承 baserequesthandler
# 重写handle方法
    # conn = self.request

# server = threadtcpserver((ip,port),自定义类)
# server.serve_forever()

