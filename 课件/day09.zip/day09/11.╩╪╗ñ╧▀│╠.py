import time
from threading import Thread
# 守护线程的面试题

def deamon_t():
    while True:
        time.sleep(1)
        print('is alive')
        
def thread_2():
    print('start t2')
    time.sleep(5)
    print('end t2')

def main():
    print('main start')
    time.sleep(1.5)
    print('main end')
    
t1 = Thread(target=deamon_t)
t2 = Thread(target=thread_2)
t1.daemon = True  # 守护线程守护子线程
t1.start()
t2.start()
main()


# 守护线程什么时候执行结束？？？
# 守护线程 会等待所有的子线程结束之后才结束
# 守护进程 是主进程代码结束就结束了 不会主动守护子进程
# 守护进程是怎么结束的？   守护进程只和主进程代码有关系
    # 主进程代码执行完 主进程没结束 守护进程先结束
    # 主进程回收守护进程的资源

# 守护线程到底是怎么结束的  守护线程永远是这个进程中最后结束的线程
    # 主线程 会等待所有的非守护线程结束
    # 主线程才结束
    # 主进程结束了
    # 守护线程才结束