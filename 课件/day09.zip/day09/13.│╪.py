# 池
# 100个任务
# 并发的效果
    # 100个进程
    # 100个线程

# 我们应该开100个进程么？
    # 8个
# 一个进程可以同时用两个cpu么？
# 一个进程可以有多个线程
# 一个进程中的多个线程 不能使用多核
# import time
# import random
# from concurrent.futures import ThreadPoolExecutor,ProcessPoolExecutor
#
# def func(n):
#     print('in son thread %s' % n)
#     time.sleep(random.randint(1,4))
#     print('end %s'%n)
#
#
# tp = ThreadPoolExecutor(10)
# for i in range(20):
#     tp.submit(func,i)
# tp.shutdown()   # 直接join整个线程池中的任务
# print('main')
    
# cpu个数*1 -cpu个数*2个进程
# cpu个数*5个线程

# 4c
# 5个进程 20条线程 100的并发
# 一条线程 再开500个协程
# 100 * 500 = 50000


# import time
# import random
# from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
#
# def func(n):
#     print('in son thread %s' % n)
#     time.sleep(random.randint(1, 4))
#     print('end %s' % n)
#
# if __name__ == '__main__':
#     tp = ProcessPoolExecutor(5)
#     for i in range(20):
#         tp.submit(func, i)
#     tp.shutdown()  # 直接join整个线程池中的任务
#     print('main')


# 获取返回值
# import time
# import random
# from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
#
# def func(n):
#     print('in son thread %s' % n)
#     time.sleep(random.randint(1, 4))
#     print('end %s' % n)
#     return n*'*'
#
# if __name__ == '__main__':
#     tp = ThreadPoolExecutor(5)
#     task_l = []
#     for i in range(20):
#         task_obj = tp.submit(func, i)
#         task_l.append(task_obj)
#     for task in task_l:
#         print(task.result())
#     print('main')


# 简化操作
# import time
# import random
# from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
#
# def func(n):
#     print('in son thread %s' % n)
#     time.sleep(random.randint(1, 4))
#     print('end %s' % n)
#     return n*'*'
#
# if __name__ == '__main__':
#     tp = ProcessPoolExecutor(5)
#     ret = tp.map(func,range(20))
#     for i in ret:
#         print(i)
#     print('main')

# 回调方法
# import time
# import random
# from urllib.request import urlopen
# from concurrent.futures import ThreadPoolExecutor,ProcessPoolExecutor
#
# def parser_page(ret):
#     dic = ret.result()
#     print(dic['url'],len(dic['html']))
#
#
# def get_html(url):
#     ret = urlopen(url)
#     html = ret.read()
#     return {'url':url,'html':html}
#
# tp = ThreadPoolExecutor(4)
# for url in ['https://www.cnblogs.com/Eva-J/articles/9374538.html','http://www.sogou.com','http://www.JD.com','http://www.qq.com','http://www.baidu.com']:
#     task_obj = tp.submit(get_html,url)
#     task_obj.add_done_callback(parser_page)












