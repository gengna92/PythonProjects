# import os
# import time
# from multiprocessing import Process
#
# def eating():
#     print('start eating',os.getpid())
#     time.sleep(1)
#     print('end eating',os.getpid())
#
# if __name__ == '__main__':
#     Process(target=eating).start()   # 异步
#     print(1234567)
#     time.sleep(0.1)
#     print(os.getpid(),os.getppid())  # process id  进程id  ppid parent process id
# 父进程
# 子进程

# 为什么在执行代码的时候要加上一句if __name__ == '__main__':
    # 不同的操作系统开启进程的方式不同，如果在win上，不加这句话 会产生一个创建子进程的递归现象
# 开启多个子进程呢？
# import os
# import time
# from multiprocessing import Process
#
# def eating():
#     print('start eating',os.getpid())
#     time.sleep(1)
#     print('end eating',os.getpid())
#
# if __name__ == '__main__':
#     for i in range(10):
#         Process(target=eating).start()   # 异步
#     print(1234567)
#     time.sleep(0.1)
#     print(os.getpid(),os.getppid())


# 能不能给子进程传递参数呢？
# import os
# import time
# from multiprocessing import Process
#
# def eating(i):
#     print('start eating %s'%i,os.getpid())
#     time.sleep(1)
#     print('end eating %s'%i,os.getpid())
#
# if __name__ == '__main__':
#     for i in range(10):
#         Process(target=eating,args=(i,)).start()   # 异步
#     print(1234567)
#     time.sleep(0.1)
#     print(os.getpid(),os.getppid())

# 能不能接收子进程返回的结果呢？   子进程的返回值是不能返回给主进程的
# import os
# import time
# from multiprocessing import Process
#
# def eating(i):
#     print('start eating %s'%i,os.getpid())
#     time.sleep(1)
#     print('end eating %s'%i,os.getpid())
#     return i**i
#
# if __name__ == '__main__':
#     for i in range(10):
#         p = Process(target=eating,args=(i,))
#         p.start()   # 异步
#     print(1234567)
#     time.sleep(0.1)
#     print(os.getpid(),os.getppid())


# 异步和同步
# import time
# from multiprocessing import Process
# def a():
#     time.sleep(1)
#     print('end a')
# if __name__ == '__main__':
#     p = Process(target=a)
#     p.start()
#     p.join()   # 在这里阻塞 直到p表示的子进程执行完毕才结束阻塞
#     print('a 执行完毕')


# import time
# import random
# from multiprocessing import Process
# def a(i):
#     time.sleep(random.random())
#     print('end a %s'%i)
# if __name__ == '__main__':
#     p_l = []
#     for i in range(10):
#         p = Process(target=a,args=(i,))
#         p.start()
#         p_l.append(p)
#     for p in p_l:
#         p.join()
#     print('a 执行完毕')


# 进程之间的数据隔离
# import os
# import time
# from multiprocessing import Process
# n = 0
# def add():
#     global n
#     n += 1
#
# if __name__ == '__main__':
#     p_l = []
#     for i in range(100):
#         p = Process(target=add)
#         p.start()   # 异步
#         p_l.append(p)
#     for p in p_l:p.join()
#     print(n)

