# 同步 :
# 两个事儿，当在a事件中调用b事件时，总是a事件要等待b事件有了结果之后再继续
# 异步 ：
# 两个事儿，当在a事件中调用b事件时，a事件不要等待b事件的结果就可以直接继续

# import time
# def eat():
#     time.sleep(1)
#     print('finished')
#     return True
#
# def main():
#     eat()
#     print('continue')

# def eat():
#     yield 1
#
# def main():
#     g = eat()
#     print('continue')
#     g.__next__()

# 阻塞 并不是io操作
    # input sleep recv accept recvfrom
# 非阻塞
    # 在程序的执行过程中 不会卡在某一个位置很长时间

# import socket
# sk = socket.socket()
# sk.setblocking(False)
# sk.bind(('127.0.0.1',9000))
# sk.listen()
# conn_l = []
# while True:
#     try:
#         conn,addr = sk.accept()
#         conn_l.append(conn)
#     except BlockingIOError:
#         for conn in conn_l:
#             try :
#                 msg = conn.recv(1024)
#                 print(msg)
#                 conn.send(b'recieved')
#             except BlockingIOError:
#                 pass


# 并发  几个程序  在一个时间段内  宏观上 看起来是同时在执行的
# 并行  在一个时刻内 两个程序 同时在 CPU上执行

# 进程 （数据隔离，进程的开销大）
    # 每一个进程都是计算机中资源分配的最小单位
    # 进程与进程之间的特点 ：
        # 数据隔离
            # 各自拥有自己的空间
            # 所以开启一个进程 需要开辟空间 分配资源
            # 销毁一个进程 需要收回空间 释放资源
            # 操作系统在多个进城之间相互切换 也需要耗费资源
        # 各自可以利用多核
        
# 线程 （数据共享，线程的开销小）
    # 计算机中最小的能够被CPU执行的单位
    # 计算机中能够被CPU调度的最小单位，比线程还小的单位对于操作系统来说都是不可见的
    # 同一个进程的多个线程之间数据共享的
    # 线程也是一个执行代码的单位，实际存在在进程中的，且不能脱离进程存在
    # 也可以利用多核
    
# 协程 （本身就是一条线程）
    # 协程就是在一条线程的基础上能够切换多个任务
    # 不能利用多个CPU
    # 切换效率 ：高
    # 只有在io操作多的时候协程才有意义
    

    
    
    
    
    
    
    
    
    
    
    