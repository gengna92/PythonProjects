import time
import json
from multiprocessing import Process,Lock

def check_ticket(name):
    with open('ticket') as f:
        tickit_dic = json.load(f)
        count = tickit_dic['count']
        print('%s查询余票%s'%(name,count))
    return count

def buy_ticket(name):
    with open('ticket') as f:
        tickit_dic = json.load(f)
        count = tickit_dic['count']
    if count >= 1:
        print('有余票')
        count -= 1
        print('%s买到一张票啦'%name)
        tickit_dic['count'] = count
        time.sleep(0.02)
        with open('ticket','w') as f:
            json.dump(tickit_dic,f)
    else:
        print('%s没有余票了'%name)

    
def main(name,lock):
    check_ticket(name)
    with lock:    # 上下文管理的一种使用锁的方式
        buy_ticket(name)
    
        
if __name__ == '__main__':
    lock = Lock()
    for i in range(10):
        p = Process(target=main,args=('alex%s'%i,lock))
        p.start()
        
# 多进程中产生了一个数据安全问题
# 用锁 实际上降低了程序的执行效率，从原本的同时执行某段代码 变成几个进程顺序的执行 拖慢了速度 提高了数据的安全性


# 子进程的对象.join()  阻塞主进程  直到这个子进程结束 才结束阻塞
# lock 锁的是某一段代码

