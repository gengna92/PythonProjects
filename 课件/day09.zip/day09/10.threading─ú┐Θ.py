import os
import time
from threading import Thread
# multiprocessing这个模块 完全是仿照threading模块

# def func(n):
#     print('start thread %s'%n,os.getpid())
#     time.sleep(1)
#     print('end thread %s' % n)
#
# print('-->',os.getpid())
# for i in range(20):
#     Thread(target=func,args=(i,)).start()
    
# 进程与线程的对比
# 1. if name = main
    # 线程不需要
# 2. 进程id
    # 对于线程来说 进程id都是相同的
# 3.执行效率
    # 多线程的开销远远小于多进程
# import time
# from multiprocessing import Process
# def func(n):
#     print('start thread %s' % n, os.getpid())
#     time.sleep(1)
#     print('end thread %s' % n)
#
# if __name__ == '__main__':
#     start1 = time.time()
#     t_l = []
#     for i in range(50):
#         t = Thread(target=func, args=(i,))
#         t.start()
#         t_l.append(t)
#     for t in t_l:t.join()
#     end1 = time.time()
#
#     start2 = time.time()
#     p_l = []
#     for i in range(50):
#         p = Process(target=func, args=(i,))
#         p.start()
#         p_l.append(p)
#     for p in p_l:p.join()
#     end2 = time.time()
#
#     print(end1 - start1)
#     print(end2 - start2)


# print(1.6781532764434814/0.0080575942993164)

# 4.数据共享
# import time
# n = 0
# def func():
#     global n
#     n += 1
#
# if __name__ == '__main__':
#     t_l = []
#     for i in range(50):
#         t = Thread(target=func)
#         t.start()
#         t_l.append(t)
#     for t in t_l:t.join()
#     print(n)