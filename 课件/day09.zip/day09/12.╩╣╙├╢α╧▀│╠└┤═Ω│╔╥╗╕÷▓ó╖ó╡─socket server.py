import socket
from threading import Thread

def talk(conn):
    while True:
        msg = conn.recv(1024).decode('utf-8')
        msg_up = msg.upper()
        conn.send(msg_up.encode('utf-8'))

sk = socket.socket()
sk.bind(('127.0.0.1',9000))
sk.listen()

while True:
    conn,addr = sk.accept()
    Thread(target=talk,args=(conn,)).start()
    
