# 绝对路径
#   c:/hyf.jpg  从磁盘根目录开始寻找
#   d:/abc/def.jpg
# 相对路径
#   相对于当前程序所在的文件夹
#   ../ 上一层文件夹

f = open("../day02 格式化输出 运算符 编码 字符串 列表 元组 字典 set集合 深浅拷贝/03 运算符.py", mode="r", encoding="utf-8")
print(f.read())
