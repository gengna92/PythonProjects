# def fn():
#     print("我是fn")
#
#
# # an = fn() # 函数的调用
# # print(an)
#
# an = fn
# an()
# # print(an)


# def f1():
#     print("f1")
#
#
# def f2():
#     print("f2")
#
#
# def f3():
#     print("f3")
#
# # fn代理了f1, f2, f3的执行
# def fn(a): # 函数名可以像变量一样作为参数进行传递
#     a()
#
# fn(f1)
# fn(f2)
# fn(f3)


def func():
    a = 10
    print("哈哈哈")
    def inner():
        print("呵呵呵")
    return inner

# ret = func()
# ret()
# print(ret)
func()()
