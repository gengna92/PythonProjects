# f = open("fruit", mode="r", encoding="utf-8")
# result = []
# for line in f:
#     lst = line.strip().split(",") # 1,香蕉,3.99,20t  ->  {id:1, name: 香蕉, price:3.99, totle: 20t}
#     dic = {}
#     dic['id'] = lst[0]
#     dic['name'] = lst[1]
#     dic['price'] = lst[2]
#     dic['totle'] = lst[3]
#
#     result.append(dic)
#
# print(result)



f = open("fruit", mode="r", encoding="utf-8")
# 处理表头
title = f.readline()
titleList = title.strip().split(",") # 列表中放的是一个一个的表头信息=> key

# 处理数据
result = []
for line in f: # 每一行数据
    # 切割每一行数据 => value
    lst = line.strip().split(",")  # 1,香蕉,3.99,20t  ->  {id:1, name: 香蕉, price:3.99, totle: 20t}
    dic = {}
    # 循环表头的索引. 同时相当于拿到了数据的索引
    for i in range(len(titleList)):
        # 把表头和数据放在字典中
        dic[titleList[i]] = lst[i]
        
    result.append(dic) # 放列表中
print(result)
