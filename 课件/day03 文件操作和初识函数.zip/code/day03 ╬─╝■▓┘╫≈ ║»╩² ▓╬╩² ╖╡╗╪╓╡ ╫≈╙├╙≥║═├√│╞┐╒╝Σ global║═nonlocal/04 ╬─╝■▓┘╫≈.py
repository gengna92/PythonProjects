# # 句柄 和文件交互的一个通道
# f = open("四驱兄弟", mode="r", encoding="utf-8")
#
# # content = f.read() # 读取数据, 把文件中所有的数据一次性读取出来
# # content = f.read(4) # 读取4个字符
# # print(content)
#
# # line1 = f.readline()
# # print(line1)
# #
# # line2 = f.readline()
# # print(line2)
# #
# # line3 = f.readline()
# # print(line3)
# # line4 = f.readline()
# # print(line4)
# # line5 = f.readline()
# # print(line5)
# #
# # # 光标移动到最开始
# # f.seek(0)
# #
# # line6 = f.readline()
# # print(line6)
# #
# # line6 = f.readline()
# # print(line6)
# # # 有一个可以记录当前文件读取的位置: 光标
#
# # c = f.readline() # 这一行内容里有\n
# # print(c.strip()) # 打印有一个换行
# # print("一行内容")
#
# # 重点:::: 文件句柄可以进行迭代
# for line in f: # 每一行内容
#     print(line.strip())
#
#
#
# # lst = f.readlines()  # 也是一次性读取成一个列表.
# # print(lst)
#
# # 好习惯
# f.close()
#
#
# # print("哈哈哈", end="\n") # end='\n'控制了打印语句的换行
# # print("呵呵呵")
#


# # f = open("葫芦娃", mode="r", encoding="utf-8") # No such file or directory: '葫芦娃'
# f = open("葫芦娃", mode="a", encoding="utf-8") # 如果文件不存在. 创建新文件, 如果文件存在. 清空文件
# f.write("葫芦小金刚")
# print(f.read()) # io.UnsupportedOperation: not readable

# # 好习惯
# f.flush() # 刷新管道
# f.close()


# # 文件复制
# f1 = open("c:/hyf.jpg", mode="rb")
# f2 = open("d:/hyf.jpg", mode="wb")
# for b in f1: # 一部分一部分复制
#     f2.write(b)
#
# f1.close()
# f2.flush()
# f2.close()


# # r+, a+, w+
# f = open("电影", mode="r+", encoding="utf-8") # r+ 读写:先读后写
# print(f.read())
# f.write("欢乐喜剧人") # 把原来的数据覆盖了
# # print(f.read())
# f.flush()
# f.close()


# 文件修改, 把文件中的'大帅哥' 改成 'dsb'

# import os # 引入os模块
# import time # 时间模块
#
# f1 = open("老男孩.txt", mode="r",encoding="utf-8")
# f2 = open("老男孩.txt_副本", mode="w", encoding="utf-8")
# for line in f1: # 从源文件中读取内容
#     s = line.replace("大帅哥", "dsb") # 把文件中的内容进行替换.
#     f2.write(s) # 写入到新文件中
# # 关掉两个文件
# f1.close()
# f2.flush()
# f2.close()
#
# # time.sleep(5) # 暂停5秒
# # 删除源文件
# os.remove("老男孩.txt")
# # time.sleep(5)
# # 把副本文件修改成源文件
# os.rename("老男孩.txt_副本", "老男孩.txt")

# import os
#
# with open("老男孩.txt", mode="r", encoding="utf-8") as f1, \
#      open("老男孩.txt_副本", mode="w", encoding="utf-8") as f2:
#     # 代码块(with), 当这个代码块结束的时候. 自动的关闭f1和f2
#     for line in f1:
#         s = line.replace("大帅哥", "dsb")
#         f2.write(s)
#
# # 外面的操作
# os.remove("老男孩.txt")
# os.rename("老男孩.txt_副本", "老男孩.txt")


# f = open("老男孩.txt", mode="r", encoding="utf-8")
# c = f.read(5) # 读取5个字符
# print(c)
#
# print(f.tell())#  告诉你当前光标的位置(字节)

f = open("老男孩.txt", mode="r+", encoding="utf-8")
f.truncate(7) # 截断文件(单位是字节)
f.seek(12)
f.truncate()
print(f.read())
f.flush()
f.close()