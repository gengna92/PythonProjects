"""
1. 用户先给自己的账户充钱：比如先充3000元。
2. 页面显示 序号 + 商品名称 + 商品价格，如：
        1 电脑 1999
        2 鼠标 10
        …
        n 购物车结算
3. 用户输入选择的商品序号，然后打印商品名称及商品价格,
并将此商品，添加到购物车，用户还可继续添加商品。
4. 如果用户输入的商品序号有误，则提示输入有误，并重新输入。

5. 用户输入n为购物车结算，依次显示用户购物车里面的商品，数量及单价，若充值的钱数不足，则让用户删除某商品，直至可以购买，若充值的钱数充足，则可以直接购买。
6. 用户输入Q或者q退出程序。
7. 退出程序之后，依次显示用户购买的商品，数量，单价，以及此次共消费多少钱，账户余额多少。
"""
product_list = [
    {"name":"电脑","price":1999},
    {"name":"鼠标","price":10},
    {"name":"游艇","price":998},
    {"name":"FBB","price":200}]

# 购物车
# [{"id": 1, 'name':"鼠标", "price":10, "totle": 2}, {}]
shop_cart = []

money = int(input("请输入你有多少钱:"))

while 1:
    for i in range(len(product_list)):
        print(i + 1, product_list[i]['name'], product_list[i]['price'])
    
    
    num = input("请输入你要购买的商品编号, 输入n结束购买. 进行结算:")
    if num.upper() == 'N':
        sum = 0
        for pro in shop_cart:
            print(pro['id'] + 1, pro['name'], pro['price'], pro['totle'], pro['price'] * pro['totle'])
            sum += pro['price'] * pro['totle']
        print("您的购物车需要消费%s" % sum)
        print("您的账户还有%s" % money)
        print("如果结账剩余%s" % (money - sum))
        break
    
    if int(num) <= 0 or int(num) > len(product_list):
        print("您输入的商品不存在. 请重新输入")
        continue
    index = int(num) - 1
    print("您要购买的商品名称:%s, 价格:%s" % (product_list[index]['name'], product_list[index]['price']))
    
    '''
    isContinue = False
    while 1:
        # 判断用户的余额是否充足
        if money > product_list[index]['price']:
            money -= product_list[index]['price'] # 扣钱
            isContinue = False
            break
        else:
            print("余额不足, 请充值或放弃购买该商品")
            n = input("充钱(Y), 重新选择商品(输入任意)")
            if n.upper() == "Y":
                m = input("请输入您要充值的金额:")
                money += int(m)
            else:
                isContinue = True # 该商品不要了
                break
    if isContinue: # 判断是否重新开始
        continue
    '''
    
    # 删除商品的逻辑
    # 计算购物车中所有的商品的价格
    
    while 1:
        sum = product_list[index]['price'] # 总和要加上你要购买的这个商品
        for pro in shop_cart:
            sum += pro['price'] * pro['totle']
        
        if money < sum:
            # 删除购物车中的商品信息
            print("您的余额不足, 请删除购物车中的商品: ")
            print("购物车中已经存在的商品有:")
            for pro in shop_cart:
                print(pro['id'] + 1, pro['name'], pro['price'], pro['totle'], pro['price'] * pro['totle'])
                
            i = input("请选择您要移除的商品的序号")
            if int(i) >= 1:
                for pro in shop_cart:
                    if int(i) - 1 == pro["id"]: # 找到该商品
                        if pro['totle'] > 1:
                            pro['totle'] -= 1
                        else:
                            shop_cart.remove(pro)
        else:
            print("余额充足.可以购买")
            break
    
    # 加入购物车 xxxxx
    # 判断购物车里是否已经有该商品
    for item in shop_cart: # item是你已经购买的每一个商品
        if item['id'] == index:
            item['totle'] += 1
            print("商品已经存在. 商品数量+1")
            break
        # else: # 一次性的判断不能确定购物车中是否包含这个商品
    else:
        # 这个商品在购物车里不存在
        shop_cart.append({"id": index, 'name': product_list[index]['name'], "price": product_list[index]['price'], "totle": 1})
    
    print("加入购物车成功!")
    print(shop_cart)
    print(money)


