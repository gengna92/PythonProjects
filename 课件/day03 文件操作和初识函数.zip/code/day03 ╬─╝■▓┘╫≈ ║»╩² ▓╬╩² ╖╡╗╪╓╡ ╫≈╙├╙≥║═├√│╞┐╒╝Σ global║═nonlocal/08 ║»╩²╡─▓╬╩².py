# 参数: 在函数执行的时候给函数传递的信息
# 1. 实参: 在函数调用的时候给函数传递的具体的值
#           1. 位置参数: 按照形参的声明顺序给形参传递信息
#           2. 关键字参数: 按照形参上面声明的变量名去指定参数
#           3. 混合参数: 位置+关键字. 顺序!!!!  先位置 - 后关键字
#
# 2. 形参: 在函数声明的位置写的变量
#           1. 位置参数: 按照位置声明变量
#           2. 默认值参数: 参数 = 值,  当不给参数传递信息的时候. 默认值生效
#                   位置 -> 默认值
#           3. 动态传参
#               1. 位置参数的动态传参  *args (arguments)
#               2. 关键字参数的动态传参 **kwargs (keyword arguments)
#           形参的声明顺序(重点): 位置 -> *args -> 默认值 -> **kwargs
#              以上参数的顺序可以任意搭配使用. 顺序必须保证是上面的顺序
#
#       重点
#       * 和 ** :  在形参位置相当于聚合.
#                  在实参位置相当于打散.



# def chi(main_food, fu_food, tang, tianpin):
#     print(main_food, fu_food, tang, tianpin)
    
# chi() # 如果你给的参数不够. 会报错
# chi("大米饭", "鱼香肉丝", "疙瘩汤", "冰淇淋") # 正确的调用
# chi("大米饭", "鱼香肉丝", "疙瘩汤", "冰淇淋", "汉堡") # 参数多了也不行

# chi(fu_food="酱肘子", main_food="面条", tianpin="土豆泥", tang="紫菜蛋花汤")

# 位置在前, 关键字在后 -> 正确的用法
# chi("酱肘子", "北京烤鸭", tianpin="哈根达斯", tang="鳕鱼豆腐汤")
# 关键字在前, 位置在后 -> 报错
# chi(tianpin="哈根达斯", tang="鳕鱼豆腐汤", "酱肘子", "北京烤鸭")


# 默认值参数: 为了简化调用
# def reg(name, age, gender="男", job_address="北京"):
#     print(name,age,gender, job_address)
#
# reg("彭于晏", 23)
# reg("周杰伦", 18)
# reg("王力宏", 19)
# reg("郭彩妮", 23, "女", "上海")


# def chi(*food): # *: 动态接收位置参数. food 是参数名, 接收到的是一个元组
#     print(food)

# chi("大米饭", "鱼香肉丝", "汉堡", "泡面")
# chi("辣条")
# chi("辣条", "疙瘩汤")

# # 关键字的动态传参
# def chi(**food): # ** 接收关键字参数. food参数名, 接收到的是字典
#     print(food['zhu'])
#
# chi(zhu="馒头", fu="韭菜炒鸡蛋", tang="蛋花汤", tian="牛轧糖")


# def func(a, b, *args): # 位置 -> *args
#     pass
#
# func(1, 2, 3,4,5)


# def func(c = 5, **kwargs): # 如果实参那边不用关键字.c一定生效
#     print(c, kwargs)
#
# func(a = 10, b = 20)

# def func(*args, **kwargs): # 可以接收所有的参数. 无敌传参
#     print(args, kwargs)
#
# func(1, 2, 3, zhubo1="冯提莫", zhubo2="陈一发儿", zhubo3="PDD")
#

# print("周润发", "周杰伦", "周星驰", sep="___")

# def chi(*food): # 聚合成元组
#     print(food)
#
# lst = ["酱肘子", "小龙虾", "羊蹄", "烧烤"]
# # chi(lst[0], lst[1], lst[2], lst[3])
# chi(*lst) # 把列表打散成实参. 传递给函数


# def chi(**food): # 聚合. 把传递过来的关键字参数聚合成字典
#     print(food)
#
# dic = {"串":"羊肉串", "汤":"驴肉汤", "面":"兰州拉面"}
# # chi(串=dic['串'], 汤=dic['汤'], 面=dic['面'])
# dic2 = {"a":1, "b":2, "c":3}
# chi(**dic, **dic2) # 把字典打散成关键字参数


# def func(*args, **kwargs):
#     print(kwargs)
#
# func(1, 2, 3, a = 1, b = 2)
