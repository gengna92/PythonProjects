# def outer():
#     a = 10
#     def inner(): # inner的作用域是outer里面
#         print(111)
#     inner()
#
# outer()


# def outer():
#     print(555)
#     def inner():  # inner的作用域是outer里面
#         print(1111)
#         def inner2():
#             print("呵呵呵")
#         print(222)
#         inner2()
#         print(333)
#     inner()
#     print(4444)
#
# outer()


# def func1():
#     print("我的天")
#     func2()
#
# def func2():
#     print("你的天")
#     func3()
#
# def func3():
#     print("大家的天")
#
# def func4():
#     func3()
#     print("谁的天")
#     func1()
# func4()

# global和nonlocal
# global: 可以把一个全局变量引入到局部
# nonlocal: 在局部. 把离他最近的那一层的变量引入进来

# a = 20 # 不是服务于一个函数的.
# def func():
#     # a = 20
#     # 在局部中不允许直接更改全局变量 -> 很危险的一个事情
#     # 有些情况不得不改
#     # 把全局变量拽到局部
#     global a # 把全局里的a拽到局部
#     a += 1 # a = 10 + 1 # 此时用的a是全局
#     print(a) # 当前作用域中没有a. 但是又用到了a. 此时只能去全局找
#
# func()
# print(a)

# def outer():
#     a = 10
#     def inner():
#         nonlocal a
#         a += 1
#     inner()
#
# outer()


# a = 1
# def fun_1():
#     a = 2
#     def fun_2():
#         nonlocal a
#         a = 3
#         def fun_3():
#             a = 4
#             print(a)
#         print(a)
#         fun_3()
#         print(a)
#     print(a)
#     fun_2()
#     print(a)
# print(a)
# fun_1()
# print(a)
