while 1: print(input(">>>:").strip("吗呢么?")+"!")
