# 约过么?

# while 1:
#     print("1. 打开手机")
#     print("2. 打开陌陌")
#     print("3. 找一个你心意的他她它")
#     print("4. 聊一聊人生,理想")
#     print("5. 走啊. 约啊?")

# 想什么时候约就什么时候约?  => 函数
# 先在脑子里定义好. 应该怎么样去约. 然后在需要的时候. 把定义好的这个动作拿出来执行一次

# # 定义一个函数
# # define # 定义
# def yue(): # 定义一个函数叫yue
#     print("1. 打开手机")
#     print("2. 打开陌陌")
#     print("3. 找一个你心意的他她它")
#     print("4. 聊一聊人生,理想")
#     print("5. 走啊. 约啊?")
#
# # 调用函数
# # yue() # 函数名+括号  =>  函数的调用
# # print("今天上班了. 不开心")
# # yue()
# # print("累了. 休息一个月")
# # yue()
# # 一次声明, 到处去调用
# # 函数名和变量名是一致的. 都要遵循变量的命名规范
# # 函数名其实就是变量名
#
# print(yue) # <function yue at 0x0000000001D51E18>
# yue = "哈哈哈"
# print(yue)


# def yue(): # 定义一个函数叫yue
#     print("1. 打开手机")
#     print("2. 打开陌陌")
#     print("3. 找一个你心意的他她它")
#     print("4. 聊一聊人生,理想")
#     print("5. 走啊. 约啊?")
#     # return "萝莉", "大码", "大爷", "小动物"
#     # return
#     # return "胡一菲"  # return 表示返回. 后面的这个数据表示返回值,  return 可以结束一个函数的执行

# return 可以终止一个函数的执行
# 函数可以有返回值, 谁调用的函数. 返回值就返回给谁
# 返回值有3种:
#   1. 有一个返回值(return 值)
#   2. 函数中没写return. 或者只写了个return. 默认返回None
#   3. 一次返回多个返回值. 多个返回值. 调用方接收到的是一个元组 (return 值1, 值2, 值3, 值..)

# ret = yue() #
# print("接收到的结果是", ret)



# def yue(tools, ta): # 形参
#     print("1. 打开手机")
#     print("2. 打开%s" % tools)
#     print("3. 找一个你心意的%s" % ta)
#     print("4. 聊一聊人生,理想")
#     print("5. 走啊. 约啊?")
#
# # 需求: 指定某一个工具去约
# # 参数: 在函数执行的时候给函数传递的信息.
# #   1. 形参: 在函数声明的位置写的变量.
# #   2. 实参: 在函数调用的位置给出的具体的数据
# #   3. 传参: 把实参传递给形参的过程.
# yue("微信", "他") # 实参
# yue("陌陌", "它")
# yue("探探", "她")

# # f(x) = x + 1
# def f(x):
#     return x + 1

# # 给函数传递两个数据a,b. 计算a+b的结果
# def func(a, b):
#     return a + b
#
# ret = func(1, 2)
# print(ret)

# 文件的复制粘贴:
def copy(src, target):
    with open(src, mode="rb") as f1, \
        open(target, mode="wb") as f2:
        for line in f1:
            f2.write(line)

    print("文件复制成功!")
    
copy("d:/hyf.jpg", "e:/hef.jpg")
lst = [1,2,3,4,5]
print(len(lst))