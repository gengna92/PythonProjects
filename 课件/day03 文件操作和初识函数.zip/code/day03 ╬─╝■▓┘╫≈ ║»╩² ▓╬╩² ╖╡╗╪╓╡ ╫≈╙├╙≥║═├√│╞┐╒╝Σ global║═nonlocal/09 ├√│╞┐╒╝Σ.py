# 名称空间: 你创建的变量. 函数. 类. 对象. 都会有一个独立的内存空间.
# 三个名称空间: 1. 内置名称空间, 2. 全局名称空间. 3.局部名称空间
#   1. 内置: python内部命名的一些内容. print, input, len
#   2. 全局: py文件有一个单独的名称空间
#   3. 局部: 你的函数(类)内部 声明的变量.


# 作用域: 你的变量可以作用的范围.
# 1. 全局作用域: 内置 + 全局
# 2. 局部作用域: 局部

# a = 10
# print(globals()) # 查看全局作用域中的内容
#
# # if True:
# #     d = 128
#
# def chi(): # 全局
#     a = 50 # 不是全局
#     pass # 为了语法的完整
# print(globals()) # 查看全局



# a = 10
# def func():
#     a = 20
#     b = 320
#     print(a)
#     print(locals()) # 查看本地(当前)的名称空间
#     print(globals()) # 查看全局
#
# # def func2():
# #     print(a)
#
# func()
# # func2()

# print(locals()) # 查看本地(当前)的名称空间
# print(globals()) # 查看全局