# dic = {}
# # d = dic.fromkeys("jay", "方文山") # 创建字典
# # print(d)  # 此时创建新字典. 和原来的字典没有关系
#
# # fromkeys执行的效果: 把前面的那个参数的数据进行迭代. 和后面的参数组合成一个key:value. 创建一个新字典

# print(dict.fromkeys("国产动画", "白蛇,缘起")) # fromkeys的正确用法

# d = dict.fromkeys("周杰伦", ["昆凌"])
# d['杰'].append("蔡依林")
# print(d)

# 面试官
# 1. fromkeys返回新字典. 不是在原来字典的基础上干活的
# 2. 所有的key共享同一个value
