# -*- coding: utf-8 -*-
import scrapy
from bossPro.items import BossproItem

class BossSpider(scrapy.Spider):
    name = 'boss'
    # allowed_domains = ['www.xxx.com']
    start_urls = ['https://www.zhipin.com/job_detail/?query=python&city=101010100&industry=&position=']
    #指定一个通用的url模板
    url = 'https://www.zhipin.com/c101010100/?query=python&page=%d'
    page_num = 2
    
    #解析岗位名称，薪资，公司名称
    def parse(self, response):
        #岗位名称，薪资，公司名称，岗位描述
        li_list = response.xpath('//*[@id="main"]/div/div[3]/ul/li')
        for li in li_list:
            job_title = li.xpath('./div/div[1]/h3/a/div/text()').extract_first()
            salary = li.xpath('./div/div[1]/h3/a/span/text()').extract_first()
            company_name = li.xpath('.//div[@class="info-company"]/div/h3/a/text()').extract_first()
            #详情页的url，对该url发起请求获取岗位描述
            detail_url = 'https://www.zhipin.com'+li.xpath('./div/div[1]/h3/a/@href').extract_first()

            # 将解析的数据存储封装到item类型的对象中
            item = BossproItem()
            item['job_name'] = job_title
            item['salary'] = salary
            item['company_name'] = company_name
           
            #对详情页的url发起请求解析出岗位描述
            #meta作用：将meta对应的字典传递给callback指定的回调函数
            yield scrapy.Request(url=detail_url,callback=self.parse_detail,meta={'item':item})
            
            
           
         
        
        #10表示的是最大页码数据
        if self.page_num <= 10:
            # print('正在爬取第{}页的数据。'.format(self.page_num))
            #手动请求发送
            new_url = format(self.url%self.page_num)
            self.page_num += 1
            #callback参数是完成数据解析
            yield scrapy.Request(url=new_url,callback=self.parse)
            
    #解析岗位描述
    def parse_detail(self,response):
        job_desc = response.xpath('//*[@id="main"]/div[3]/div/div[2]/div[2]/div[1]/div//text()').extract()
        job_desc = ''.join(job_desc)
        
        #接收请求传参传递过来的meta字典
        item = response.meta['item']
        item['job_desc'] = job_desc

        # 将item提交给管道
        yield item
        