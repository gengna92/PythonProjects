# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html


class BossproPipeline(object):
    fp = None
    
    def open_spider(self,spider):
        #测试spider这个参数是否表示的是爬虫类实例化的对象
        print('当前工程爬虫文件的名称是：',spider.name)
        
        self.fp = open('./boss.txt','a+',encoding='utf-8')
        
    def process_item(self, item, spider):
        self.fp.write(item['job_name']+':'+item['salary']+':'+item['company_name']+':'+item['job_desc']+'\n')
        # print(item)
        return item
    
    def close_spider(self,spider):
        self.fp.close()
