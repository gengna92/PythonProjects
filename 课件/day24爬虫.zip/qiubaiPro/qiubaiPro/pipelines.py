# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html

import pymysql
class QiubaiproPipeline(object):
    #重写父类的一个方法：只会被调用一次
    fp = None
    def open_spider(self,spider):
        print('开始爬虫！！！')
        self.fp = open('./qiushibaike.txt','w',encoding='utf-8')
        
    #负责接收item且将item中封装的数据进行任意形式的持久化存储
    #item参数就是管道接收到的item类型的对象
    #该方法调用的次数是由爬虫文件向管道提交item的次数决定
    def process_item(self, item, spider):
        self.fp.write(item['author']+':'+item['content']+'\n')
        return item #将item返回给下一个即将被执行的管道类
    
    
    def close_spider(self,spider):
        print('爬虫结束！！！')
        self.fp.close()
        
        
class MysqlPileLine(object):
    conn = None
    cursor = None
    def open_spider(self,spider):
        self.conn = pymysql.Connect(host='127.0.0.1',port=3306,user='root',password='',db='spider',charset='utf8')
        print(self.conn)
        
    def process_item(self,item,spider):
        self.cursor = self.conn.cursor()
        sql = 'insert into qiubai values ("%s","%s")'%(item['author'],item['content'])
        try:
            self.cursor.execute(sql)
            self.conn.commit()
        except Exception as e:
            print(e)
            self.conn.rollback()
            
        return item
        
    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()
    
