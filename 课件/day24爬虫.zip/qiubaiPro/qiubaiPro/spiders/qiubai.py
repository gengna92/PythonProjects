# -*- coding: utf-8 -*-
import scrapy
from qiubaiPro.items import QiubaiproItem
#- 需求：爬取糗事百科的段子内容和作者名称
class QiubaiSpider(scrapy.Spider):
    name = 'qiubai'
    # allowed_domains = ['www.xxxx.com']
    start_urls = ['https://www.qiushibaike.com/text/']

    #基于终端指令持久化存储的方式
    # def parse(self, response):
    #     all_data = []
    #     div_list = response.xpath('//div[@id="content-left"]/div')
    #     for div in div_list:
    #         #extract_first()将列表中第0个列表元素对应的Selector对象中的字符串取出
    #         author = div.xpath('./div[1]/a[2]/h2/text()').extract_first()
    #         #extract()将列表中的每一个列表元素表示的Selector对象中的字符串进行提取
    #         content = div.xpath('./a[1]/div/span//text()').extract()
    #         content = ''.join(content)
    #
    #         dic = {
    #             'author':author,
    #             'content':content
    #         }
    #         all_data.append(dic)
    #     #返回值就是爬取到的所有数据
    #     return all_data
    def parse(self, response):
        all_data = []
        div_list = response.xpath('//div[@id="content-left"]/div')
        for div in div_list:
            # extract_first()将列表中第0个列表元素对应的Selector对象中的字符串取出
            author = div.xpath('./div[1]/a[2]/h2/text() | ./div[1]/span[2]/h2/text()').extract_first()
            # extract()将列表中的每一个列表元素表示的Selector对象中的字符串进行提取
            content = div.xpath('./a[1]/div/span//text()').extract()
            content = ''.join(content)
        
            #实例化一个item类型的对象
            item = QiubaiproItem()
            item['author'] = author
            item['content'] = content
            
            #将item对象提交给管道
            yield item
