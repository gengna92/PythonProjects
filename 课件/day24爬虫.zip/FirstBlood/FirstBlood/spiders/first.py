# -*- coding: utf-8 -*-
import scrapy


class FirstSpider(scrapy.Spider):
    #爬虫文件的名称：爬虫源文件的唯一标识
    name = 'first'
    #允许的域名
    # allowed_domains = ['www.baidu.com']
    #起始url列表：列表元素必须为url，且列表元素表示url会被自动的进行请求发送
    start_urls = ['http://www.baidu.com/','https://www.sogou.com']
    #数据解析
    def parse(self, response):
        print(response)
