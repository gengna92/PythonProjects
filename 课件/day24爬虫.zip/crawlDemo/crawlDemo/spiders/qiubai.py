# -*- coding: utf-8 -*-
import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule


class QiubaiSpider(CrawlSpider):
    name = 'qiubai'
    # allowed_domains = ['www.xxx.com']
    start_urls = ['https://www.qiushibaike.com/text/']
    
    #实例化了一个LinkExtractor（连接提取器）对象
    #作用：可以根据规则（allow）提取指定的连接
    link = LinkExtractor(allow=r'/text/page/\d+/')
    #单独使用一个连接提取器提取第一个的连接
    link1 = LinkExtractor(allow=r'/text/')
    rules = (
        #实例化了Rule（规则解析器）对象
        #作用：将连接提取器提取到的连接进行请求发送然后进行指定规则（callback）的解析
        Rule(link, callback='parse_item', follow=True),
        Rule(link1, callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        print(response)
        
