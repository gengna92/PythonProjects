from selenium import webdriver
from time import sleep
#导入动作链对应的模块
from selenium.webdriver import ActionChains

#实例化一个浏览器对象
bro = webdriver.Chrome(executable_path='./chromedriver.exe')

#发起请求
bro.get('https://www.runoob.com/try/try.php?filename=jqueryui-api-droppable')

#基于动作链实现滑动操作
action = ActionChains(bro) #实例化一个动作链对象

#定位标签
#NoSuchElementException：在标签定位的时候
#额外操作
bro.switch_to.frame('iframeResult')

targer_tag = bro.find_element_by_id('draggable')

#点击且长按的动作
action.click_and_hold(targer_tag)

#实现滑动
for i in range(5):
    #perform()立即执行动作链
    action.move_by_offset(17,0).perform()
    sleep(0.5)
    
sleep(3)
bro.quit()