from selenium import webdriver
from lxml import etree
url = 'http://125.35.6.84:81/xk/'
bro = webdriver.Chrome(executable_path='./chromedriver.exe')

bro.get(url)

#page_source返回的是当前浏览器对应页面的源码
#厉害：可见即可得
page_text = bro.page_source

#解析出动态加载的企业名称
tree = etree.HTML(page_text)
li_list = tree.xpath('//*[@id="gzlist"]/li')
for li in li_list:
    company_title = li.xpath('./dl/@title')[0]
    print(company_title)
