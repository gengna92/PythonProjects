from selenium import webdriver
bro = webdriver.Chrome(executable_path='./chromedriver.exe')

url = 'https://qzone.qq.com/'

bro.get(url)

bro.switch_to.frame('login_frame')

bro.find_element_by_id('switcher_plogin').click()

bro.find_element_by_id('u').send_keys('328410948')
bro.find_element_by_id('p').send_keys('xxxxxx')
bro.find_element_by_id('login_button').click()


#登录成功后会实现页面跳转，跳转后的页面就是登录成功之后的页面
# page_text = bro.page_source