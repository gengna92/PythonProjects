var a = 5;
// alert(a);