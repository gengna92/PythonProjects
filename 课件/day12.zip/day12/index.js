// var a = 2;
// var str = 'abc';
// console.log(typeof a);
// console.log(typeof str);
// var array = [1,'abc',[1,2,3]];
// array.length
// array[0]
//  array[2][2];
    // int a = 2;
    // float b = 2.1323;

/*
var a;
console.log(typeof a);
a=3;

var c = a / 0;
console.log(typeof c);//Infinity

var b = null;
console.log(typeof b);

var isFalse = false;
console.log(typeof isFalse);
*/

/*
数值转字符串
var str = '';
var str2 = 9999999;
var newStr = str+ str2;
*/
// var num = 9999999;

var a = 5;

//先赋值 再对a的值++
// var b = a++;

//先对a++对a赋值。再将a的值赋值给b
var b = ++a;

console.log(a); //6
console.log(b); //5


var c = 6;
var d = '6';
//eq()
console.log(c===d); //false
console.log(c==d); //true

/*

if(c===d){

}else if(c>d){

}else if(c<d){

}else{

}
*/
/*
var a = 1;
var sum = 0;
while(a <= 100){
    sum = sum + a;
    a++;
}
console.log(sum);
*/
/*
var a;
var sum = 0;
for(a = 1; a <= 100;a++){
    sum = sum + a;
}
console.log(sum);
*/
new Array()
var weather = 'sunnyxxxx';
switch (weather){
    case 'sunny':
        //run to code
        alert('天气很好呀');
        break;
    case 'rainy':
        alert('天气下雨了');
        break;
    default:
        alert('天气也就那样吧');
}


//300  700
//min   max
var min = 300;
var max = 700;

//300 ~ 300
// var ran = min + Math.random() * (max-min);
// console.log(ran);


/*
function rand(min,max) {
    return min + Math.random() * (max-min);
}

var r = rand(400,800);
console.log(r);
*/

// var a = function() {
//     console.log(1+1);
// }
// a();

//
// (function (a,b) {
//     alert(a+b);
// })(2,5);

// var person = {
//     name:"alex",
//     age:19,
//     fav:function () {
//         alert(this.name);
//     }
// }
// person.fav();

class Animal {
    constructor(name,age){
        this.name = name;
        this.age = age;
    }
    fav(){

    }
}