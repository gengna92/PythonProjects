# # 匿名函数: 一行代码搞定一个函数
# fn = lambda x, y: x + y
# # def fn(x, y):
# #     return x + y
#
# # ret = fn(3, 4)
# # print(ret)
# print(fn)

# 语法: lambda 参数: 返回值


