# == 比较的是数据
# is 比较的是内存地址

# lst1 = [1,2,3]
# lst2 = [1,2,3]
# print(lst1 == lst2)
# print(lst1 is lst2)


s1 = "alex"
s2 = "alex"

print(s1 is s2)  # True, 原因是有小数据池进行缓存. 优化你的字符串创建过程
print(id(s1))
print(id(s2))

# String interning
# 小数据池: python会自动的对我们写的字符串, 数字, 布尔.进行缓存.
