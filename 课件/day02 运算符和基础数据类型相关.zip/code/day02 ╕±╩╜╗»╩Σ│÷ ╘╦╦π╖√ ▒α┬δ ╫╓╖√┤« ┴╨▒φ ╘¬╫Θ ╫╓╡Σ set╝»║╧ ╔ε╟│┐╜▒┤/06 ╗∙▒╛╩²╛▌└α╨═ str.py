# # str: 由双引号, 单引号, 三个单引号, 三个双引号括起来的内容
# # 引号引起来的就是字符串.
# mingxing = '周杰伦的老婆是'
# # 下面哪行代码和当前这行代码是同一条代码
# mingxing2 = "冯提莫的老公是" \
#             "'alex'"
# print(mingxing2)
# mingxing3 = '''卢本伟的老婆
# 是Uu'''
# print(mingxing3)
# mingxing4 = """陈一发儿"""

# 字符串的索引和切片
# 索引就是第几个字符, 索引从0开始
#    012
#   -3-2-1
# s = "jay"
# print(s[1]) # []表示索引
#
# print(s[2])
# print(s[-1])
# print(s[-3])

# 切片
# s = "alex昨天看冯提莫直播. 刷了1w个鱼丸"
# s1 = s[4:8] # 默认从左到右切, 顾头不顾尾[start, end)
# print(s1)
#
# s2 = s[8:4]
# print(s2)
#
# s3 = s[-6:-2]
# print(s3)
#
# s4 = s[6:] # 从6开始切, 切割末尾
# print(s4)
#
# s5 = s[:6] # 从头开始切, 切到6为止
# print(s5)
#
# s6 = s[:] # 从头到尾
# print(s6)

# # 带有步长的切片
# s = "wusir喜欢和alex一起去探讨课件"
#
# # s1 = s[3:8:2] # 从3到8 每2个出来1个  i喜和
# # print(s1)
# #
# # s2 = s[::2]
# # print(s2)
# #
# # # 如果步长为负数, 从右到左
# # s3 = s[::-1]
# # print(s3)
# #
# # s4 = s[-1:-6:-2]
# # print(s4)
#
# s5 = s[-3::-3]
# print(s5)

# 索引和切片:
# 字符串[数字]  获取到第xx索引位置的字符
# 字符串[m:n]   从m开始获取到n结束. 永远娶不到n
# 字符串[m:n:s] 从m到n结束. 每s个取1个

# 字符串相关操作:
# 1. upper()  忽略大小写
# 2. split()  字符串的切割, 默认是使用空白切割
# 3. replace() 字符串替换
# 4. strip() 去掉左右两端的空白
# 5. startswith() 判断是否已xxx开头
# 6. find()  查找. 找不到返回-1
# 7. isdigit() 判断是否是数字组成





# 大小写转来转去
# 1. 首字母大写
# s = "alex"
# s1 = s.capitalize()  # 首字母大写, 字符串是不可变的数据类型. 每次操作都会返回新字符串
# print(s)
# print(s1)

# 2. upper() 把所有字母转化成大写
# s = "wusir"
# s1 = s.upper()
# print(s1)
# while 1:
#     game = input("请输入你喜欢玩儿的游戏(请输入Exit退出程序):")
#     if game.upper() == "EXIT": # 忽略大小写
#         break
#     print("你喜欢的游戏是%s" % game)

# 3. lower() 全部转化成小写. 对一些欧洲文字不敏感
# s = "wusir和ALEX关系不一般"
# print(s.lower())

# 4. title() 标题,  每个单词的首字母大写
# s = "alex wusir ritian taibai nezha 女神"
# print(s.title())

# 切来切去
# 1. split() 字符串切割
# s = "alex_wusir_taibai"
# ret = s.split("alex_wusir_taibai") # 如果切割的位置在边缘. 一定能获取到空字符串
# print(type(ret)) # <class 'list'> 列表
# print(ret)

# # 2. replace()  字符串的替换
# s = "alex dsb, wusir xsb"
# # print(s.replace("sb", "烧饼"))
# print(s.replace("sb", ""))

# # 3. strip()  去掉空白 => 脱掉空白
# # s = "    哈哈哈     哈哈哈\n\t" # \t 制表符(缩进)  \n 换行
# # print(s.strip()) # 去掉左右两端的空白(必须要记住)
#
# username = input("用户名:").strip()
# password = input("密码:").strip()
# if username == "alex" and password == "123":
#     print("登录成功了")
# else:
#     print("登录失败")
#
# # 张总. 用户名是alex  密码是123

# s = "周杰伦         功夫足球   \t\t\t 少林足球 足球少林"
# print(s.split())


# 找来找去
# s = "php是全世界最好的编程语言"
# print(s.startswith("java")) # 判断这句话是否是以xxx开头
# print(s.endswith("php")) #  判断是否以xxx结尾

# name = input("请输入你的名字:")
# if name.startswith("张"):
#     print("你是姓张的")
# else:
#     print("你不是姓张的")

# s = "java, php, python, c++"
# print(s.count("av")) # 计算xxx字符串中出现的次数
# s = "海王_剑姬_诺手_余小C喜欢用诺手"
#
# print(s.find("手")) # 找的是索引
# print(s.find("胡")) # 如果不存在. 返回-1
# print(s.index("手")) # index: 索引
# print(s.index("胡")) # index如果找不到. 报错

# 判断组成
# isdigit() 判断字符串是否由数字组成
# s = "abc胡辣汤壹123@#$%"
# print(s.isdigit())
# print(s.isalpha()) # 判断是否由文字的基本组成.
# print(s.isalnum()) # 是否由数字. 字母组成, 能屏蔽特殊字符

# s = "123123壹佰贰拾伍万贰千三百四十六"
# print(s.isnumeric()) # 判断是否是数字, 两, 俩

# 字符串操作完结
# 1. len() 求字符串长度,  内置函数
# s = "alex 和 wusir一堆好基友"
# print(len(s)) # 求字符串的长度
# # 可以使用len来遍历字符串
# print(s[0])
# print(s[1])
# print(s[2])
# print(s[3])

# print(s[108]) # string index out of range  字符串索引超过了边界


# i = 0
# while i < len(s): # 遍历字符串
#     print(s[i])  # alex  # string index out of range
#     i += 1 # i = 4

# for循环
# 语法: for 变量 in 可迭代对象:
#           循环体
# 字符串是一个可迭代对象

# s = "alex特别喜欢武藤兰"
# for c in s: # 把字符串s中的每一个字符赋值给前面的变量c
#     print(c)

# for i in 10: # 'int' object is not iterable
#     print(i)

# in和not in 成员运算
# s = "alex特别喜欢太白金星"
# if "胡辣汤" in s:
#     print("对不起, 你的评论有敏感词")
# else:
#     print("OK. 没问题")

# # while...else...
# # for...else...
#
# i = 0
# while i < 100:
#     print(i)
#     if i == 66:
#         break  # break不会执行else, 打断这个循环.没有经过条件判断所以. 不执行else
#     i+=1
# else: # 当判断结束的时候. 自动执行else
#     print("数完了")
# # for循环和while循环一样也可以使用break和continue, 和else
# # for循环只有当迭代结束的时候才能执行else

