# 美国人发明了关于美国文字在计算机中的显示效果 => ascii 里面编码的内容都是按照美国人的文字进行编码. ascii => 我们能看到的就是那一堆英文字母 + 数字 + 一些你键盘上能看到得所有特殊符号

# 编码就是用特定的排列组合来表示我们的文字信息
# a  =>  01
# 在ascii中使用8位01组合来表示一个ascii中的字符
# ascii在最开始只有7位=> 后来发现,7位很难处理. 为了扩展又添加了一位 => 8bit  => 1byte
# ascii中只有7位是有效的. 最前面的哪一位是空着的. 是0

# ascii中没有中文编码  提出一个标准 => ANSI => 在ascii基础上扩展8bit  => 16bit=> 给各个国家进行编码 => GB2312 => GBK(国标码扩展码)=>gbk中包含了我们常用的中文, 日文, 韩文, 繁体字

# 国际化的操作依然不能实现 => UNICODE => 万国码 => 扩容=>  us4 => 32bit  => 把所有国家的文字进行同一

# 早期的unicode根本没有办法使用: 1.存储, 2.网络传输
# a =>8  => unicode => 32
# 1MB => 4MB

# 随着机能的提高. 还有utf-8的产生. unicode可以使用了

# 0111 1111
# 把unicode重新进行定义 -> 可变长度的unicode => UTF-8, UTF-16
# utf-8: 最小的字节单位是8bit
# utf-16: 最小字节单位: 16bit

# 用的最多的编码就是utf-8
# 1. 英文: 8bit  -> 1byte
# 2. 欧洲文字: 16bit  -> 2byte
# 3. 中文: 24bit -> 3个字节  中文有9万多个


# python使用的是???
# python2.x使用的是ascii
# python3.x内存中使用的unicode, 文件存储使用:utf-8
#
# s = "古力娜扎" # 字符串直接就是unicode
# print(s)
#
# # 想要存储. 必须进行转换 => utf-8 或者GBK
#
# # unicode => UTF-8
#
# # b'\xe5\x8f\xa4\xe5\x8a\x9b\xe5\xa8\x9c\xe6\x89\x8e' 字节 => 01  => 用来存储和传输
# # b'\xb9\xc5\xc1\xa6\xc4\xc8\xd4\xfa' => gbk的编码  一个中文2个字节
# bs = s.encode("gbk")
# print(bs)

#  解码
# bs = b'\xb9\xc5\xc1\xa6\xc4\xc8\xd4\xfa' # GBK
bs = b'\xe5\x8f\xa4\xe5\x8a\x9b\xe5\xa8\x9c\xe6\x89\x8e' # utf-8

s = bs.decode("utf-8")
print(s)

import json

# 用什么编码. 就用什么解码

# 0,1  => 1bit
# 8bit => 1byte
# 1024byte => 1kb
# 1024kb => 1mb
# 1024mb => 1gb
# 1024gb => 1tb
# 1024tb => 1pb
# ....


# 简单的编码总结:
# 1. ascii  8bit => 1byte  英文 + 数字 + 特殊符号
# 2. GBK 16bit  => 2byte 中文
# 3. unicode 32bit => 4byte 万国码
# 4. utf-8 :
#   英文: 8bit, 1byte
#   欧洲: 16bit, 2byte
#   中文: 24bit, 3byte

# encode(编码)  编码. 得到的是bytes类型
# decode(编码)  解码. 得到字符串
