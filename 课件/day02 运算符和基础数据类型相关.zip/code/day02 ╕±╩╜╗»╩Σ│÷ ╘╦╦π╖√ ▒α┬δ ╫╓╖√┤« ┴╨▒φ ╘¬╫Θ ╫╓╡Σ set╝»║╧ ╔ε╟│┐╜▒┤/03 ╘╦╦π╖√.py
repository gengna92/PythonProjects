'''
一. 算数运算
    + - * / % // **
二. 比较运算
    > < >= <= == !=
三. 赋值运算
    = 把等号右边的值赋值给左边的变量
    a += b   =>  a = a + b
    a -= b    =>  a = a - b
    *=
    /=
    a %= b    => a = a % b
四. 逻辑运算
    1, and
        并且, 左右两端必须同时为真, 最终的结果才能是真, 有一个是假, 结果就是假
    2, or
        或者, 左右两端有一个是真. 结果就是真. 全都是假, 结果才能是假
    3, not
        非.不.  非真既假, 非假既真
        
    如果出现混合逻辑运算. 顺序: () => not  => and => or
    
    
    a or b
        如果a是0 结果是b
        如果a是非零, 结果就是a
    
    a and b
        和or相反
    
'''

# a = 10
# b = 4
# a %= b # a = 10 % 4
# print(a)

# 用while循环计数 1-100
# i = 1
# while i <= 100:
#     print(i)
#     # i = i + 1
#     i += 1


# print(1 > 5 or 5 < 6 or 7 > 3)
# print(not False

# print(1 > 3 or 5 < 7 and 6 > 8)

# print(not 1 > 5 and 4 < 6 or 7 > 8 and 1 < 9 or 5 > 6)

# 0就是假
# 非0就是真
# a or b if a == False then b else a
# print(1 or 2) # 1
# print(0 or 3) # 3
# print(1 or 5) # 1
# print(0 or 5) # 5

# print(1 and 3) # 3
# print(0 and 5) # 0
# # print(5 and 0) # 0
# # print(3 and 5) # 5
#
# # print(1 and 2 or 3) # 2
#
# # print(1 and 5 or 3 and 4 or 7 or 8 and 6 or 2)  # 5
#
# # print(1 and 5 < 3 or 6) # 6
#
# # print(1 or 0 and 5 < 6 and 7 > 8 or 3)
