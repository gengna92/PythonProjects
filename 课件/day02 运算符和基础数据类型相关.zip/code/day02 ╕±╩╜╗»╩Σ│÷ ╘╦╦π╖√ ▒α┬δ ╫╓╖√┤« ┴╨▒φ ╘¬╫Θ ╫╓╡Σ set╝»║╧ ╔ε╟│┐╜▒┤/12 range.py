
# range可以让for循环数数
# for i in range(100): # [0, 100)  100次循环
#     print(i)

# for i in range(10, 20): # [10, 20)
#     print(i)
    
# for i in range(10, 20, 2): # [10, 20) 每2个出1个
#     print(i)

# 重点:
# lst = ["成功", "不要", "30岁", "做人", "思想", "学习是自己的", "找家长"] # 0-4
#
# for i in range(len(lst)): # 可以拿到索引和元素
#     print(i, lst[i])

# i = 0
# for item in lst: # 这个循环看不到索引
#     print(i, item)
#     i += 1


