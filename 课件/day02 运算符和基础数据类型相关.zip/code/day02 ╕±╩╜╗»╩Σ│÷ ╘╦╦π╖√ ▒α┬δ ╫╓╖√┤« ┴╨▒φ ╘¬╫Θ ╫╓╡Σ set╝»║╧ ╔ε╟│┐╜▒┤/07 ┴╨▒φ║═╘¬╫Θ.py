# 能装对象的对象叫列表.  存在的意义:存储大量的数据
# 列表使用[]括起来, 内部元素用逗号隔开
# lst = ["张三丰", "张全蛋", "张无忌", "张国立", "张翠山", "张二嘎"]

# 类表和字符串一样也有索引和切片
# print(lst[1])
# print(lst[1::2]) # 切片功能和字符串一模一样
# print(lst[-1::-2]) #

# 列表的增删改查
# 增加
# 1. append 追加 向列表的最后放数据
# lst = []  # list()
# lst.append("手表")
# lst.append("腰带")
# lst.append("相机")
# lst.append("陈冠希")
#
# print(lst)

# # 2. insert 插入.
# lst = ["倚天", "射雕", "天龙", "笑傲江湖"]
# lst.insert(2, "少林足球")
# print(lst)

# 3. extend() 迭代添加(不常用)
# lst= ["小龙女", "李若彤", "阿娇", "景甜"]
# lst.extend(["张三丰", "李四", "王二麻子", "李老五"])
# print(lst)

# 删除
# lst = ["李嘉诚", "马云", "马化腾", "王健林", "你"]
# lst.pop(1)
# print(lst)

# lst.remove("马化腾") # 删除. 指定某一个元素删除
# print(lst)

# del lst[3]
# print(lst)

# lst.clear() # 清空列表
# print(lst)


# 修改
# lst = ["马大帅", "乡村爱情", "刘老根", "圣水湖畔"]
# lst[1] = "东北一家人" # 索引修改
# print(lst)

# # 查询-> 用的最多的是索引
# lst = ["马大帅", "乡村爱情", "刘老根", "圣水湖畔"]
# # # print(lst[3])
# # # 列表是一个可迭代对象. 可以使用for循环
# # for item in lst: # item:列表中的每一项元素
# #     print(item)
#
# print("马大帅" in lst) # 成员判断

# 相关操作
# sort()
# lst = [1,5,4,7,5,4,11,2,5,44,5,1,3,6]
# # reverse: 只要看到它. 一定是反着来
# lst.sort(reverse=True) # 排序
# print(lst)

# lst = ["张无忌", "赵敏", "周芷若", "小昭", "阿离"]
# lst.reverse() # 列表的翻转
# print(lst)

# 深浅拷贝
# a = 20
# b = a
#
# print(a is b) # 判断a和b的内存地址是否完全一致


# a = [1,2,3]
# b = a # 赋值操作没有进行拷贝. 还是同一个对象
# # print(a is b)
#
# a.append(4444)
# print(a)
# print(b)


# 周杰伦吃三个馒头 jay同时也吃了三个馒头 -> 因为周杰伦和jay是同一个人
# 赋值操作没有创建新对象





# a = [1,2,3]
# b = a[:] # 此时对a进行了复制. 此时创建了新的列表, 浅拷贝
# print(a is b)
#
# a.append(4444)
# print(a)
# print(b)


# 浅拷贝出现的问题.  解决方案:用深拷贝
# 作业: xxxxxjlkjflkasdjkfljasklfd, 此题答案见附录1.0
# 作业: xxxxxjlkjflkasdjkfljasklfd, 此题答案见附录1.0

# a = [1,2,3, [123, 456]]
# b = a.copy()
# print(a is b)
# print(a[3] is b[3])
# # a.append(4444)
# # print(a)
# # print(b)

# 如果画不明白, 装teamviewer, 找我

# # 深拷贝
# import copy # 导入一个copy模块
# lst = [1,2,3, [123, 456]]
# lst2 = copy.deepcopy(lst) # 深度拷贝(深度克隆, 原型模式)
# print(lst2)
#
# print(lst is lst2)
# print(lst[3] is lst2[3])
# # 注意. 此时不论任何操作都不会互相的影响
# lst[3].append("胡辣汤")
# print(lst)
# print(lst2)


# 元组是不可变的列表, 又被成为只读列表
# 元组用小括号表示, 并且空元祖用tuple(), 如果元组中只有一个元素,必须在后面加逗号
# # 元组是可迭代对象

# tu = (1,) # 此时认为()是数学运算, 加了逗号就是元组
# print(type(tu))
# print(tu)

# tu = ("金庸", "古龙", "黄奕", "孙晓")
# for t in tu:
#     print(t)


# 列表在循环的时候删除操作