# 字典存储数据的时候. 它是根据hash值进行存储的. 字典中所有的key必须是可哈希的.
# 字典用{}表示. 以key:value的形式进行保存数据
# dic = {"jay":"周杰伦", "wlh":"王力宏", "jj":"林俊杰"}
#
# print(dic)
# print(type(dic))

# # 不可变就是可哈希
# dic = {1:"呵呵", "hh":"哈哈", []:"吼吼"} # unhashable type: 'list'
# print(dic)

# 字典的增伤改查
# 查询
# dic = {"金庸": "扫地僧", "古龙": "天机老人", "黄奕": "alex"}
# print(dic["金庸"]) # 用的最多的是这种写法
# print(dic["李寻欢"]) # KeyError: '李寻欢' 没有这个key

# print(dic.get("李寻欢")) # 默认情况下. 如果找不到这个key, 返回None
# print(dic.get("李寻欢", "没这个人")) # 当key不存在, 返回第二个数据
# print(dic["李寻欢"])


# 添加
# dic = {}
# dic["赵本山"] = "乡村爱情协奏曲" # dic[新key] = value
# dic["赵本水"] = "综艺节目"
#
# dic["赵本山"] = "马大帅" # 替换., 修改. 当key存在了的时候. 是修改
# print(dic)

# # dic.setdefault("安安") # 如果只有一个参数. value放空
# dic.setdefault("安安", "很高") # 如果有两个参数. 可以执行新增
# dic.setdefault("安安", "很瘦") # 当执行到这句话的时候. 字典中已经有了安安. 此时就不会再执行新增了
# print(dic)

# setdefault执行流程:
# 1.首先判断你给的key是否在字典中出现了. 如果出现了. 就不执行任何新增操作. 如果没有出现. 执行新增
# 2.不论前面是否执行了新增. 最后都会根据你给的key把value查询出来

# dic = {"安安": "班主任", "大安安":'大美女'}
# ret = dic.setdefault("大安安", "大美女")
# print(dic)
# print(ret)

# lst = [11,22,33,44,55,66,77,88,99]
# ret = {}
# for item in lst:
#     if item < 66:
#         if not ret.get("key1"):
#             ret["key1"] = [item]
#         else:
#             ret["key1"].append(item)
#     else:
#         if not ret.get("key2"):
#             ret["key2"] = [item]
#         else:
#             ret["key2"].append(item)
# print(ret)

# 难
# for item in lst:
#     if item < 66:
#         ret.setdefault("key1", []).append(item)
#     else:
#         ret.setdefault("key2", []).append(item)
# print(ret)


# 删除
# dic = {"alex": "路飞", "wusir": "alex", "老男孩": "linux", "linux":"成全了老男孩"}
# dic.pop("alex") # 根据key删除
# print(dic)
# dic.clear()

# del dic['wusir'] # 根据key删除
# print(dic)


# 查询补充: keys(), values() , items()
dic = {"alex": "路飞", "wusir": "alex", "老男孩": "linux", "linux":"成全了老男孩"}
# print(dic.keys()) # 像列表, 不是列表, 山寨列表
# for item in dic.keys(): # 可以直接拿到每一个key
#     print(item)
#     print(dic[item])

# # 记这个
# for k in dic: # 字典是可迭代的. 此时拿到的k就是字典中所有的key
#     print(k)
#     print(dic[k])

# print(dic.values()) # 获取到所有的value.

# for v in dic.values(): # 很少用到这个
#     print(v)
#
# print(dic.items())

# 直接获取到key和value的方式
# for k, v in dic.items(): # dic.items()  => 打开之后是元组 =>  打开是=> key, value
#     print(k, "=>", v)
   

# 解构, 解包: 把元组, 列表中的每一项拿出来赋值给前面的变量
# 要求:数据和变量要能对的上
# a, b, c = (1, 2, 3) # (1, 2)
# print(a)
# print(b)


# dic = {"aa":"安安", "xx":"晓雪", "xr":"小茹"}

# for k in dic:
#     print(k)
#     print(dic[k])

# for k, v in dic.items():
#     print(k)
#     print(v)

# 字典的嵌套

wf = {
    "name": "汪峰",
    "age": 42,
    "wife": {
        "name":"章子怡",
        "age": 41,
        "hobby":["拍戏", "当导师.."],
        "assit":{
            "name":"章助理",
            "age":18
        }
    },
    "children":[
        {"name":"汪小峰1号", "age":18},
        {"name":"汪小峰2号", "age":8},
        {"name":"汪小峰3号", "age":2}
        
    ]
}
# # 查询汪峰2儿子的年龄
# print(wf['children'][1]['age'])
# # 汪峰老婆的助理的年龄
# print(wf["wife"]['assit']['age'])
# 给汪峰小儿子加10岁
wf['children'][2]['age'] = wf['children'][2]['age'] + 10
print(wf)

# 字典没有索引和切片
