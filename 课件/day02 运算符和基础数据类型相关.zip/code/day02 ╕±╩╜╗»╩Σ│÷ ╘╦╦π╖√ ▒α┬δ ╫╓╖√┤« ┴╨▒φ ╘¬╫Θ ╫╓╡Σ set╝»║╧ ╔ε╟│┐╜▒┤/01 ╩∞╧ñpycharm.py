# 希望大家养成一个习惯性保存的好习惯  ctrl + s
# abcdefg = 12

print("你好啊, 我叫赛利亚")
