# int类型的数据. 基本运算 +-*/ // **
# bit_length() 二进制长度
# a = 3 # 11
# print(a.bit_length()) # 二进制长度 2


# bool类型. 基本数据类型之间的互相转换
# a = True
# print(type(a)) # <class 'bool'>
#
# # bool => int
# b = int(a) # 把xxx转化成数字
# print(b) # True => 1

# True => 1
# False => 0

# print(bool(0)) # False
# print(bool(-1)) # True

# 0 => False
# 非0 => True

# while 1: # while 1(效率高一点点) 和 while True
#     print("还我钱!!!!!!")

# 结论2: 你想把x转化成y   需要y(x)
# 字符串 => 数字
# int(字符串)

# print(bool("")) # 能够表示False的字符串是空字符串
# 结论3: 所有表示空的东西都是假

# print(bool(None)) # None : 空, 真空.

