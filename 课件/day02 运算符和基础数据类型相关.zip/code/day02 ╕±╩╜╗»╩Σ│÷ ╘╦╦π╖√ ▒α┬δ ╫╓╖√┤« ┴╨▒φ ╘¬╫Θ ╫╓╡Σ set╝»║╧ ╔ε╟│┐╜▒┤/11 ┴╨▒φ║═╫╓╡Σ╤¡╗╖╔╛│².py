# lst = ["jay", "jj", "Jolin", "alex"]
# # lst.clear()  不准用clear
# # for item in lst: # 删不干净
# #     lst.remove(item)
#
# # 1. 把要删除的元素记录在一个新列表中
# new_lst = []
# for el in lst:
#     new_lst.append(el)
#
# for item in new_lst: # 循环新列表. 循环出来的都是要删除的内容
#     lst.remove(item) # 删除原来的列表中的内容
#
#
# print(lst)


# lst = ["金城武", "李嘉诚", "鹿晗", "韩露", "李易峰", "吴亦凡"]
# # 删除姓李的
#
# # 把要删除的人装新列表中
# new_list = []
# for item in lst:
#     if item.startswith("李"):
#         new_list.append(item)
#
# # 循环新列表. 删除老列表
# for item in new_list:
#     lst.remove(item)
#
# print(lst)

dic = {"jay":"呵呵", "jj":"哈哈", "Jolin":"吼吼"}

new_lst = []

for k in dic:
    # dic["哈哈哈"] = "呵呵"
    # dic.pop(k) # dictionary changed size during iteration
    new_lst.append(k)
    
for k in new_lst:
    dic.pop(k)
    
print(dic)
