import base64
import string
import random
import time

from Crypto.Hash import SHA, SHA256
from Crypto.PublicKey import RSA
from Crypto.Signature import PKCS1_v1_5 as Sign_PK
import json


#我自己在UAT环境使用sessionID可以成功的报文 parseMpqrcPayload主扫EMV国外解析二维码数据
data1 = {
    "cardAmount": "1000",
    "currency": "840",
    "msgInfo": {
        "insID": "151525",
        "msgID": "A3999012220210414172059774800",
        "timeStamp": "20210414172059"
    },
    "trxInfo": {
        "cvmInfo": "eyJhbGciOiJSU0ExXzUiLCJlbmMiOiJBMTI4Q0JDLUhTMjU2Iiwia2lkIjoiMTUxNTI1MDAwMSJ9.rBBB4GtRXAmbkifECSrV1PvJj1Xf_1FVXvaGWuDcoHw3suk9eB3DTx816irjEpi0TcW4BBgIJX5wTuVr5Ry0_R3xpOX5m5q1gZqXirYvwYWEtgW1bGpIN8CuyvBNSvYoaR445x-p_3_Jc0f2shNkg6hJ7Do_kwtAvV_vtNg80_xztSP2vAg-rDZ3g_uYxjWj3FEMTEHXr6lK2gsskZ_d2IPwVjei-eeKRHHryAMO-gdDE2pH7eXcT0YQa6Elv8wRC0fOr2jggGPkUIvOEilZs-jaYGcp4tv3bJC0qhetRfzn183ettaNbZG3s7CFkxXD5fy7M078UR9Izx-4PIzMYA.ZTAxZTBlNDlhNWY2NDM4Yw.-H4v5NU8gxvdWOaViZnNTIEu4F6_M82fbJ-zyWHfVrLgArFSKt7DaI1ZFR3mON3z.19HMCkpnU-KDAqPNpUbhrg",
        "deviceID": "710f6324aa0643e5875b7fa2d44ec20d",
        "prdNo": "1000",
        "userID": "+8618612211331"
    }
}

#随机数
uuid = ''.join(random.sample(string.digits + string.ascii_letters,32))
header = {"alg":"RS256","kid":"1515250004","crit":["UPI-UUID","UPI-TIMESTAMP","UPI-APPID"],"UPI-UUID":uuid,"UPI-TIMESTAMP":int(time.time()),"UPI-APPID":"151525"}

# origin_header={"alg":"RS256","kid":"1515250004","crit":["UPI-UUID","UPI-TIMESTAMP","UPI-APPID"],"UPI-UUID":"eb8e27e82db548669dbd573f4f0ccf1b","UPI-TIMESTAMP":"1618392059","UPI-APPID":"151525"}
#卡注册你给的报文
data2={"cardAmount":"1000","currency":"840","msgInfo":{"insID":"151525","msgID":"A3999012220210414172059774800","timeStamp":"20210414172059"},"trxInfo":{"cvmInfo":"eyJhbGciOiJSU0ExXzUiLCJlbmMiOiJBMTI4Q0JDLUhTMjU2Iiwia2lkIjoiMTUxNTI1MDAwMSJ9.rBBB4GtRXAmbkifECSrV1PvJj1Xf_1FVXvaGWuDcoHw3suk9eB3DTx816irjEpi0TcW4BBgIJX5wTuVr5Ry0_R3xpOX5m5q1gZqXirYvwYWEtgW1bGpIN8CuyvBNSvYoaR445x-p_3_Jc0f2shNkg6hJ7Do_kwtAvV_vtNg80_xztSP2vAg-rDZ3g_uYxjWj3FEMTEHXr6lK2gsskZ_d2IPwVjei-eeKRHHryAMO-gdDE2pH7eXcT0YQa6Elv8wRC0fOr2jggGPkUIvOEilZs-jaYGcp4tv3bJC0qhetRfzn183ettaNbZG3s7CFkxXD5fy7M078UR9Izx-4PIzMYA.ZTAxZTBlNDlhNWY2NDM4Yw.-H4v5NU8gxvdWOaViZnNTIEu4F6_M82fbJ-zyWHfVrLgArFSKt7DaI1ZFR3mON3z.19HMCkpnU-KDAqPNpUbhrg","deviceID":"710f6324aa0643e5875b7fa2d44ec20d","prdNo":"1000","userID":"+8618612211331"}}


#UPI-JWS=Base64(原始header)+'..'+Base64(SHA256WithRSA(Base64(原始header)+'.'+Base64(data)))
#part1=Base64(原始header)
part1 = base64.urlsafe_b64encode(json.dumps(header,separators=(',',':')).encode()).decode().strip('=')
print(part1)
#Base64(data)
base64_data = base64.urlsafe_b64encode(json.dumps(data1,ensure_ascii=False,separators=(',',':')).encode()).decode().strip('=')

#(Base64(原始header)+'.'+Base64(data))
part2 = part1 + '.' + base64_data
print("content ",part2)

#摘要处理原文
digest_data = SHA256.new(part2.encode("utf8"))


with open('data/private.pem') as f:
    key = f.read()
    rsa_key = RSA.import_key(key)
    #私钥签名
    sign_pk = Sign_PK.new(rsa_key)
    sign_data = sign_pk.sign(digest_data)
    #Base64(SHA256WithRSA(Base64(原始header)+'.'+Base64(data))
    SHA256WithRSA_base64 = base64.urlsafe_b64encode(sign_data).decode().strip('=')

    # print(SHA256WithRSA_base64)
   #Base64(原始header)+'..'+Base64(SHA256WithRSA(Base64(原始header)+'.'+Base64(data)))
    signature = part1 + '..' + SHA256WithRSA_base64

    print(signature)
    #
    # print(int(time.time()))









