import yaml
import base
import requests
import allure
import json
import time
import base64
import string
import random

from Crypto.Hash import SHA256
from Crypto.PublicKey import RSA
from Crypto.Signature import PKCS1_v1_5 as Sign_PK



class SaasCard:
    def __init__(self):
        self.session = requests.session()

    #通用解析yaml数据方法
    def get_data(self,files):
        with open(files,encoding='utf-8') as f:
            yml_data = yaml.safe_load(f)
            data = []
            for i in yml_data.keys():
                errorCode = yml_data[i]['errorCode']
                datas = yml_data[i]['data']
                eles = (datas,errorCode)
                data.append(eles)
        return data

    #通用解析casename
    @allure.story("获取casename")
    def get_case_name(self,files):
        with open(files,encoding='utf-8') as f:
            yml_data = yaml.safe_load(f)
            casenames = []
            for i in (yml_data.keys()):
                casenames.append(i)
        return casenames


    @allure.story("获取MsgInfo")
    def genMsgInfo(self):
        self.url = base.easy_bank_base_url + '/interface/genMsgInfo'
        r = requests.get(url=self.url,headers=self.myHeader,verify=False)
        msgID = r.json()['msgID']
        return msgID


    @allure.story("获取卡qrcToken")
    def get_qrcToken(self):
        self.url = base.easy_bank_base_url + '/interface/getCardListNew?refresh=1'
        r = requests.get(url=self.url,headers=self.myHeader,verify=False)
        n = len(r.json()['userCardInfoDtoList'])
        if n > 0:
            qrcToken = r.json()['userCardInfoDtoList'][0]['qrcToken']
        else:
            print("未绑卡")
        return qrcToken

    @allure.story("获取卡数量")
    def get_card_count(self):
        self.url = base.easy_bank_base_url + '/interface/getCardListNew?refresh=1'
        r = requests.get(url=self.url,headers=self.myHeader,verify=False)
        n = len(r.json()['userCardInfoDtoList'])
        return n


    #获取卡密
    @allure.story("获取卡密")
    def get_card(self,files):
        with open(files,encoding='utf-8') as f:
            lines = [line.strip('\n') for line in f.readlines()]
        return lines

    #删除已使用卡
    @allure.story("删除已使用卡")
    def del_used_card(self,files):
        cards = self.get_card(files)
        cards.pop()
        with open(files,'a',encoding='utf-8') as f:
            f.seek(0)
            f.truncate()
            # f.write(''.join(str(i) for i in cards) +'\n')
        for i in cards:
            with open(files,'a',encoding='utf-8') as f:
                f.write(i+'\n')


    #生成付款码
    @allure.story("生成付款码")
    def qrcGeneration(self,session,data,header):
        self.url = base.saascard_app_base_url + '/interface/qrcGeneration'
        self.data = data
        self.header = header
        r = session.post(url=self.url,json=self.data,headers=self.header,verify=False)
        return r

    # 查询交易明细
    @allure.story("查询交易信息")
    def getTransactions(self, session, data,header):
        self.url = base.saascard_app_base_url + '/interface/getTransactions'
        self.data = data
        self.header = header
        r = session.post(url=self.url, json=self.data, headers=self.header, verify=False)
        return r

    # 查询交易详情
    @allure.story("查询交易信息")
    def getTransaction(self, session, data,header):
        self.url = base.saascard_app_base_url + '/interface/getTransaction'
        self.data = data
        self.header = header
        r = session.post(url=self.url, json=self.data, headers=self.header, verify=False)
        return r

    @allure.story('卡注册')
    def card_enrollment(self,session,data,header):
        self.url = base.saascard_app_base_url + '/interface/cardEnrollment'
        self.data = data
        self.header = header
        return session.post(url=self.url,headers=self.header,json=self.data,verify=False)

    @allure.story('卡状态查询')
    def card_status_inquiry(self,session,data,header):
        self.url = base.saascard_app_base_url + '/interface/cardStatusInquiry'
        self.data = data
        self.header = header
        return session.post(url=self.url,headers=self.header,json=self.data,verify=False)

    @allure.story('卡状态管理')
    def card_status_management(self,session,data,header):
        self.url = base.saascard_app_base_url + '/interface/cardStatusManagement'
        self.data = data
        self.header = header
        return session.post(url=self.url,headers=self.header,json=self.data,verify=False)

    @allure.story('查询卡信息')
    def get_card_info(self,session,data,header):
        self.url = base.saascard_app_base_url + '/interface/getCardInfo'
        self.data = data
        self.header = header
        return session.post(url=self.url,headers=self.header,json=self.data,verify=False)

    @allure.story('主扫emv国外解析二维码数据')
    def parse_mpqrc_payload(self,session,data,header):
        self.url = base.saascard_app_base_url + '/interface/parseMpqrcPayload'
        self.data = data
        self.header = header
        return session.post(url=self.url,headers=self.header,json=self.data,verify=False)

    @allure.story('主扫emv国外')
    def mpqrc_payment_emv(self,session,data,header):
        self.url =  base.saascard_app_base_url + '/interface/mpqrcPaymentEMV'
        self.data = data
        self.header = header
        return session.post(url=self.url,headers=self.header,json=self.data,verify=False)

    @allure.story('主扫url国内')
    def mpqrc_payment_url(self,session,data,header):
        self.url =  base.saascard_app_base_url + '/interface/mpqrcPaymentURL'
        self.data = data
        self.header = header
        return session.post(url=self.url,headers=self.header,json=self.data,verify=False)

    @allure.story('主扫URL国内查询扫码信息')
    def qrc_info_inquiry(self,session,data,header):
        self.url =  base.saascard_app_base_url + '/interface/qrcInfoInquiry'
        self.data = data
        self.header = header
        return session.post(url=self.url,headers=self.header,json=self.data,verify=False)

    @allure.story('主扫交易结果查询')
    def trx_result_inquiry(self,session,data,header):
        self.url =  base.saascard_app_base_url + '/interface/trxResultInquiry'
        self.data = data
        self.header = header
        return session.post(url=self.url,headers=self.header,json=self.data,verify=False)

    @allure.story('被扫是否触发附加流程')
    def get_additional_processing(self,session,data,header):
        self.url =  base.saascard_app_base_url + '/interface/getAdditionalProcessing'
        self.data = data
        self.header = header
        return session.post(url=self.url,headers=self.header,json=self.data,verify=False)

    @allure.story('被扫附加流程用户回复')
    def additional_processing_result(self,session,data,header):
        self.url =  base.saascard_app_base_url + '/interface/additionalProcessingResult'
        self.data = data
        self.header = header
        return session.post(url=self.url,headers=self.header,json=self.data,verify=False)

    @allure.story('被扫根据二维码信息查询交易结果')
    def find_last_result(self,session,data,header):
        self.url =  base.saascard_app_base_url + '/interface/findLastTrxResult'
        self.data = data
        self.header = header
        r = session.post(url=self.url,headers=self.header,json=self.data,verify=False)
        return r


    #获取银联主扫国内url
    def get_qrc_yinlian_mpqrcPayload(self):
        para = time.strftime("%Y%m%d%H%M%S",time.localtime())
        url = 'https://open.unionpay.com/ajweb/help/qrcodeFormPage/sendOk?puid=6&requestType=mainSweepGoldenReceiver&sendtype=QRCode&sendData=[{"fid":131,"keyword":"acqCode","value":"48020000"},{"fid":132,"keyword":"orderNo","value":'+str(para)+'},{"fid":133,"keyword":"orderTime","value":'+str(para)+'},{"fid":134,"keyword":"orderType","value":"10"},{"fid":320,"keyword":"txnAmt","value":""},{"fid":369,"keyword":"termId","value":""},{"fid":383,"keyword":"payeeComments","value":""},{"fid":393,"keyword":"qrValidTime","value":""},{"fid":136,"keyword":"id","value":"777290058135880"},{"fid":137,"keyword":"name","value":"商户名称"},{"fid":381,"keyword":"accNo","value":""},{"fid":382,"keyword":"termId","value":""},{"fid":391,"keyword":"subId","value":""},{"fid":392,"keyword":"subName","value":""}]'
        res = requests.get(url=url).content.decode('utf-8')
        import re
        partten = re.compile(r"https://.*")
        r = partten.search(res).group(0).split(',')[0]
        return r

    #银联被扫国外send
    def qrc_consume_oss_send(self,mpqrcPayload):
        self.header = {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8", 'Connection': 'close'}
        self.url = 'https://qrctest.unionpayintl.com/cqrt/ossComsume/send'
        self.data = {'BODY_4':'10',
                'caseCd':'211',
                'cgqrc':mpqrcPayload}
        res = requests.post(url=self.url,headers=self.header,data=self.data,verify=False)
        return res.status_code



    # 获取银联被扫国内url
    def qrc_consume_sendok(self,barcodeCpqrcPayload):
        para = time.strftime("%Y%m%d%H%M%S", time.localtime())
        url = 'https://open.unionpay.com/ajweb/help/qrcodeFormPage/sendOk?puid=14&requestType=coverSweepGoldenReceiver&sendtype=Purchase&sendData=[{"fid":352,"keyword":"acqCode","value":"48020000"},{"fid":353,"keyword":"merId","value":"777290058135880"},{"fid":354,"keyword":"merCatCode","value":"5811"},{"fid":355,"keyword":"merName","value":"商户名称"},{"fid":356,"keyword":"reqType","value":"0310000903"},{"fid":357,"keyword":"txnAmt","value":"300"},{"fid":358,"keyword":"termId","value":"49000002"},' \
              '{"fid":359,"keyword":"qrNo","value":'+barcodeCpqrcPayload+'},' \
                                                                         '{"fid":360,"keyword":"backUrl","value":"http://101.231.204.84:8091/sim/notify_url2.jsp"},' \
                                                                         '{"fid":372,"keyword":"orderNo","value":'+str(para)+'},' \
                                                                                                                             '{"fid":373,"keyword":"orderTime","value":'+str(para)+'}]'
        print(url)
        res = requests.get(url=url)
        return res.status_code


    @allure.story("H5获取发红包人信息")
    def redp_sender_Info(self,session,data):
        self.url = base.easy_bank_base_url + '/api/send-red-packet/senderInfo'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    @allure.story("发红包记录")
    def redp_send_record(self,session,data):
        self.url = base.easy_bank_base_url + '/api/send-red-packet/sendRedPacketRecord'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    def signature(self,data):
        self.data = data
        #随机数
        uuid = ''.join(random.sample(string.digits + string.ascii_letters,32))
        header = {"alg":"RS256","kid":"1515250004","crit":["UPI-UUID","UPI-TIMESTAMP","UPI-APPID"],"UPI-UUID":uuid,"UPI-TIMESTAMP":int(time.time()),"UPI-APPID":"151525"}

        #规则UPI-JWS=Base64(原始header)+'..'+Base64(SHA256WithRSA(Base64(原始header)+'.'+Base64(data)))
        #Base64(原始header)
        part1 = base64.urlsafe_b64encode(json.dumps(header,ensure_ascii=False,separators=(',',':')).encode()).decode().strip('=')
        #Base64(data)ensure_ascii=False解决中文的问题，separators=(',',':')解决空格的问题
        base64_data = base64.urlsafe_b64encode(json.dumps(self.data,ensure_ascii=False,separators=(',',':')).encode()).decode().strip('=')

        #(Base64(原始header)+'.'+Base64(data))
        part2 = part1 + '.' + base64_data
        #hash对象
        digest_data = SHA256.new(part2.encode("utf8"))
        private_key = base.file_path + '/data/private.pem'
        with open(private_key,encoding='utf-8') as f:
            key = f.read()
            rsa_key = RSA.import_key(key)
            #私钥签名
            sign_pk = Sign_PK.new(rsa_key)
            sign_data = sign_pk.sign(digest_data)
            #Base64(SHA256WithRSA(Base64(原始header)+'.'+Base64(data))
            SHA256WithRSA_base64 = base64.urlsafe_b64encode(sign_data).decode().strip('=')
            #Base64(原始header)+'..'+Base64(SHA256WithRSA(Base64(原始header)+'.'+Base64(data)))
            signature = part1 + '..' + SHA256WithRSA_base64
            return signature

    def broker_signature(self,data):
        # 先排序
        js = json.dumps(data, ensure_ascii=False,separators=(',',':'),sort_keys=True)
        # 将 JSON 对象转换为 Python 字典
        json_dict = json.loads(js)
        items = sorted(json_dict.items())
        # 在拼为新的字符串
        result = ''
        for key, value in items:
            result += (str(key) + '=' + str(value)) + '&'
        org_data = result[:-1]
        #摘要处理原文
        digest_data = SHA256.new(org_data.encode("utf8")).hexdigest()
        d_data = SHA256.new(digest_data.encode('utf8'))
        private_key = base.file_path + '/data/privatekey_bhy.pem'
        with open(private_key,encoding='utf-8') as f:
            key = f.read()
            rsa_key = RSA.import_key(key)
            #私钥签名
            sign_pk = Sign_PK.new(rsa_key)
            sign_data = sign_pk.sign(d_data)

            #是否需要urlbase64
            SHA256WithRSA_base64 = base64.b64encode(sign_data).decode()
            data.update({"signature":SHA256WithRSA_base64})
            return data

    @allure.story("证转银请求")
    def transaction_withdrawal(self,session,data):
        self.url = 'http://8.131.88.65:8810/broker/api/v2/business/transaction/withdrawal'
        self.data = data
        r = session.post(url=self.url,json=self.data,verify=False)
        return r
