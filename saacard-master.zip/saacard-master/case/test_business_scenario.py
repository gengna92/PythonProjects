#todo 主扫、被扫功能
import random
import string
import time
import requests
import allure
import pytest
import datetime
from dateutil.relativedelta import relativedelta
import os, sys
path = os.path.abspath(__file__)
for i in range(2):
    path = os.path.dirname(path)
    sys.path.append(path)
import base
from api.saascardApi import SaasCard

class TestQrc:
    def setup(self):
        self.session = requests.session()
        self.preCard = SaasCard()
        self.tmp = globals()

    def teardowm(self):
        self.session.close()


    @allure.story('主扫EMV国外')
    @allure.severity('blocker')
    def test_mpqrc_payment_emv(self):
        self.msgid = ''.join(random.sample(string.digits + string.ascii_letters,28))
        #此处token写死了，后续可做成动态
        self.tmp['token'] = '6292690169160886'
        self.data = {
            "msgInfo": {
                "insID": "151525",
                "msgID": self.msgid,
                "msgType": "string",
                "timeStamp": "20200921100936",
                "versionNo": "string"
            },
            "trxInfo": {
                "deviceID": "1b5ddc2562a8de5b4e175d418f5b7edf",
                "merchantInfo": {
                    "acquirerIIN": "25000344",
                    "fwdIIN": "00020344",
                    "mcc": "5972",
                    "merchantCountry": "HK",
                    "merchantName": "Test Merchant",
                    "mid": "100000000000006",
                    "termId": "string"
                },
                "mpqrcPayload": "000201010211153125000344000203441000000000000065204597253033445802HK5913Test Merchant6002HK626001200000000000000000000005200000000000000000000007080000001063045855",
                "token": self.tmp['token'],
                "trxAmt": "1.00",
                "trxCurrency": "344",
                "trxFeeAmt": "0",
                "userID": "PB10000900"
            }
        }
        self.env_header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(self.data),"INS-ID":"151525"}
        res = self.preCard.mpqrc_payment_emv(self.session,self.data,self.env_header)
        try:
            ret = res.json()['msgResponse']['responseCode']
            qrcVoucherNo_emv = res.json()['trxInfo']['qrcVoucherNo']
            assert ret == '00'
            startTime = datetime.date.today() - relativedelta(months=+1)
            endTime = datetime.date.today()
            #获取最新的一条交易记录进行断言是否消费成功
            self.tran_data = {
                "msgInfo": {
                    "insID": "151525",
                    "msgID": "A39990122000000000000751089",
                    "msgType": "string",
                    "timeStamp": "20200921100936",
                    "versionNo": "string"
                },
                "trxInfo": {
                    "endTime": str(endTime),
                    "pageNo": 1,
                    "pageSize": 1,
                    "paymentState": "SUCCESS",
                    "startTime": str(startTime),
                    "token": self.tmp['token']
                }
            }
            self.tran_header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(self.tran_data),"INS-ID":"151525"}
            res = self.preCard.getTransactions(self.session,self.tran_data,self.tran_header)
            qrcVoucherNo_t = res.json()['transactions']['records'][0]['qrcVoucherNo']
            assert qrcVoucherNo_emv == qrcVoucherNo_t
        except:
            allure.attach(Exception)
            raise Exception

    @allure.story('主扫url国内')
    @allure.severity('blocker')
    def test_mpqrc_payment_url(self):
        self.msgid = ''.join(random.sample(string.digits + string.ascii_letters,28))
        # 此处token写死了，后续可做成动态
        self.tmp['token'] = '6292690169160886'
        #获取mpqrcPayload
        self.tmp['mpqrcPayload'] = self.preCard.get_qrc_yinlian_mpqrcPayload()
        #获取origTrxMsgID
        self.info_data = {
            "msgInfo": {
                "insID": "151525",
                "msgID": self.msgid,
                "msgType": "string",
                "timeStamp": "20210406164357",
                "versionNo": "string"
            },
            "trxInfo": {
                "deviceID": "RERCOUZDODGTMZFFMS00NDM4LTK2N0YTMEJDNJCXM0EWMT",
                "mpqrcPayload": self.tmp['mpqrcPayload'],
                "userID": "PB10000900"
            }
        }
        self.info_header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(self.info_data),"INS-ID":"151525"}
        self.tmp['origTrxMsgID'] = self.preCard.qrc_info_inquiry(self.session,self.info_data,self.info_header).json()['msgInfo']['msgID']
        self.msgid_01 = ''.join(random.sample(string.digits + string.ascii_letters,28))
        self.payment_url_data = {
            "msgInfo": {
                "insID": "151525",
                "msgID": self.msgid_01,
                "msgType": "string",
                "timeStamp": "20200921100936",
                "versionNo": "string"
            },
            "trxInfo": {
                "deviceID": "RERCOUZDODGTMZFFMS00NDM4LTK2N0YTMEJDNJCXM0EWMT",
                "merchantInfo": {
                    "mcc": "5811",
                    "merchantName": "商户*"
                },
                "mpqrcPayload": self.tmp['mpqrcPayload'],
                "origTrxMsgID": self.tmp['origTrxMsgID'],
                "token": self.tmp['token'],
                "trxAmt": "2.00",
                "trxCurrency": "156",
                "trxFeeAmt": "0",
                "userID": "PB10000900"
            }
        }
        self.url_header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(self.payment_url_data),"INS-ID":"151525"}
        res = self.preCard.mpqrc_payment_url(self.session, self.payment_url_data,self.url_header)
        try:
            ret = res.json()['msgResponse']['responseCode']
            qrcVoucherNo_emv = res.json()['trxInfo']['qrcVoucherNo']
            assert ret == '00'
            startTime = datetime.date.today() - relativedelta(months=+1)
            endTime = datetime.date.today()
            # 获取最新的一条交易记录进行断言是否消费成功
            self.tran_data = {
                "msgInfo": {
                    "insID": "151525",
                    "msgID": "A39990122000000000000751089",
                    "msgType": "string",
                    "timeStamp": "20200921100936",
                    "versionNo": "string"
                },
                "trxInfo": {
                    "endTime": str(endTime),
                    "pageNo": 1,
                    "pageSize": 1,
                    "paymentState": "SUCCESS",
                    "startTime": str(startTime),
                    "token": self.tmp['token']
                }
            }
            self.tran_header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(self.tran_data),"INS-ID":"151525"}
            res = self.preCard.getTransactions(self.session,self.tran_data,self.tran_header)
            qrcVoucherNo_t = res.json()['transactions']['records'][0]['qrcVoucherNo']
            assert qrcVoucherNo_emv == qrcVoucherNo_t
        except:
            allure.attach(Exception)
            raise Exception

    @allure.story("被扫国内场景验证")
    @allure.severity('blocker')
    def test_qrc_payment_inbound(self):
        #生成付款barcode
        self._msg_id = ''.join(random.sample(string.digits + string.ascii_letters,28))
        #token
        self.tmp['token'] = '6292690181183296'
        self.qrc_gen_data = {
            "msgInfo": {
                "insID": "151525",
                "msgID": self._msg_id,
                "msgType": "string",
                "timeStamp": "20210323162631",
                "versionNo": "string"
            },
            "trxInfo": {
                "couponInfo": "string",
                "cpqrcNo": "1",
                "cvmLimit": "0",
                "deviceID": "NEFFREEZOTMTMJY5MY00RDI3LTG2MUUTMDQ1ODUWRTC2OD",
                "limitCurrency": "840",
                "token": self.tmp['token'],
                "trxLimit": "10000",
                "userID": "PB10001000"
            }
        }
        self.qrc_gen_header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(self.qrc_gen_data),"INS-ID":"151525"}
        res = self.preCard.qrcGeneration(self.session,self.qrc_gen_data,self.qrc_gen_header)
        responseCode = res.json()['msgResponse']['responseCode']
        barcodeCpqrcPayload = res.json()['trxInfo']['barcodeCpqrcPayload']
        para = barcodeCpqrcPayload[0]
        assert responseCode == "00"
        #调取银联接口进行消费
        res = self.preCard.qrc_consume_sendok(para)
        if res == 200:
            allure.attach('调取银联接口成功')
            #被扫是否触发附加流程
            while 1:
                self._msgID = ''.join(random.sample(string.digits + string.ascii_letters,28))
                self.additon_data = {
                    "msgInfo": {
                        "insID": "151525",
                        "msgID": self._msgID,
                        "msgType": "string",
                        "timeStamp": "20210407151631",
                        "versionNo": "string"
                    },
                    "trxInfo": {
                        "barcodeCpqrcPayload": para,
                        "token": self.tmp['token']
                    }
                }
                self.add_header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(self.additon_data),"INS-ID":"151525"}
                add_res = self.preCard.get_additional_processing(self.session,self.additon_data,self.add_header)
                print(add_res)
                if add_res.json()['trxInfo'] != None:
                    self.tmp['origMsgID'] = add_res.json()['trxInfo']['origMsgID']
                    time.sleep(2)
                    break
            #触发被扫附加流程回复
            self.result_msgID = ''.join(random.sample(string.digits + string.ascii_letters,28))
            self.adp_result_data = {
                "msgInfo": {
                    "insID": "151525",
                    "msgID": self.result_msgID,
                    "msgType": "string",
                    "timeStamp": "20210408102723",
                    "versionNo": "string"
                },
                "trxInfo": {
                    "barcodeCpqrcPayload": [para],
                    "deviceID": "NEFFREEZOTMTMJY5MY00RDI3LTG2MUUTMDQ1ODUWRTC2OD",
                    "origMsgID": self.tmp['origMsgID'],
                    "paymentStatus": "CONTINUING",
                    "rejectionReason": "string",
                    "token": self.tmp['token'],
                    "userID": "PB10000900"
                }
            }
            time.sleep(5)
            self.add_result_header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(self.adp_result_data),"INS-ID":"151525"}
            res = self.preCard.additional_processing_result(self.session,self.adp_result_data,self.add_result_header)
            res_code = res.json()['msgResponse']['responseCode']
            #断言被扫附加流程用户回复结果
            assert res_code == '00'
            #成功后根据二维码信息查询交易结果
            #先更新msgid
            for i in range(5):
                time.sleep(1)
                self.result_data_msgID = ''.join(random.sample(string.digits + string.ascii_letters,28))
                self.result_data = {
                    "msgInfo": {
                        "insID": "151525",
                        "msgID": self.result_data_msgID,
                        "msgType": "string",
                        "timeStamp": "20210408102723",
                        "versionNo": "string"
                    },
                    "trxInfo": {
                        "barcodeCpqrcPayload": para,
                        "token": self.tmp['token']
                    }
                }
                self.find_last_header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(self.result_data),"INS-ID":"151525"}
                res = self.preCard.find_last_result(self.session,self.result_data,self.find_last_header)
                ret = res.json()['msgResponse']['responseCode']
                assert ret=='00'
                if res.json()['trxInfo'] !=None:
                    #获取交易号
                    qrcVoucherNo_emv = res.json()['trxInfo']['qrcVoucherNo']
                    break
            startTime = datetime.date.today() - relativedelta(months=+1)
            endTime = datetime.date.today()
            # 获取最新的一条交易记录进行断言是否消费成功
            self.tran_data = {
                "msgInfo": {
                    "insID": "151525",
                    "msgID": "A39990122000000000000751089",
                    "msgType": "string",
                    "timeStamp": "20200921100936",
                    "versionNo": "string"
                },
                "trxInfo": {
                    "endTime": str(endTime),
                    "pageNo": 1,
                    "pageSize": 1,
                    "paymentState": "SUCCESS",
                    "startTime": str(startTime),
                    "token": self.tmp['token']
                }
            }
            self.tran_header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(self.tran_data),"INS-ID":"151525"}
            res = self.preCard.getTransactions(self.session, self.tran_data,self.tran_header)
            qrcVoucherNo_t = res.json()['transactions']['records'][0]['qrcVoucherNo']
            assert qrcVoucherNo_emv == qrcVoucherNo_t
        else:
            allure.attach('调取银联接口失败啦')

    @allure.story("被扫国外场景验证")
    @allure.severity('blocker')
    def test_qrc_payment_overseas(self):
        #生成付款二维码国外
        self._msg_id = ''.join(random.sample(string.digits + string.ascii_letters,28))
        #token
        self.tmp['token'] = '6292690181183296'
        self.qrc_gen_data = {
            "msgInfo": {
                "insID": "151525",
                "msgID": self._msg_id,
                "msgType": "string",
                "timeStamp": "20210323162631",
                "versionNo": "string"
            },
            "trxInfo": {
                "couponInfo": "string",
                "cpqrcNo": "1",
                "cvmLimit": "0",
                "deviceID": "NEFFREEZOTMTMJY5MY00RDI3LTG2MUUTMDQ1ODUWRTC2OD",
                "limitCurrency": "840",
                "token": self.tmp['token'],
                "trxLimit": "10000",
                "userID": "PB10001000"
            }
        }
        self.qrc_gen_header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(self.qrc_gen_data),"INS-ID":"151525"}
        res = self.preCard.qrcGeneration(self.session,self.qrc_gen_data,self.qrc_gen_header)
        responseCode = res.json()['msgResponse']['responseCode']
        emvCpqrcPayload = res.json()['trxInfo']['emvCpqrcPayload']
        para = emvCpqrcPayload[0]
        assert responseCode == "00"
        #调取银联接口进行消费
        res = self.preCard.qrc_consume_oss_send(para)
        if res == 200:
            allure.attach('调取银联接口成功')
            #被扫是否触发附加流程
            while 1:
                self._msgID = ''.join(random.sample(string.digits + string.ascii_letters,28))
                self.additon_data = {
                    "msgInfo": {
                        "insID": "151525",
                        "msgID": self._msgID,
                        "msgType": "string",
                        "timeStamp": "20210407151631",
                        "versionNo": "string"
                    },
                    "trxInfo": {
                        "emvCpqrcPayload": para,
                        "token": self.tmp['token']
                    }
                }
                self.add_header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(self.additon_data),"INS-ID":"151525"}
                add_res = self.preCard.get_additional_processing(self.session,self.additon_data,self.add_header)
                if add_res.json()['trxInfo'] != None:
                    self.tmp['origMsgID'] = add_res.json()['trxInfo']['origMsgID']
                    time.sleep(2)
                    break
                else:
                    raise Exception
            #触发被扫附加流程回复
            self.result_msgID = ''.join(random.sample(string.digits + string.ascii_letters,28))
            self.adp_result_data = {
                "msgInfo": {
                    "insID": "151525",
                    "msgID": self.result_msgID,
                    "msgType": "string",
                    "timeStamp": "20210408102723",
                    "versionNo": "string"
                },
                "trxInfo": {
                    "deviceID": "NEFFREEZOTMTMJY5MY00RDI3LTG2MUUTMDQ1ODUWRTC2OD",
                    "emvCpqrcPayload": [para],
                    "origMsgID": self.tmp['origMsgID'],
                    "paymentStatus": "CONTINUING",
                    "rejectionReason": "string",
                    "token": self.tmp['token'],
                    "userID": "PB10000900"
                }
            }
            time.sleep(5)
            self.add_result_header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(self.adp_result_data),"INS-ID":"151525"}
            res = self.preCard.additional_processing_result(self.session,self.adp_result_data,self.add_result_header)
            res_code = res.json()['msgResponse']['responseCode']
            #断言被扫附加流程用户回复结果
            assert res_code == '00'
            #成功后根据二维码信息查询交易结果
            #先更新msgid
            for i in range(5):
                time.sleep(1)
                self.result_data_msgID = ''.join(random.sample(string.digits + string.ascii_letters,28))
                self.result_data = {
                    "msgInfo": {
                        "insID": "151525",
                        "msgID": self.result_data_msgID,
                        "msgType": "string",
                        "timeStamp": "20210408102723",
                        "versionNo": "string"
                    },
                    "trxInfo": {
                        "emvCpqrcPayload": para,
                        "token": self.tmp['token']
                    }
                }
                self.find_last_header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(self.result_data),"INS-ID":"151525"}
                res = self.preCard.find_last_result(self.session,self.result_data,self.find_last_header)
                ret = res.json()['msgResponse']['responseCode']
                assert ret=='00'
                if res.json()['trxInfo'] !=None:
                    #获取交易号
                    qrcVoucherNo_emv = res.json()['trxInfo']['qrcVoucherNo']
                    break
            startTime = datetime.date.today() - relativedelta(months=+1)
            endTime = datetime.date.today()
            # 获取最新的一条交易记录进行断言是否消费成功
            self.tran_data = {
                "msgInfo": {
                    "insID": "151525",
                    "msgID": "A39990122000000000000751089",
                    "msgType": "string",
                    "timeStamp": "20200921100936",
                    "versionNo": "string"
                },
                "trxInfo": {
                    "endTime": str(endTime),
                    "pageNo": 1,
                    "pageSize": 1,
                    "paymentState": "SUCCESS",
                    "startTime": str(startTime),
                    "token": self.tmp['token']
                }
            }
            self.tran_header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(self.tran_data),"INS-ID":"151525"}
            res = self.preCard.getTransactions(self.session, self.tran_data,self.tran_header)
            qrcVoucherNo_t = res.json()['transactions']['records'][0]['qrcVoucherNo']
            assert qrcVoucherNo_emv == qrcVoucherNo_t
        else:
            allure.attach('调取银联接口失败')













