import pytest
import requests
import allure
import logging
logging.basicConfig(level=logging.DEBUG, format=' %(asctime)s - %(levelname)s- %(message)s')


import os, sys
path = os.path.abspath(__file__)
for i in range(2):
    path = os.path.dirname(path)
    sys.path.append(path)
import base
from api.saascardApi import SaasCard




class TestComm:

    def setup(self):
        self.session = requests.session()
        self.preCard = SaasCard()

    def teardowm(self):
        self.session.close()

    C = SaasCard()
    parse_mpqrc_payload_yml = base.file_path + '/data/qrc/parse_mpqrc_payload.yml'
    @allure.feature("parseMpqrcPayload")
    @pytest.mark.parametrize("data,errorcode",C.get_data(parse_mpqrc_payload_yml),ids=C.get_case_name(parse_mpqrc_payload_yml))
    def test_parse_mpqrc_payload(self,data,errorcode):
        self.header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(data),"INS-ID":"151525"}
        res = self.preCard.parse_mpqrc_payload(self.session,data,self.header)
        err = res.json()['msgResponse']['responseCode']
        errormsg = res.json()['msgResponse']['responseMsg']
        if err != '00':
            allure.attach("errormsg: ", errormsg)
            allure.attach("实际errorcode：", err)
        assert errorcode == err


    mpqrc_payment_emv_yml = base.file_path + '/data/qrc/mpqrc_payment_emv.yml'
    @allure.feature("mpqrcPaymentEMV")
    @pytest.mark.parametrize('data,errorcode',C.get_data(mpqrc_payment_emv_yml),ids=C.get_case_name(mpqrc_payment_emv_yml))
    def test_mpqrc_payment_emv(self,data,errorcode):
        self.header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(data),"INS-ID":"151525"}
        res = self.preCard.mpqrc_payment_emv(self.session,data,self.header)
        err = res.json()['msgResponse']['responseCode']
        errormsg = res.json()['msgResponse']['responseMsg']
        if err != '00':
            allure.attach("errormsg: ", errormsg)
            allure.attach("实际errorcode：", err)
        assert errorcode == err


    mpqrc_payment_url_yml = base.file_path + '/data/qrc/mpqrc_payment_url.yml'
    @allure.feature("mpqrcPaymentURl")
    @pytest.mark.parametrize('data,errorcode',C.get_data(mpqrc_payment_url_yml),ids=C.get_case_name(mpqrc_payment_url_yml))
    def test_mpqrc_payment_url(self,data,errorcode):
        self.header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(data),"INS-ID":"151525"}
        res = self.preCard.mpqrc_payment_url(self.session,data,self.header)
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != '00':
                allure.attach("errormsg: ", errormsg)
                allure.attach("实际errorcode：", err)
            assert errorcode == err
        except:
            ret = res.json()['retCode']
            retmsg = res.json()['retMsg']
            allure.attach("实际errorcode: ", ret)
            allure.attach("errormsg：", retmsg)
            assert errorcode == ret

    qrc_info_inquiry_yml = base.file_path + '/data/qrc/qrc_info_inquiry.yml'
    @allure.feature("qrcinfoinquiry")
    @pytest.mark.parametrize('data,errorcode',C.get_data(qrc_info_inquiry_yml),ids=C.get_case_name(qrc_info_inquiry_yml))
    def test_qrc_info_inquiry(self,data,errorcode):
        self.header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(data),"INS-ID":"151525"}
        res = self.preCard.qrc_info_inquiry(self.session,data,self.header)
        err = res.json()['msgResponse']['responseCode']
        errormsg = res.json()['msgResponse']['responseMsg']
        if err != '00':
            allure.attach("errormsg: ", errormsg)
            allure.attach("实际errorcode：", err)
        assert errorcode == err


    trx_result_inquiry_yml = base.file_path + '/data/qrc/trx_result_inquiry.yml'
    @allure.story('trxresultinquiry')
    @pytest.mark.parametrize('data,errorcode',C.get_data(trx_result_inquiry_yml),ids=C.get_case_name(trx_result_inquiry_yml))
    def test_trx_result_inquiry(self,data,errorcode):
        self.header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(data),"INS-ID":"151525"}
        res = self.preCard.trx_result_inquiry(self.session,data,self.header)
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != '00':
                allure.attach("errormsg: ", errormsg)
                allure.attach("实际errorcode：", err)
            assert errorcode == err
        except:
            ret = res.json()['retCode']
            retmsg = res.json()['retMsg']
            allure.attach("实际errorcode: ", ret)
            allure.attach("errormsg：", retmsg)
            assert errorcode == ret


    get_additional_yml = base.file_path + '/data/qrc/get_additional_processing.yml'
    @allure.story('getadditionalprocessing')
    @pytest.mark.parametrize('data,errorcode',C.get_data(get_additional_yml),ids=C.get_case_name(get_additional_yml))
    def test_get_additional_processing(self,data,errorcode):
        self.header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(data),"INS-ID":"151525"}
        res = self.preCard.get_additional_processing(self.session,data,self.header)
        err = res.json()['msgResponse']['responseCode']
        errormsg = res.json()['msgResponse']['responseMsg']

        if err != '00':
            allure.attach("errormsg: ", errormsg)
            allure.attach("实际errorcode：", err)
        assert errorcode == err


    additional_processing_result_yml = base.file_path + '/data/qrc/additional_processing_result.yml'
    @allure.feature('additionalProcessingResult')
    @pytest.mark.parametrize('data,errorcode',C.get_data(additional_processing_result_yml),ids=C.get_case_name(additional_processing_result_yml))
    def test_additional_processing_result(self,data,errorcode):
        self.header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(data),"INS-ID":"151525"}
        res = self.preCard.additional_processing_result(self.session,data,self.header)
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != '00':
                allure.attach("errormsg: ", errormsg)
                allure.attach("实际errorcode：", err)
            assert err == errorcode
        except:
            ret = res.json()['retCode']
            retmsg = res.json()['retMsg']
            allure.attach("实际errorcode: ", ret)
            allure.attach("errormsg：", retmsg)
            assert errorcode == ret

    find_last_result_yml = base.file_path + '/data/qrc/find_last_result.yml'
    @allure.feature('findlastResult')
    @pytest.mark.parametrize('data,errorcode',C.get_data(find_last_result_yml),ids=C.get_case_name(find_last_result_yml))
    def test_find_last_result(self,data,errorcode):
        self.header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(data),"INS-ID":"151525"}
        res = self.preCard.find_last_result(self.session,data,self.header)
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != '00':
                allure.attach("errormsg: ", errormsg)
                allure.attach("实际errorcode：", err)
            assert err == errorcode
        except:
            ret = res.json()['retCode']
            retmsg = res.json()['retMsg']
            allure.attach("实际errorcode: ", ret)
            allure.attach("errormsg：", retmsg)
            assert errorcode == ret


    card_enrollment_yml = base.file_path + '/data/card/cardEnrollment.yml'
    @allure.feature('card_enrollment')
    @pytest.mark.parametrize('data,errorcode',C.get_data(card_enrollment_yml),ids=C.get_case_name(card_enrollment_yml))
    def test_card_enrollment(self,data,errorcode):
        self.header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(data),"INS-ID":"151525"}
        res = self.preCard.card_enrollment(self.session,data,self.header)
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != '00':
                allure.attach("errormsg: ", errormsg)
                allure.attach("实际errorcode：", err)
            assert err == errorcode
        except:
            ret = res.json()['retCode']
            retmsg = res.json()['retMsg']
            allure.attach("实际errorcode: ", ret)
            allure.attach("errormsg：", retmsg)
            assert errorcode == ret

    card_stat_inquiry_yml = base.file_path + '/data/card/cardStatusInquiry.yml'
    @allure.feature('card_stat_inquiry')
    @pytest.mark.parametrize('data,errorcode',C.get_data(card_stat_inquiry_yml),ids=C.get_case_name(card_stat_inquiry_yml))
    def test_card_status_inquiry(self,data,errorcode):
        self.header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(data),"INS-ID":"151525"}
        res = self.preCard.card_status_inquiry(self.session,data,self.header)
        err = res.json()['msgResponse']['responseCode']
        errormsg = res.json()['msgResponse']['responseMsg']
        if err != '00':
            allure.attach("errormsg: ", errormsg)
            allure.attach("实际errorcode：", err)
        assert err == errorcode


    card_stat_manage_yml = base.file_path + '/data/card/cardStatusManagement.yml'
    @allure.feature('card_stat_manage')
    @pytest.mark.parametrize('data,errorcode',C.get_data(card_stat_manage_yml),ids=C.get_case_name(card_stat_manage_yml))
    def test_card_status_manage(self,data,errorcode):
        self.header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(data),"INS-ID":"151525"}
        res = self.preCard.card_status_management(self.session,data,self.header)
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != '00':
                allure.attach("errormsg: ", errormsg)
                allure.attach("实际errorcode：", err)
            assert err == errorcode
        except:
            ret = res.json()['retCode']
            retmsg = res.json()['retMsg']
            allure.attach("实际errorcode: ", ret)
            allure.attach("errormsg：", retmsg)
            assert errorcode == ret

    get_card_info_yml = base.file_path + '/data/card/getCardInfo.yml'
    @allure.feature('get_card_info')
    @pytest.mark.parametrize('data,errorcode',C.get_data(get_card_info_yml),ids=C.get_case_name(get_card_info_yml))
    def test_get_card_info(self,data,errorcode):
        self.header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(data),"INS-ID":"151525"}
        res = self.preCard.get_card_info(self.session,data,self.header)
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != '00':
                allure.attach("errormsg: ", errormsg)
                allure.attach("实际errorcode：", err)
            assert err == errorcode
        except:
            ret = res.json()['retCode']
            retmsg = res.json()['retMsg']
            allure.attach("实际errorcode: ", ret)
            allure.attach("errormsg：", retmsg)
            assert errorcode == ret

    qrc_generation_yml = base.file_path + '/data/qrc/qrc_generation.yml'
    @allure.feature('qrc_generation')
    @pytest.mark.parametrize('data,errorcode',C.get_data(qrc_generation_yml),ids=C.get_case_name(qrc_generation_yml))
    def test_qrc_generation(self,data,errorcode):
        self.header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(data),"INS-ID":"151525"}
        res = self.preCard.qrcGeneration(self.session,data,self.header)
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != '00':
                allure.attach("errormsg: ", errormsg)
                allure.attach("实际errorcode：", err)
            assert err == errorcode
        except:
            ret = res.json()['retCode']
            retmsg = res.json()['retMsg']
            allure.attach("实际errorcode: ", ret)
            allure.attach("errormsg：", retmsg)
            assert errorcode == ret

    get_transaction_yml = base.file_path + '/data/qrc/get_transition.yml'
    @allure.feature('get_transition')
    @pytest.mark.parametrize('data,errorcode',C.get_data(get_transaction_yml),ids=C.get_case_name(get_transaction_yml))
    def test_get_transaction(self,data,errorcode):
        self.header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(data),"INS-ID":"151525"}
        res = self.preCard.getTransaction(self.session,data,self.header)
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != '00':
                allure.attach("errormsg: ", errormsg)
                allure.attach("实际errorcode：", err)
            assert err == errorcode
        except:
            ret = res.json()['retCode']
            retmsg = res.json()['retMsg']
            allure.attach("实际errorcode: ", ret)
            allure.attach("errormsg：", retmsg)
            assert errorcode == ret


    get_transactions_yml = base.file_path + '/data/qrc/get_transitions.yml'
    @allure.feature('get_transition')
    @pytest.mark.parametrize('data,errorcode',C.get_data(get_transactions_yml),ids=C.get_case_name(get_transactions_yml))
    def test_get_transactions(self,data,errorcode):
        self.header = {"Content-Type": "application/json", "UPI-JWS": self.preCard.signature(data),"INS-ID":"151525"}
        res = self.preCard.getTransactions(self.session,data,self.header)
        try:
            err = res.json()['msgResponse']['responseCode']
            errormsg = res.json()['msgResponse']['responseMsg']
            if err != '00':
                allure.attach("errormsg: ", errormsg)
                allure.attach("实际errorcode：", err)
            assert err == errorcode
        except:
            ret = res.json()['retCode']
            retmsg = res.json()['retMsg']
            allure.attach("实际errorcode: ", ret)
            allure.attach("errormsg：", retmsg)
            assert errorcode == ret





if __name__ == '__main__':
    pytest.main(["-q", "-s", f"{__file__}"])

