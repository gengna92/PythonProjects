import os
import sys
print(sys.path)

# 封装程序常量
saascard_app_base_url = 'http://118.193.47.229:8800'



file_path = os.path.dirname(os.path.abspath(__file__))