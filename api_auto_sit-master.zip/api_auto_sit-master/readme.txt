异常情况通用处理方式：
1.如果使用balance发卡发红包余额不足
UPDATE user_cash_mapping set balance_amount='20000' WHERE phone_no = '+8616200000001'

2.如果使用card发卡发红包余额不足
UPDATE user_card_info set card_amount = '200001',balance_amount = '200000' where qrc_token in ('6292690170944690','6292690154363545')

3.如果卡密用完，制卡
初始化
card doInit  {"channelNo":"015","channelName":"test20210302","currency":"2","count":50,"parValue":"010","initDate":"0318","luckyNumber":["3","4"],"from":"20210318","to":"20230318","months":"25","market":"0","initDesc":"uat制卡-USD"}
DB中查，保存card_pwd
SELECT card_pwd FROM `gift_card` ORDER BY create_time desc LIMIT 50
激活
card doActived {"channelNo":"015","merchantId":"151525","currency":"2","activeNumber":50,"parValue":"010","batchNo":"04","activeDate":"0318"}

其中parValue currency activeDate = initDate 与初始化步骤中一致，batchNo=table 'gift_card'中batch_id

人民币同上步骤
card doInit  {"channelNo":"015","channelName":"test20210302","currency":"1","count":50,"parValue":"010","initDate":"0318","luckyNumber":["3","4"],"from":"20210318","to":"20230318","months":"25","market":"0","initDesc":"uat制卡-CNY"}

