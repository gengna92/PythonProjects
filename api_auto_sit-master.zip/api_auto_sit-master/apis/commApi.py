import yaml
import base
import requests
import allure


class PreCard:

    def __init__(self):
        self.session = requests.session()
        self.data = {
            "channel": "1201",
            "loginId": "+8616200000001",
            "password": "123456",
            "uuid": "0b8a8a7158524f0881b7d8cfedea5e69"
        }
        self.myHeader = {"Content-Type": "application/json", "sessionId": self.get_sessionId()}

    #通用解析yaml数据方法
    def get_data(self,files):
        with open(files,encoding='utf-8') as f:
            yml_data = yaml.safe_load(f)
            data = []
            for i in yml_data.keys():
                errorCode = yml_data[i]['errorCode']
                datas = yml_data[i]['data']
                eles = (datas,errorCode)
                data.append(eles)
        return data

    #通用解析casename
    def get_case_name(self,files):
        with open(files,encoding='utf-8') as f:
            yml_data = yaml.safe_load(f)
            casenames = []
            for i in (yml_data.keys()):
                casenames.append(i)
        return casenames

    @allure.story("获取sessionId")
    def get_sessionId(self):
        self.url = base.pre_bank_base_url + '/perbank/v1/user/login'
        r = requests.post(url=self.url,json=self.data,verify=False)
        sessionId = r.json()["sessionId"]
        return sessionId

    @allure.story("登录接口")
    def login(self,session,data):
        self.url = base.pre_bank_base_url + '/perbank/v1/user/login'
        self.data = data
        r = session.post(url=self.url,json=self.data,verify=False)
        return r

    @allure.story("获取MsgInfo")
    def genMsgInfo(self):
        self.url = base.easy_bank_base_url + '/interface/genMsgInfo'
        r = requests.get(url=self.url,headers=self.myHeader,verify=False)
        msgID = r.json()['msgID']
        return msgID

    @allure.story("设置默认卡")
    def setCardDefaultNew(self,session,data):
        self.url = base.easy_bank_base_url + '/interface/setCardDefaultNew'
        self.data = data
        r = session.post(url=self.url,json=self.data,headers=self.myHeader,verify=False)
        return r

    @allure.story("获取卡列表")
    def getCardListNew(self):
        self.url = base.easy_bank_base_url + '/interface/getCardListNew?refresh=1'
        r = requests.get(url=self.url,headers=self.myHeader,verify=False)
        return r


    @allure.story("获取卡qrcToken")
    def get_qrcToken(self):
        self.url = base.easy_bank_base_url + '/interface/getCardListNew?refresh=1'
        r = requests.get(url=self.url,headers=self.myHeader,verify=False)
        n = len(r.json()['userCardInfoDtoList'])
        if n > 0:
            qrcToken = r.json()['userCardInfoDtoList'][0]['qrcToken']
        else:
            print("未绑卡")
        return qrcToken

    @allure.story("获取卡数量")
    def get_card_count(self):
        self.url = base.easy_bank_base_url + '/interface/getCardListNew?refresh=1'
        r = requests.get(url=self.url,headers=self.myHeader,verify=False)
        n = len(r.json()['userCardInfoDtoList'])
        return n

    #APP绑卡
    @allure.story("APP绑卡")
    def app_bind(self,session,data):
        self.url = base.easy_bank_base_url + '/api/gift/app/bind'
        self.data = data
        r = session.post(url=self.url,json=self.data,headers=self.myHeader,verify=False)
        return r

    #H5绑卡
    @allure.story("H5绑卡")
    def h5_bind(self,session,data):
        self.url = base.easy_bank_base_url + '/api/gift/bind'
        self.data = data
        r = session.post(url=self.url,json=self.data,headers=self.myHeader,verify=False)
        return r

    #获取卡密
    @allure.story("获取卡密")
    def get_card(self,files):
        with open(files,encoding='utf-8') as f:
            lines = [line.strip('\n') for line in f.readlines()]
        return lines

    #删除已使用卡
    @allure.story("删除已使用卡")
    def del_used_card(self,files):
        cards = self.get_card(files)
        cards.pop()
        with open(files,'a',encoding='utf-8') as f:
            f.seek(0)
            f.truncate()
            # f.write(''.join(str(i) for i in cards) +'\n')
        for i in cards:
            with open(files,'a',encoding='utf-8') as f:
                f.write(i+'\n')

    #生成付款码
    @allure.story("生成付款码")
    def qrcGeneration(self,session,data):
        self.url = base.easy_bank_base_url + '/interface/qrcGeneration'
        self.data = data
        r = session.post(url=self.url,json=self.data,headers=self.myHeader,verify=False)
        return r

    #发卡
    @allure.story("发卡")
    def sendCard(self,session,data):
        self.url = base.easy_bank_base_url + '/api/send-card/send'
        self.data = data
        r = session.post(url=self.url,json=self.data,headers=self.myHeader,verify=False)
        return r

    #发红包
    @allure.story("发红包")
    def sendRedPacket(self,session,data):
        self.url = base.easy_bank_base_url + '/api/send-red-packet/send'
        self.data = data
        r = session.post(url=self.url,json=self.data,headers=self.myHeader,verify=False)
        return r

    #查询交易信息
    @allure.story("查询交易信息")
    def getTransactions(self,session,data):
        self.url = base.easy_bank_base_url + '/interface/getTransactions'
        self.data = data
        r = session.post(url=self.url,json=self.data,headers=self.myHeader,verify=False)
        return r

    #获取零钱
    @allure.story("获取零钱")
    def balance(self):
        self.url = base.easy_bank_base_url + '/api/cash/balance'
        r = requests.get(url=self.url,headers=self.myHeader,verify=False)
        return r

    #获取零钱记录
    @allure.story("获取零钱记录")
    def balance_record(self):
        self.url = base.easy_bank_base_url + '/api/cash/record'
        r = requests.get(url=self.url,headers=self.myHeader,verify=False)
        return r


    @allure.story("设置隐藏卡")
    def set_card_hide(self,session,data):
        self.url = base.easy_bank_base_url + '/interface/setCardHideNew'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    @allure.story("领卡详情")
    def card_collection_detail(self,session,data):
        self.url = base.easy_bank_base_url + '/api/cardCollectionDetail'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    @allure.story("领卡记录")
    def card_collection_record(self,session,data):
        self.url = base.easy_bank_base_url + '/api/cardCollectionRecord'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    @allure.story("发卡记录")
    def send_card_record(self,session,data):
        self.url = base.easy_bank_base_url + '/api/cardIssuingRecord'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    @allure.story("卡片领取详情")
    def send_card_receive_detail(self,session,data):
        self.url = base.easy_bank_base_url + '/api/send-card/receiveDetail'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    @allure.story("获取发卡人信息")
    def send_card_sender_info(self,session,data):
        self.url = base.easy_bank_base_url + '/api/send-card/senderInfo'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    @allure.story("领卡")
    def card_receive(self,session,data):
        self.url = base.h5_url+ '/api/send-card/receive'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    @allure.story("领取状态")
    def card_receive_State(self,session,data):
        self.url = base.easy_bank_base_url + '/api/send-card/receiveState'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    @allure.story("领取红包")
    def redp_receive(self,session,data):
        self.url = base.h5_url + '/api/send-red-packet/receive'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    @allure.story("领取红包记录")
    def redp_receive_record(self,session,data):
        self.url = base.easy_bank_base_url + '/api/send-red-packet/recvRedPacketRecord'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    @allure.story("app红包详情")
    def app_redp_detail(self,session,data):
        self.url = base.easy_bank_base_url + '/api/send-red-packet/redPacketDetail'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    @allure.story("H5红包详情")
    def h5_redp_detail(self,session,data):
        self.url = base.easy_bank_base_url + '/api/send-red-packet/redPacketDetailOfHtml'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    @allure.story("H5获取发红包人信息")
    def redp_sender_Info(self,session,data):
        self.url = base.easy_bank_base_url + '/api/send-red-packet/senderInfo'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    @allure.story("发红包记录")
    def redp_send_record(self,session,data):
        self.url = base.easy_bank_base_url + '/api/send-red-packet/sendRedPacketRecord'
        self.data = data
        r = session.post(url=self.url,headers=self.myHeader,json=self.data,verify=False)
        return r

    #获取发红包流程数据
    def get_redp_data(self,files):
        with open(files,encoding='utf-8') as f:
            yml_data = yaml.safe_load(f)
            data = []
            for i in yml_data.keys():
                send_data = yml_data[i]['send_data']
                send_record_data = yml_data[i]['send_record_data']
                rec_record_data = yml_data[i]['rec_record_data']
                eles = (send_data,send_record_data,rec_record_data)
                data.append(eles)
        return data