import os
import sys
print(sys.path)

# 封装程序常量
easy_bank_base_url = 'http://192.168.168.204:8081'
pre_bank_base_url= 'http://sit.bankdo.com'
h5_url = 'http://gift.easybank.com.cn'


file_path = os.path.dirname(os.path.abspath(__file__))